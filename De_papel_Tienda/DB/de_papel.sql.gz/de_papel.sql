-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 29-08-2018 a las 20:53:36
-- Versión del servidor: 5.6.34-log
-- Versión de PHP: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `de_papel`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_commentmeta`
--

CREATE TABLE `dp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_comments`
--

CREATE TABLE `dp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_comments`
--

INSERT INTO `dp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un Comentarista de WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-08-09 17:28:31', '2018-08-09 17:28:31', 'Hola, este es un comentario.\nPara empezar con la moderación, edición y eliminación de comentarios, por favor visita la pantalla de comentarios en el panel inicial.\nLos Avatares de los comentaristas provienen de <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_duplicator_packages`
--

CREATE TABLE `dp_duplicator_packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_ewwwio_images`
--

CREATE TABLE `dp_ewwwio_images` (
  `id` int(14) UNSIGNED NOT NULL,
  `attachment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gallery` varchar(10) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `resize` varchar(75) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `converted` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `results` varchar(75) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `image_size` int(10) UNSIGNED DEFAULT NULL,
  `orig_size` int(10) UNSIGNED DEFAULT NULL,
  `backup` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `level` int(5) UNSIGNED DEFAULT NULL,
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `updates` int(5) UNSIGNED DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT '1971-01-01 03:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `trace` blob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_ewwwio_images`
--

INSERT INTO `dp_ewwwio_images` (`id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 45, 'media', 'full', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1.jpg', '', 'Reduced by 3.0% (2.4 KB)', 78758, 81196, '', 10, 0, 1, '2018-08-20 00:58:59', NULL),
(2, 45, 'media', 'thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-150x150.jpg', '', 'Reduced by 12.1% (1,006 B)', 7327, 8333, '', 10, 0, 1, '2018-08-20 00:59:00', NULL),
(3, 45, 'media', 'medium', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-300x225.jpg', '', 'Reduced by 7.9% (1.4 KB)', 16464, 17882, '', 10, 0, 1, '2018-08-20 00:59:00', NULL),
(4, 45, 'media', 'medium_large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-768x576.jpg', '', 'Reduced by 4.4% (3.3 KB)', 73766, 77195, '', 10, 0, 1, '2018-08-20 00:59:01', NULL),
(5, 45, 'media', 'large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-1024x768.jpg', '', 'Reduced by 2.3% (2.2 KB)', 96128, 98419, '', 10, 0, 1, '2018-08-20 00:59:02', NULL),
(6, 45, 'media', 'slideshow', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-800x600.jpg', '', 'Reduced by 4.5% (3.6 KB)', 78609, 82294, '', 10, 0, 1, '2018-08-20 00:59:02', NULL),
(7, 45, 'media', 'woocommerce_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-300x300.jpg', '', 'Reduced by 7.0% (1.6 KB)', 22398, 24075, '', 10, 0, 1, '2018-08-20 00:59:03', NULL),
(8, 45, 'media', 'woocommerce_single', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-600x450.jpg', '', 'Reduced by 5.2% (2.7 KB)', 50266, 53021, '', 10, 0, 1, '2018-08-20 00:59:03', NULL),
(9, 45, 'media', 'woocommerce_gallery_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog1-100x100.jpg', '', 'Reduced by 21.0% (1,006 B)', 3788, 4794, '', 10, 0, 1, '2018-08-20 00:59:03', NULL),
(10, 47, 'media', 'full', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2.jpg', '', 'Reduced by 3.1% (1.3 KB)', 42177, 43512, '', 10, 0, 1, '2018-08-20 01:09:21', NULL),
(11, 47, 'media', 'thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-150x150.jpg', '', 'Reduced by 13.9% (885 B)', 5470, 6355, '', 10, 0, 1, '2018-08-20 01:09:22', NULL),
(12, 47, 'media', 'medium', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-300x225.jpg', '', 'Reduced by 6.7% (793 B)', 10971, 11764, '', 10, 0, 1, '2018-08-20 01:09:22', NULL),
(13, 47, 'media', 'medium_large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-768x576.jpg', '', 'Reduced by 3.4% (1.4 KB)', 39436, 40832, '', 10, 0, 1, '2018-08-20 01:09:22', NULL),
(14, 47, 'media', 'large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-1024x768.jpg', '', 'Reduced by 1.3% (652 B)', 50389, 51041, '', 10, 0, 1, '2018-08-20 01:09:23', NULL),
(15, 47, 'media', 'slideshow', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-800x600.jpg', '', 'Reduced by 3.6% (1.6 KB)', 42243, 43832, '', 10, 0, 1, '2018-08-20 01:09:23', NULL),
(16, 47, 'media', 'woocommerce_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-300x300.jpg', '', 'Reduced by 6.0% (915 B)', 14236, 15151, '', 10, 0, 1, '2018-08-20 01:09:24', NULL),
(17, 47, 'media', 'woocommerce_single', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-600x450.jpg', '', 'Reduced by 4.4% (1.3 KB)', 28318, 29636, '', 10, 0, 1, '2018-08-20 01:09:24', NULL),
(18, 47, 'media', 'woocommerce_gallery_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/blog2-100x100.jpg', '', 'Reduced by 21.9% (885 B)', 3148, 4033, '', 10, 0, 1, '2018-08-20 01:09:25', NULL),
(19, 49, 'media', 'full', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1.jpg', '', 'Reduced by 2.1% (1.2 KB)', 58096, 59336, '', 10, 0, 1, '2018-08-20 01:10:19', NULL),
(20, 49, 'media', 'thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-150x150.jpg', '', 'Reduced by 16.2% (1,010 B)', 5241, 6251, '', 10, 0, 1, '2018-08-20 01:10:20', NULL),
(21, 49, 'media', 'medium', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-300x225.jpg', '', 'Reduced by 8.4% (1.1 KB)', 12387, 13518, '', 10, 0, 1, '2018-08-20 01:10:20', NULL),
(22, 49, 'media', 'medium_large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-768x576.jpg', '', 'Reduced by 3.8% (2.2 KB)', 56392, 58641, '', 10, 0, 1, '2018-08-20 01:10:21', NULL),
(23, 49, 'media', 'large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-1024x768.jpg', '', 'Reduced by 1.1% (763 B)', 71850, 72613, '', 10, 0, 1, '2018-08-20 01:10:21', NULL),
(24, 49, 'media', 'slideshow', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-800x600.jpg', '', 'Reduced by 3.6% (2.2 KB)', 60264, 62506, '', 10, 0, 1, '2018-08-20 01:10:22', NULL),
(25, 49, 'media', 'woocommerce_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-300x300.jpg', '', 'Reduced by 6.9% (1.2 KB)', 16151, 17344, '', 10, 0, 1, '2018-08-20 01:10:22', NULL),
(26, 49, 'media', 'woocommerce_single', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-600x450.jpg', '', 'Reduced by 4.8% (1.9 KB)', 38371, 40300, '', 10, 0, 1, '2018-08-20 01:10:22', NULL),
(27, 49, 'media', 'woocommerce_gallery_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria1-100x100.jpg', '', 'Reduced by 26.3% (1,010 B)', 2827, 3837, '', 10, 0, 1, '2018-08-20 01:10:23', NULL),
(28, 50, 'media', 'full', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2.jpg', '', 'Reduced by 2.6% (2.5 KB)', 95652, 98215, '', 10, 0, 1, '2018-08-20 01:10:28', NULL),
(29, 50, 'media', 'thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-150x150.jpg', '', 'Reduced by 11.1% (1,006 B)', 8068, 9074, '', 10, 0, 1, '2018-08-20 01:10:28', NULL),
(30, 50, 'media', 'medium', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-300x225.jpg', '', 'Reduced by 7.4% (1.5 KB)', 19475, 21031, '', 10, 0, 1, '2018-08-20 01:10:28', NULL),
(31, 50, 'media', 'medium_large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-768x576.jpg', '', 'Reduced by 4.3% (3.9 KB)', 88172, 92149, '', 10, 0, 1, '2018-08-20 01:10:29', NULL),
(32, 50, 'media', 'large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-1024x768.jpg', '', 'Reduced by 2.0% (2.3 KB)', 117355, 119698, '', 10, 0, 1, '2018-08-20 01:10:29', NULL),
(33, 50, 'media', 'slideshow', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-800x600.jpg', '', 'Reduced by 4.4% (4.2 KB)', 93818, 98126, '', 10, 0, 1, '2018-08-20 01:10:30', NULL),
(34, 50, 'media', 'woocommerce_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-300x300.jpg', '', 'Reduced by 6.6% (1.7 KB)', 24443, 26173, '', 10, 0, 1, '2018-08-20 01:10:30', NULL),
(35, 50, 'media', 'woocommerce_single', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-600x450.jpg', '', 'Reduced by 4.9% (3.0 KB)', 60154, 63256, '', 10, 0, 1, '2018-08-20 01:10:31', NULL),
(36, 50, 'media', 'woocommerce_gallery_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria2-100x100.jpg', '', 'Reduced by 19.4% (1,006 B)', 4186, 5192, '', 10, 0, 1, '2018-08-20 01:10:31', NULL),
(37, 51, 'media', 'full', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3.jpg', '', 'Reduced by 4.7% (2.4 KB)', 50917, 53415, '', 10, 0, 1, '2018-08-20 01:10:36', NULL),
(38, 51, 'media', 'thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-150x150.jpg', '', 'Reduced by 15.4% (885 B)', 4873, 5758, '', 10, 0, 1, '2018-08-20 01:10:36', NULL),
(39, 51, 'media', 'medium', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-300x225.jpg', '', 'Reduced by 8.8% (991 B)', 10219, 11210, '', 10, 0, 1, '2018-08-20 01:10:36', NULL),
(40, 51, 'media', 'medium_large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-768x576.jpg', '', 'Reduced by 5.1% (2.5 KB)', 46653, 49169, '', 10, 0, 1, '2018-08-20 01:10:37', NULL),
(41, 51, 'media', 'large', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-1024x768.jpg', '', 'Reduced by 3.8% (2.4 KB)', 62262, 64739, '', 10, 0, 1, '2018-08-20 01:10:37', NULL),
(42, 51, 'media', 'slideshow', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-800x600.jpg', '', 'Reduced by 5.1% (2.6 KB)', 49704, 52358, '', 10, 0, 1, '2018-08-20 01:10:38', NULL),
(43, 51, 'media', 'woocommerce_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-300x300.jpg', '', 'Reduced by 7.7% (1.2 KB)', 14958, 16201, '', 10, 0, 1, '2018-08-20 01:10:38', NULL),
(44, 51, 'media', 'woocommerce_single', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-600x450.jpg', '', 'Reduced by 5.9% (2.0 KB)', 31790, 33796, '', 10, 0, 1, '2018-08-20 01:10:39', NULL),
(45, 51, 'media', 'woocommerce_gallery_thumbnail', 'C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/uploads/2018/08/galeria3-100x100.jpg', '', 'Reduced by 24.7% (885 B)', 2695, 3580, '', 10, 0, 1, '2018-08-20 01:10:40', NULL),
(46, 67, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613.jpg', '', 'Reduced by 96.0% (1.8 MB)', 77290, 1939350, '', 10, 0, 1, '2018-08-22 19:38:43', NULL),
(47, 67, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-150x150.jpg', '', 'Reduced by 6.3% (408 B)', 6090, 6498, '', 10, 0, 1, '2018-08-22 22:38:44', NULL),
(48, 67, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-300x200.jpg', '', 'Reduced by 4.8% (556 B)', 11120, 11676, '', 10, 0, 1, '2018-08-22 22:38:45', NULL),
(49, 67, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-768x512.jpg', '', 'Reduced by 5.0% (2.3 KB)', 46032, 48431, '', 10, 0, 1, '2018-08-22 22:38:50', NULL),
(50, 67, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-1024x683.jpg', '', 'Reduced by 5.4% (4.3 KB)', 77237, 81617, '', 10, 0, 1, '2018-08-22 22:38:57', NULL),
(51, 67, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-800x600.jpg', '', 'Reduced by 4.6% (2.6 KB)', 55318, 57958, '', 10, 0, 1, '2018-08-22 22:39:02', NULL),
(52, 67, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-300x300.jpg', '', 'Reduced by 4.5% (800 B)', 16935, 17735, '', 10, 0, 1, '2018-08-22 22:39:04', NULL),
(53, 67, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-600x400.jpg', '', 'Reduced by 4.5% (1.4 KB)', 31204, 32660, '', 10, 0, 1, '2018-08-22 22:39:07', NULL),
(54, 67, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-100x100.jpg', '', 'Reduced by 9.5% (368 B)', 3510, 3878, '', 10, 0, 1, '2018-08-22 22:39:08', NULL),
(55, 51, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3.jpg', '', 'Reduced by 43.7% (21.7 KB)', 28672, 50917, '', 10, 0, 1, '2018-08-22 22:39:42', NULL),
(56, 51, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-150x150.jpg', '', 'No savings', 4873, 4873, '', 10, 0, 1, '2018-08-22 22:39:44', NULL),
(57, 51, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-300x225.jpg', '', 'No savings', 10219, 10219, '', 10, 0, 1, '2018-08-22 22:39:45', NULL),
(58, 51, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-768x576.jpg', '', 'No savings', 46653, 46653, '', 10, 0, 1, '2018-08-22 22:39:52', NULL),
(59, 51, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-1024x768.jpg', '', 'No savings', 62262, 62262, '', 10, 0, 1, '2018-08-22 22:39:52', NULL),
(60, 51, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-800x600.jpg', '', 'No savings', 49704, 49704, '', 10, 0, 1, '2018-08-22 22:39:58', NULL),
(61, 51, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-300x300.jpg', '', 'No savings', 14958, 14958, '', 10, 0, 1, '2018-08-22 22:40:00', NULL),
(62, 51, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-600x450.jpg', '', 'No savings', 31790, 31790, '', 10, 0, 1, '2018-08-22 22:40:07', NULL),
(63, 51, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-100x100.jpg', '', 'No savings', 2695, 2695, '', 10, 0, 1, '2018-08-22 22:40:08', NULL),
(64, 50, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2.jpg', '', 'No savings', 95652, 95652, '', 10, 0, 1, '2018-08-22 22:40:23', NULL),
(65, 50, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-150x150.jpg', '', 'No savings', 8068, 8068, '', 10, 0, 1, '2018-08-22 22:40:23', NULL),
(66, 50, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-300x225.jpg', '', 'No savings', 19475, 19475, '', 10, 0, 1, '2018-08-22 22:40:25', NULL),
(67, 50, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-768x576.jpg', '', 'No savings', 88172, 88172, '', 10, 0, 1, '2018-08-22 22:40:28', NULL),
(68, 50, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-1024x768.jpg', '', 'No savings', 117355, 117355, '', 10, 0, 1, '2018-08-22 22:40:35', NULL),
(69, 50, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-800x600.jpg', '', 'No savings', 93818, 93818, '', 10, 0, 1, '2018-08-22 22:40:40', NULL),
(70, 50, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-300x300.jpg', '', 'No savings', 24443, 24443, '', 10, 0, 1, '2018-08-22 22:40:42', NULL),
(71, 50, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-600x450.jpg', '', 'No savings', 60154, 60154, '', 10, 0, 1, '2018-08-22 22:40:45', NULL),
(72, 50, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-100x100.jpg', '', 'No savings', 4186, 4186, '', 10, 0, 1, '2018-08-22 22:40:46', NULL),
(73, 49, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1.jpg', '', 'No savings', 58096, 58096, '', 10, 0, 1, '2018-08-22 22:41:19', NULL),
(74, 49, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-150x150.jpg', '', 'No savings', 5241, 5241, '', 10, 0, 1, '2018-08-22 22:41:19', NULL),
(75, 49, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-300x225.jpg', '', 'No savings', 12387, 12387, '', 10, 0, 1, '2018-08-22 22:41:19', NULL),
(76, 49, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-768x576.jpg', '', 'No savings', 56392, 56392, '', 10, 0, 1, '2018-08-22 22:41:20', NULL),
(77, 49, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1024x768.jpg', '', 'No savings', 71850, 71850, '', 10, 0, 1, '2018-08-22 22:41:21', NULL),
(78, 49, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-800x600.jpg', '', 'No savings', 60264, 60264, '', 10, 0, 1, '2018-08-22 22:41:22', NULL),
(79, 49, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-300x300.jpg', '', 'No savings', 16151, 16151, '', 10, 0, 1, '2018-08-22 22:41:22', NULL),
(80, 49, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-600x450.jpg', '', 'No savings', 38371, 38371, '', 10, 0, 1, '2018-08-22 22:41:22', NULL),
(81, 49, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-100x100.jpg', '', 'No savings', 2827, 2827, '', 10, 0, 1, '2018-08-22 22:41:23', NULL),
(82, 47, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2.jpg', '', 'No savings', 42177, 42177, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(83, 47, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-150x150.jpg', '', 'No savings', 5470, 5470, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(84, 47, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-300x225.jpg', '', 'No savings', 10971, 10971, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(85, 47, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-768x576.jpg', '', 'No savings', 39436, 39436, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(86, 47, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-1024x768.jpg', '', 'No savings', 50389, 50389, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(87, 47, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-800x600.jpg', '', 'No savings', 42243, 42243, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(88, 47, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-300x300.jpg', '', 'No savings', 14236, 14236, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(89, 47, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-600x450.jpg', '', 'No savings', 28318, 28318, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(90, 47, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-100x100.jpg', '', 'No savings', 3148, 3148, '', 10, 0, 1, '2018-08-22 22:41:27', NULL),
(91, 45, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1.jpg', '', 'No savings', 78758, 78758, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(92, 45, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-150x150.jpg', '', 'No savings', 7327, 7327, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(93, 45, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-300x225.jpg', '', 'No savings', 16464, 16464, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(94, 45, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-768x576.jpg', '', 'No savings', 73766, 73766, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(95, 45, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-1024x768.jpg', '', 'No savings', 96128, 96128, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(96, 45, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-800x600.jpg', '', 'No savings', 78609, 78609, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(97, 45, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-300x300.jpg', '', 'No savings', 22398, 22398, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(98, 45, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-600x450.jpg', '', 'No savings', 50266, 50266, '', 10, 0, 1, '2018-08-22 22:41:32', NULL),
(99, 45, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-100x100.jpg', '', 'No savings', 3788, 3788, '', 10, 0, 1, '2018-08-22 22:41:33', NULL),
(100, 127, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684.jpg', '', 'Reduced by 95.8% (1.7 MB)', 76315, 1809363, '', 10, 0, 1, '2018-08-23 01:04:23', NULL),
(101, 127, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-150x150.jpg', '', 'Reduced by 6.3% (370 B)', 5534, 5904, '', 10, 0, 1, '2018-08-23 04:04:23', NULL),
(102, 127, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-300x200.jpg', '', 'Reduced by 4.0% (446 B)', 10808, 11254, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(103, 127, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-768x512.jpg', '', 'Reduced by 4.2% (1.9 KB)', 45366, 47335, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(104, 127, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-1024x683.jpg', '', 'Reduced by 4.8% (3.8 KB)', 76221, 80075, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(105, 127, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-800x600.jpg', '', 'Reduced by 4.0% (2.2 KB)', 54356, 56645, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(106, 127, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-300x300.jpg', '', 'Reduced by 3.7% (579 B)', 15265, 15844, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(107, 127, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-600x400.jpg', '', 'Reduced by 4.0% (1.3 KB)', 30534, 31814, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(108, 127, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-100x100.jpg', '', 'Reduced by 10.1% (359 B)', 3192, 3551, '', 10, 0, 1, '2018-08-23 04:04:24', NULL),
(109, 133, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677.jpg', '', 'Reduced by 94.3% (1.3 MB)', 82253, 1440522, '', 10, 0, 1, '2018-08-23 01:10:39', NULL),
(110, 133, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-150x150.jpg', '', 'Reduced by 7.0% (408 B)', 5424, 5832, '', 10, 0, 1, '2018-08-23 04:10:39', NULL),
(111, 133, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-300x200.jpg', '', 'Reduced by 4.8% (546 B)', 10861, 11407, '', 10, 0, 1, '2018-08-23 04:10:39', NULL),
(112, 133, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-768x512.jpg', '', 'Reduced by 3.9% (1.9 KB)', 48408, 50363, '', 10, 0, 1, '2018-08-23 04:10:40', NULL),
(113, 133, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1024x683.jpg', '', 'Reduced by 4.5% (3.8 KB)', 82231, 86120, '', 10, 0, 1, '2018-08-23 04:10:40', NULL),
(114, 133, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-800x600.jpg', '', 'Reduced by 3.6% (2.1 KB)', 58733, 60916, '', 10, 0, 1, '2018-08-23 04:10:40', NULL),
(115, 133, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-300x300.jpg', '', 'Reduced by 3.7% (634 B)', 16460, 17094, '', 10, 0, 1, '2018-08-23 04:10:40', NULL),
(116, 133, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-600x400.jpg', '', 'Reduced by 3.9% (1.3 KB)', 32482, 33798, '', 10, 0, 1, '2018-08-23 04:10:40', NULL),
(117, 133, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-100x100.jpg', '', 'Reduced by 11.6% (393 B)', 2998, 3391, '', 10, 0, 1, '2018-08-23 04:10:40', NULL),
(118, 142, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674.jpg', '', 'Reduced by 95.7% (1.5 MB)', 71018, 1644785, '', 10, 0, 1, '2018-08-23 15:23:43', NULL),
(119, 142, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-150x150.jpg', '', 'Reduced by 6.2% (358 B)', 5426, 5784, '', 10, 0, 1, '2018-08-23 18:23:43', NULL),
(120, 142, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-300x200.jpg', '', 'Reduced by 4.0% (431 B)', 10406, 10837, '', 10, 0, 1, '2018-08-23 18:23:44', NULL),
(121, 142, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-768x512.jpg', '', 'Reduced by 4.7% (2.1 KB)', 42859, 44961, '', 10, 0, 1, '2018-08-23 18:23:45', NULL),
(122, 142, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-1024x683.jpg', '', 'Reduced by 5.4% (3.9 KB)', 70975, 74991, '', 10, 0, 1, '2018-08-23 18:23:46', NULL),
(123, 143, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989.jpg', '', 'Reduced by 98.2% (3.1 MB)', 60204, 3319112, '', 10, 0, 1, '2018-08-23 15:23:53', NULL),
(124, 142, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-800x600.jpg', '', 'Reduced by 4.6% (2.4 KB)', 50361, 52798, '', 10, 0, 1, '2018-08-23 18:23:46', NULL),
(125, 142, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-300x300.jpg', '', 'Reduced by 4.0% (622 B)', 15088, 15710, '', 10, 0, 1, '2018-08-23 18:23:46', NULL),
(126, 142, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-600x400.jpg', '', 'Reduced by 4.3% (1.3 KB)', 29116, 30429, '', 10, 0, 1, '2018-08-23 18:23:47', NULL),
(127, 142, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-100x100.jpg', '', 'Reduced by 10.8% (366 B)', 3034, 3400, '', 10, 0, 1, '2018-08-23 18:23:47', NULL),
(128, 143, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-150x150.jpg', '', 'Reduced by 5.9% (362 B)', 5758, 6120, '', 10, 0, 1, '2018-08-23 18:23:54', NULL),
(129, 143, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-300x169.jpg', '', 'Reduced by 4.4% (367 B)', 7997, 8364, '', 10, 0, 1, '2018-08-23 18:23:54', NULL),
(130, 143, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-768x432.jpg', '', 'Reduced by 5.5% (2.0 KB)', 35459, 37533, '', 10, 0, 1, '2018-08-23 18:23:54', NULL),
(131, 143, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-1024x576.jpg', '', 'Reduced by 6.6% (4.1 KB)', 60155, 64376, '', 10, 0, 1, '2018-08-23 18:23:55', NULL),
(132, 143, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-800x576.jpg', '', 'Reduced by 5.7% (3.2 KB)', 55158, 58473, '', 10, 0, 1, '2018-08-23 18:23:56', NULL),
(133, 143, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-300x300.jpg', '', 'Reduced by 4.0% (715 B)', 17269, 17984, '', 10, 0, 1, '2018-08-23 18:23:56', NULL),
(134, 143, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-600x338.jpg', '', 'Reduced by 5.2% (1.3 KB)', 23784, 25092, '', 10, 0, 1, '2018-08-23 18:23:57', NULL),
(135, 143, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-100x100.jpg', '', 'Reduced by 10.1% (363 B)', 3236, 3599, '', 10, 0, 1, '2018-08-23 18:23:57', NULL),
(136, 144, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990.jpg', '', 'Reduced by 98.3% (2.6 MB)', 48186, 2783577, '', 10, 0, 1, '2018-08-23 15:24:23', NULL),
(137, 145, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991.jpg', '', 'Reduced by 98.4% (3.0 MB)', 51727, 3167667, '', 10, 0, 1, '2018-08-23 15:24:28', NULL),
(138, 144, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-150x150.jpg', '', 'Reduced by 6.7% (356 B)', 4952, 5308, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(139, 144, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-300x169.jpg', '', 'Reduced by 5.4% (385 B)', 6806, 7191, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(140, 144, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-768x432.jpg', '', 'Reduced by 6.4% (1.9 KB)', 28856, 30825, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(141, 144, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-1024x576.jpg', '', 'Reduced by 7.1% (3.6 KB)', 48205, 51907, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(142, 144, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-800x576.jpg', '', 'Reduced by 6.3% (2.9 KB)', 44818, 47816, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(143, 144, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-300x300.jpg', '', 'Reduced by 4.4% (657 B)', 14167, 14824, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(144, 144, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-600x338.jpg', '', 'Reduced by 5.8% (1.2 KB)', 19690, 20905, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(145, 144, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-100x100.jpg', '', 'Reduced by 11.4% (350 B)', 2733, 3083, '', 10, 0, 1, '2018-08-23 18:24:23', NULL),
(146, 145, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-150x150.jpg', '', 'Reduced by 6.4% (355 B)', 5215, 5570, '', 10, 0, 1, '2018-08-23 18:24:28', NULL),
(147, 145, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-300x169.jpg', '', 'Reduced by 5.1% (394 B)', 7307, 7701, '', 10, 0, 1, '2018-08-23 18:24:29', NULL),
(148, 145, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-768x432.jpg', '', 'Reduced by 6.2% (2.0 KB)', 30965, 33005, '', 10, 0, 1, '2018-08-23 18:24:30', NULL),
(149, 145, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-1024x576.jpg', '', 'Reduced by 7.1% (3.9 KB)', 51724, 55684, '', 10, 0, 1, '2018-08-23 18:24:31', NULL),
(150, 145, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-800x576.jpg', '', 'Reduced by 6.2% (3.1 KB)', 48033, 51187, '', 10, 0, 1, '2018-08-23 18:24:32', NULL),
(151, 145, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-300x300.jpg', '', 'Reduced by 4.6% (719 B)', 14991, 15710, '', 10, 0, 1, '2018-08-23 18:24:32', NULL),
(152, 145, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-600x338.jpg', '', 'Reduced by 5.7% (1.2 KB)', 21020, 22288, '', 10, 0, 1, '2018-08-23 18:24:32', NULL),
(153, 145, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-100x100.jpg', '', 'Reduced by 11.2% (360 B)', 2851, 3211, '', 10, 0, 1, '2018-08-23 18:24:32', NULL),
(154, 146, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014.jpg', '', 'Reduced by 97.9% (3.2 MB)', 70802, 3438938, '', 10, 0, 1, '2018-08-23 15:24:53', NULL),
(155, 146, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-150x150.jpg', '', 'Reduced by 5.2% (366 B)', 6642, 7008, '', 10, 0, 1, '2018-08-23 18:24:53', NULL),
(156, 146, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-300x169.jpg', '', 'Reduced by 4.2% (452 B)', 10244, 10696, '', 10, 0, 1, '2018-08-23 18:24:54', NULL),
(157, 146, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-768x432.jpg', '', 'Reduced by 4.8% (2.1 KB)', 42870, 45050, '', 10, 0, 1, '2018-08-23 18:24:54', NULL),
(158, 147, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064.jpg', '', 'Reduced by 98.5% (2.9 MB)', 47328, 3081388, '', 10, 0, 1, '2018-08-23 15:25:00', NULL),
(159, 146, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-1024x576.jpg', '', 'Reduced by 4.9% (3.6 KB)', 70763, 74437, '', 10, 0, 1, '2018-08-23 18:24:55', NULL),
(160, 146, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-800x576.jpg', '', 'Reduced by 4.5% (2.9 KB)', 63524, 66500, '', 10, 0, 1, '2018-08-23 18:24:55', NULL),
(161, 146, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-300x300.jpg', '', 'Reduced by 4.4% (877 B)', 18919, 19796, '', 10, 0, 1, '2018-08-23 18:24:55', NULL),
(162, 146, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-600x338.jpg', '', 'Reduced by 5.0% (1.5 KB)', 29389, 30932, '', 10, 0, 1, '2018-08-23 18:24:55', NULL),
(163, 146, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-100x100.jpg', '', 'Reduced by 9.1% (363 B)', 3626, 3989, '', 10, 0, 1, '2018-08-23 18:24:55', NULL),
(164, 147, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-150x150.jpg', '', 'Reduced by 6.4% (401 B)', 5870, 6271, '', 10, 0, 1, '2018-08-23 18:25:00', NULL),
(165, 147, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-175x300.jpg', '', 'Reduced by 4.0% (453 B)', 10794, 11247, '', 10, 0, 1, '2018-08-23 18:25:00', NULL),
(166, 147, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-449x600.jpg', '', 'Reduced by 3.0% (1.2 KB)', 40942, 42197, '', 10, 0, 1, '2018-08-23 18:25:02', NULL),
(167, 147, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-300x300.jpg', '', 'Reduced by 3.3% (553 B)', 16313, 16866, '', 10, 0, 1, '2018-08-23 18:25:02', NULL),
(168, 147, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-100x100.jpg', '', 'Reduced by 10.4% (390 B)', 3350, 3740, '', 10, 0, 1, '2018-08-23 18:25:03', NULL),
(169, 148, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105.jpg', '', 'Reduced by 97.2% (5.9 MB)', 178284, 6387012, '', 10, 0, 1, '2018-08-23 15:25:23', NULL),
(170, 149, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3.jpg', '', 'Reduced by 95.6% (1.8 MB)', 84969, 1942167, '', 10, 0, 1, '2018-08-23 15:25:30', NULL),
(171, 148, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-150x150.jpg', '', 'Reduced by 4.7% (361 B)', 7292, 7653, '', 10, 0, 1, '2018-08-23 18:25:23', NULL),
(172, 148, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-300x169.jpg', '', 'Reduced by 7.0% (1.3 KB)', 17782, 19123, '', 10, 0, 1, '2018-08-23 18:25:23', NULL),
(173, 148, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-768x432.jpg', '', 'Reduced by 7.6% (7.8 KB)', 97102, 105093, '', 10, 0, 1, '2018-08-23 18:25:24', NULL),
(174, 148, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-1024x576.jpg', '', 'Reduced by 7.8% (14.8 KB)', 178239, 193422, '', 10, 0, 1, '2018-08-23 18:25:24', NULL),
(175, 148, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-800x576.jpg', '', 'Reduced by 7.4% (10.4 KB)', 132661, 143302, '', 10, 0, 1, '2018-08-23 18:25:24', NULL),
(176, 148, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-300x300.jpg', '', 'Reduced by 5.7% (1.4 KB)', 24196, 25648, '', 10, 0, 1, '2018-08-23 18:25:24', NULL),
(177, 148, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-600x338.jpg', '', 'Reduced by 7.5% (5.0 KB)', 63080, 68174, '', 10, 0, 1, '2018-08-23 18:25:24', NULL),
(178, 148, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-100x100.jpg', '', 'Reduced by 8.7% (361 B)', 3770, 4131, '', 10, 0, 1, '2018-08-23 18:25:24', NULL),
(179, 149, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-150x150.jpg', '', 'Reduced by 5.5% (365 B)', 6271, 6636, '', 10, 0, 1, '2018-08-23 18:25:31', NULL),
(180, 149, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-300x200.jpg', '', 'Reduced by 4.4% (528 B)', 11453, 11981, '', 10, 0, 1, '2018-08-23 18:25:31', NULL),
(181, 149, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-768x512.jpg', '', 'Reduced by 5.1% (2.6 KB)', 50342, 53054, '', 10, 0, 1, '2018-08-23 18:25:32', NULL),
(182, 149, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-1024x683.jpg', '', 'Reduced by 5.5% (4.9 KB)', 84919, 89895, '', 10, 0, 1, '2018-08-23 18:25:33', NULL),
(183, 149, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-800x600.jpg', '', 'Reduced by 5.2% (3.2 KB)', 59591, 62847, '', 10, 0, 1, '2018-08-23 18:25:34', NULL),
(184, 149, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-300x300.jpg', '', 'Reduced by 4.6% (865 B)', 18036, 18901, '', 10, 0, 1, '2018-08-23 18:25:34', NULL),
(185, 149, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-600x400.jpg', '', 'Reduced by 4.9% (1.7 KB)', 33731, 35468, '', 10, 0, 1, '2018-08-23 18:25:34', NULL),
(186, 149, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-100x100.jpg', '', 'Reduced by 9.8% (364 B)', 3357, 3721, '', 10, 0, 1, '2018-08-23 18:25:35', NULL),
(187, 150, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2.jpg', '', 'Reduced by 97.4% (1.7 MB)', 48708, 1856665, '', 10, 0, 1, '2018-08-23 15:25:49', NULL),
(188, 150, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-150x150.jpg', '', 'Reduced by 6.1% (372 B)', 5763, 6135, '', 10, 0, 1, '2018-08-23 18:25:49', NULL),
(189, 150, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-200x300.jpg', '', 'Reduced by 4.6% (509 B)', 10604, 11113, '', 10, 0, 1, '2018-08-23 18:25:49', NULL),
(190, 150, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-512x600.jpg', '', 'Reduced by 5.0% (2.3 KB)', 44527, 46878, '', 10, 0, 1, '2018-08-23 18:25:49', NULL),
(191, 150, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-300x300.jpg', '', 'Reduced by 3.9% (679 B)', 16620, 17299, '', 10, 0, 1, '2018-08-23 18:25:49', NULL),
(192, 150, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-100x100.jpg', '', 'Reduced by 10.2% (354 B)', 3118, 3472, '', 10, 0, 1, '2018-08-23 18:25:49', NULL),
(193, 151, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670.jpg', '', 'Reduced by 96.1% (1.6 MB)', 67576, 1750300, '', 10, 0, 1, '2018-08-23 15:28:42', NULL),
(194, 151, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-150x150.jpg', '', 'Reduced by 6.6% (389 B)', 5461, 5850, '', 10, 0, 1, '2018-08-23 18:28:43', NULL),
(195, 152, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676.jpg', '', 'Reduced by 94.8% (1.2 MB)', 71527, 1363913, '', 10, 0, 1, '2018-08-23 15:28:54', NULL),
(196, 151, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-300x200.jpg', '', 'Reduced by 4.0% (439 B)', 10626, 11065, '', 10, 0, 1, '2018-08-23 18:28:43', NULL),
(197, 151, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-768x512.jpg', '', 'Reduced by 3.8% (1.6 KB)', 41851, 43517, '', 10, 0, 1, '2018-08-23 18:28:44', NULL),
(198, 151, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-1024x683.jpg', '', 'Reduced by 4.3% (3.0 KB)', 67519, 70552, '', 10, 0, 1, '2018-08-23 18:28:46', NULL),
(199, 151, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-800x600.jpg', '', 'Reduced by 3.4% (1.7 KB)', 49064, 50817, '', 10, 0, 1, '2018-08-23 18:28:47', NULL),
(200, 151, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-300x300.jpg', '', 'Reduced by 3.3% (499 B)', 14759, 15258, '', 10, 0, 1, '2018-08-23 18:28:47', NULL),
(201, 151, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-600x400.jpg', '', 'Reduced by 3.7% (1.1 KB)', 29034, 30150, '', 10, 0, 1, '2018-08-23 18:28:48', NULL),
(202, 151, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-100x100.jpg', '', 'Reduced by 10.4% (363 B)', 3121, 3484, '', 10, 0, 1, '2018-08-23 18:28:48', NULL),
(203, 152, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-150x150.jpg', '', 'Reduced by 6.7% (379 B)', 5308, 5687, '', 10, 0, 1, '2018-08-23 18:28:55', NULL),
(204, 152, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-300x200.jpg', '', 'Reduced by 3.9% (427 B)', 10389, 10816, '', 10, 0, 1, '2018-08-23 18:28:55', NULL),
(205, 152, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-768x512.jpg', '', 'Reduced by 3.4% (1.5 KB)', 43270, 44809, '', 10, 0, 1, '2018-08-23 18:28:56', NULL),
(206, 152, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-1024x683.jpg', '', 'Reduced by 4.0% (2.9 KB)', 71483, 74458, '', 10, 0, 1, '2018-08-23 18:28:56', NULL),
(207, 152, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-800x600.jpg', '', 'Reduced by 3.1% (1.6 KB)', 52084, 53755, '', 10, 0, 1, '2018-08-23 18:28:57', NULL),
(208, 152, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-300x300.jpg', '', 'Reduced by 2.9% (450 B)', 15169, 15619, '', 10, 0, 1, '2018-08-23 18:28:57', NULL),
(209, 152, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-600x400.jpg', '', 'Reduced by 3.3% (1,003 B)', 29500, 30503, '', 10, 0, 1, '2018-08-23 18:28:58', NULL),
(210, 152, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-100x100.jpg', '', 'Reduced by 11.0% (370 B)', 2992, 3362, '', 10, 0, 1, '2018-08-23 18:28:58', NULL),
(211, 153, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1.jpg', '', 'Reduced by 94.3% (1.3 MB)', 82253, 1440522, '', 10, 0, 1, '2018-08-23 15:29:15', NULL),
(212, 153, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-150x150.jpg', '', 'Reduced by 7.0% (408 B)', 5424, 5832, '', 10, 0, 1, '2018-08-23 18:29:15', NULL),
(213, 153, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-300x200.jpg', '', 'Reduced by 4.8% (546 B)', 10861, 11407, '', 10, 0, 1, '2018-08-23 18:29:16', NULL),
(214, 153, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-768x512.jpg', '', 'Reduced by 3.9% (1.9 KB)', 48408, 50363, '', 10, 0, 1, '2018-08-23 18:29:18', NULL),
(215, 154, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680.jpg', '', 'Reduced by 96.1% (1.6 MB)', 66923, 1725470, '', 10, 0, 1, '2018-08-23 15:29:30', NULL),
(216, 153, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-1024x683.jpg', '', 'Reduced by 4.5% (3.8 KB)', 82231, 86120, '', 10, 0, 1, '2018-08-23 18:29:21', NULL),
(217, 153, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-800x600.jpg', '', 'Reduced by 3.6% (2.1 KB)', 58733, 60916, '', 10, 0, 1, '2018-08-23 18:29:23', NULL),
(218, 153, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-300x300.jpg', '', 'Reduced by 3.7% (634 B)', 16460, 17094, '', 10, 0, 1, '2018-08-23 18:29:24', NULL),
(219, 153, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-600x400.jpg', '', 'Reduced by 3.9% (1.3 KB)', 32482, 33798, '', 10, 0, 1, '2018-08-23 18:29:25', NULL),
(220, 153, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-100x100.jpg', '', 'Reduced by 11.6% (393 B)', 2998, 3391, '', 10, 0, 1, '2018-08-23 18:29:25', NULL),
(221, 154, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-150x150.jpg', '', 'Reduced by 7.1% (387 B)', 5070, 5457, '', 10, 0, 1, '2018-08-23 18:29:30', NULL),
(222, 154, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-300x200.jpg', '', 'Reduced by 4.3% (445 B)', 9853, 10298, '', 10, 0, 1, '2018-08-23 18:29:30', NULL),
(223, 154, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-768x512.jpg', '', 'Reduced by 3.9% (1.6 KB)', 40455, 42095, '', 10, 0, 1, '2018-08-23 18:29:31', NULL),
(224, 155, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045.jpg', '', 'Reduced by 98.7% (2.7 MB)', 37669, 2878336, '', 10, 0, 1, '2018-08-23 15:29:42', NULL),
(225, 154, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-1024x683.jpg', '', 'Reduced by 4.3% (2.9 KB)', 66841, 69847, '', 10, 0, 1, '2018-08-23 18:29:32', NULL),
(226, 154, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-800x600.jpg', '', 'Reduced by 3.6% (1.8 KB)', 47962, 49769, '', 10, 0, 1, '2018-08-23 18:29:32', NULL),
(227, 154, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-300x300.jpg', '', 'Reduced by 3.9% (572 B)', 14038, 14610, '', 10, 0, 1, '2018-08-23 18:29:33', NULL),
(228, 154, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-600x400.jpg', '', 'Reduced by 3.9% (1.1 KB)', 27571, 28692, '', 10, 0, 1, '2018-08-23 18:29:33', NULL),
(229, 154, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-100x100.jpg', '', 'Reduced by 10.9% (359 B)', 2939, 3298, '', 10, 0, 1, '2018-08-23 18:29:33', NULL),
(230, 155, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-150x150.jpg', '', 'Reduced by 7.7% (397 B)', 4751, 5148, '', 10, 0, 1, '2018-08-23 18:29:42', NULL),
(231, 155, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-169x300.jpg', '', 'Reduced by 4.4% (395 B)', 8559, 8954, '', 10, 0, 1, '2018-08-23 18:29:42', NULL),
(232, 155, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-432x600.jpg', '', 'Reduced by 3.4% (1.2 KB)', 33858, 35058, '', 10, 0, 1, '2018-08-23 18:29:43', NULL),
(233, 155, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-300x300.jpg', '', 'Reduced by 3.0% (415 B)', 13422, 13837, '', 10, 0, 1, '2018-08-23 18:29:44', NULL),
(234, 155, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-100x100.jpg', '', 'Reduced by 11.7% (363 B)', 2732, 3095, '', 10, 0, 1, '2018-08-23 18:29:44', NULL),
(235, 156, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090.jpg', '', 'Reduced by 98.1% (4.5 MB)', 91857, 4785919, '', 10, 0, 1, '2018-08-23 15:30:08', NULL),
(236, 156, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-150x150.jpg', '', 'Reduced by 4.8% (430 B)', 8600, 9030, '', 10, 0, 1, '2018-08-23 18:30:08', NULL),
(237, 156, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-169x300.jpg', '', 'Reduced by 7.3% (1.2 KB)', 16234, 17513, '', 10, 0, 1, '2018-08-23 18:30:09', NULL),
(238, 156, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-432x600.jpg', '', 'Reduced by 7.0% (5.6 KB)', 76929, 82693, '', 10, 0, 1, '2018-08-23 18:30:09', NULL);
INSERT INTO `dp_ewwwio_images` (`id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `results`, `image_size`, `orig_size`, `backup`, `level`, `pending`, `updates`, `updated`, `trace`) VALUES
(239, 156, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-300x300.jpg', '', 'Reduced by 7.1% (2.1 KB)', 27733, 29849, '', 10, 0, 1, '2018-08-23 18:30:09', NULL),
(240, 156, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-100x100.jpg', '', 'Reduced by 8.4% (399 B)', 4372, 4771, '', 10, 0, 1, '2018-08-23 18:30:09', NULL),
(241, 157, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1.jpg', '', 'Reduced by 2.1% (1.2 KB)', 58096, 59336, '', 10, 0, 1, '2018-08-23 18:30:14', NULL),
(242, 157, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-150x150.jpg', '', 'Reduced by 6.4% (386 B)', 5667, 6053, '', 10, 0, 1, '2018-08-23 18:30:15', NULL),
(243, 157, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-300x225.jpg', '', 'Reduced by 4.9% (684 B)', 13307, 13991, '', 10, 0, 1, '2018-08-23 18:30:15', NULL),
(244, 157, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-768x576.jpg', '', 'Reduced by 3.4% (2.0 KB)', 58951, 61039, '', 10, 0, 1, '2018-08-23 18:30:16', NULL),
(245, 157, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-1024x768.jpg', '', 'Reduced by 13.8% (11.2 KB)', 71847, 83314, '', 10, 0, 1, '2018-08-23 18:30:17', NULL),
(246, 157, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-800x600.jpg', '', 'Reduced by 3.1% (1.9 KB)', 61743, 63729, '', 10, 0, 1, '2018-08-23 18:30:17', NULL),
(247, 157, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-300x300.jpg', '', 'Reduced by 4.2% (758 B)', 17343, 18101, '', 10, 0, 1, '2018-08-23 18:30:18', NULL),
(248, 157, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-600x450.jpg', '', 'Reduced by 3.8% (1.5 KB)', 40214, 41799, '', 10, 0, 1, '2018-08-23 18:30:18', NULL),
(249, 157, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-100x100.jpg', '', 'Reduced by 11.1% (387 B)', 3099, 3486, '', 10, 0, 1, '2018-08-23 18:30:18', NULL),
(250, 159, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2.jpg', '', 'Reduced by 96.2% (1.7 MB)', 67958, 1810791, '', 10, 0, 1, '2018-08-23 15:39:54', NULL),
(251, 159, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-150x150.jpg', '', 'Reduced by 6.8% (362 B)', 4981, 5343, '', 10, 0, 1, '2018-08-23 18:39:54', NULL),
(252, 159, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-300x200.jpg', '', 'Reduced by 4.0% (397 B)', 9455, 9852, '', 10, 0, 1, '2018-08-23 18:39:54', NULL),
(253, 159, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-768x512.jpg', '', 'Reduced by 5.6% (2.3 KB)', 40082, 42475, '', 10, 0, 1, '2018-08-23 18:39:55', NULL),
(254, 159, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-1024x683.jpg', '', 'Reduced by 6.2% (4.4 KB)', 67937, 72403, '', 10, 0, 1, '2018-08-23 18:39:56', NULL),
(255, 159, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-800x600.jpg', '', 'Reduced by 5.4% (2.6 KB)', 47349, 50027, '', 10, 0, 1, '2018-08-23 18:39:57', NULL),
(256, 159, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-300x300.jpg', '', 'Reduced by 4.4% (634 B)', 13936, 14570, '', 10, 0, 1, '2018-08-23 18:39:58', NULL),
(257, 159, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-600x400.jpg', '', 'Reduced by 5.1% (1.4 KB)', 26668, 28108, '', 10, 0, 1, '2018-08-23 18:39:58', NULL),
(258, 159, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-100x100.jpg', '', 'Reduced by 11.1% (354 B)', 2846, 3200, '', 10, 0, 1, '2018-08-23 18:39:59', NULL),
(259, 161, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5.jpg', '', 'Reduced by 95.9% (1.8 MB)', 80448, 1973963, '', 10, 0, 1, '2018-08-23 15:42:43', NULL),
(260, 161, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-150x150.jpg', '', 'Reduced by 6.0% (352 B)', 5514, 5866, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(261, 161, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-300x200.jpg', '', 'Reduced by 4.5% (490 B)', 10509, 10999, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(262, 161, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-768x512.jpg', '', 'Reduced by 5.1% (2.5 KB)', 46892, 49422, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(263, 161, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-1024x683.jpg', '', 'Reduced by 5.6% (4.7 KB)', 80455, 85237, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(264, 161, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-800x600.jpg', '', 'Reduced by 4.8% (2.8 KB)', 56240, 59067, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(265, 161, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-300x300.jpg', '', 'Reduced by 4.4% (744 B)', 16220, 16964, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(266, 161, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-600x400.jpg', '', 'Reduced by 4.5% (1.4 KB)', 31243, 32717, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(267, 161, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-100x100.jpg', '', 'Reduced by 10.3% (357 B)', 3120, 3477, '', 10, 0, 1, '2018-08-23 18:42:44', NULL),
(268, 163, 'media', 'full', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2.jpg', '', 'Reduced by 95.9% (1.9 MB)', 84282, 2045181, '', 10, 0, 1, '2018-08-23 15:48:48', NULL),
(269, 163, 'media', 'thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-150x150.jpg', '', 'Reduced by 6.3% (375 B)', 5609, 5984, '', 10, 0, 1, '2018-08-23 18:48:49', NULL),
(270, 163, 'media', 'medium', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-300x200.jpg', '', 'Reduced by 5.2% (575 B)', 10463, 11038, '', 10, 0, 1, '2018-08-23 18:48:49', NULL),
(271, 163, 'media', 'medium_large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-768x512.jpg', '', 'Reduced by 6.8% (3.4 KB)', 48032, 51525, '', 10, 0, 1, '2018-08-23 18:48:50', NULL),
(272, 163, 'media', 'large', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-1024x683.jpg', '', 'Reduced by 6.9% (6.1 KB)', 84234, 90496, '', 10, 0, 1, '2018-08-23 18:48:51', NULL),
(273, 163, 'media', 'slideshow', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-800x600.jpg', '', 'Reduced by 6.4% (3.8 KB)', 57174, 61097, '', 10, 0, 1, '2018-08-23 18:48:51', NULL),
(274, 163, 'media', 'woocommerce_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-300x300.jpg', '', 'Reduced by 5.6% (963 B)', 16118, 17081, '', 10, 0, 1, '2018-08-23 18:48:51', NULL),
(275, 163, 'media', 'woocommerce_single', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-600x400.jpg', '', 'Reduced by 6.4% (2.1 KB)', 31763, 33940, '', 10, 0, 1, '2018-08-23 18:48:52', NULL),
(276, 163, 'media', 'woocommerce_gallery_thumbnail', '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-100x100.jpg', '', 'Reduced by 10.8% (359 B)', 2980, 3339, '', 10, 0, 1, '2018-08-23 18:48:52', NULL),
(277, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-200x133.jpg', '', 'Reduced by 5.9% (383 B)', 6150, 6533, '', 10, 0, 1, '2018-08-23 20:23:05', NULL),
(278, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-200x150.jpg', '', 'Reduced by 5.4% (392 B)', 6898, 7290, '', 10, 0, 1, '2018-08-23 20:23:07', NULL),
(279, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-200x356.jpg', '', 'Reduced by 7.1% (1.6 KB)', 21586, 23247, '', 10, 0, 1, '2018-08-23 20:23:09', NULL),
(280, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-200x356.jpg', '', 'Reduced by 3.5% (400 B)', 11051, 11451, '', 10, 0, 1, '2018-08-23 20:23:11', NULL),
(281, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-200x133.jpg', '', 'Reduced by 6.4% (371 B)', 5470, 5841, '', 10, 0, 1, '2018-08-23 20:23:13', NULL),
(282, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-200x133.jpg', '', 'Reduced by 6.2% (388 B)', 5878, 6266, '', 10, 0, 1, '2018-08-23 20:23:16', NULL),
(283, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-200x133.jpg', '', 'Reduced by 6.3% (384 B)', 5699, 6083, '', 10, 0, 1, '2018-08-23 20:23:18', NULL),
(284, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-200x133.jpg', '', 'Reduced by 6.0% (384 B)', 5990, 6374, '', 10, 0, 1, '2018-08-23 20:23:21', NULL),
(285, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-200x200.jpg', '', 'Reduced by 4.1% (372 B)', 8706, 9078, '', 10, 0, 1, '2018-08-23 20:24:18', NULL),
(286, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-200x200.jpg', '', 'Reduced by 4.2% (374 B)', 8615, 8989, '', 10, 0, 1, '2018-08-23 20:24:21', NULL),
(287, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-200x200.jpg', '', 'Reduced by 3.9% (370 B)', 9079, 9449, '', 10, 0, 1, '2018-08-23 20:24:24', NULL),
(288, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-200x200.jpg', '', 'Reduced by 4.9% (392 B)', 7616, 8008, '', 10, 0, 1, '2018-08-23 20:24:26', NULL),
(289, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-200x133.jpg', '', 'Reduced by 6.0% (361 B)', 5606, 5967, '', 10, 0, 1, '2018-08-23 20:25:50', NULL),
(290, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-200x133.jpg', '', 'Reduced by 6.2% (362 B)', 5524, 5886, '', 10, 0, 1, '2018-08-23 20:25:59', NULL),
(291, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-200x133.jpg', '', 'Reduced by 6.5% (357 B)', 5145, 5502, '', 10, 0, 1, '2018-08-23 20:26:11', NULL),
(292, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-200x133.jpg', '', 'Reduced by 5.6% (359 B)', 6097, 6456, '', 10, 0, 1, '2018-08-23 20:27:18', NULL),
(293, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-200x113.jpg', '', 'Reduced by 4.1% (369 B)', 8559, 8928, '', 10, 0, 1, '2018-08-23 20:27:30', NULL),
(294, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-200x342.jpg', '', 'Reduced by 3.9% (535 B)', 13062, 13597, '', 10, 0, 1, '2018-08-23 20:34:01', NULL),
(295, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-200x113.jpg', '', 'Reduced by 5.9% (352 B)', 5645, 5997, '', 10, 0, 1, '2018-08-23 20:34:16', NULL),
(296, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-200x113.jpg', '', 'Reduced by 8.3% (361 B)', 3971, 4332, '', 10, 0, 1, '2018-08-23 20:34:33', NULL),
(297, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-200x113.jpg', '', 'Reduced by 8.5% (347 B)', 3740, 4087, '', 10, 0, 1, '2018-08-23 20:34:49', NULL),
(298, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-200x113.jpg', '', 'Reduced by 7.4% (340 B)', 4228, 4568, '', 10, 0, 1, '2018-08-23 20:35:02', NULL),
(299, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-200x133.jpg', '', 'Reduced by 6.3% (381 B)', 5712, 6093, '', 10, 0, 1, '2018-08-23 20:35:16', NULL),
(300, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-200x133.jpg', '', 'Reduced by 6.2% (388 B)', 5878, 6266, '', 10, 0, 1, '2018-08-23 20:35:26', NULL),
(301, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-200x133.jpg', '', 'Reduced by 5.8% (368 B)', 6017, 6385, '', 10, 0, 1, '2018-08-23 20:35:45', NULL),
(302, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-200x150.jpg', '', 'Reduced by 5.9% (359 B)', 5705, 6064, '', 10, 0, 1, '2018-08-23 20:36:48', NULL),
(303, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-200x150.jpg', '', 'Reduced by 6.5% (747 B)', 10710, 11457, '', 10, 0, 1, '2018-08-23 20:37:04', NULL),
(304, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL5-400x267.jpg', '', 'Reduced by 4.5% (751 B)', 16047, 16798, '', 10, 0, 1, '2018-08-23 20:38:03', NULL),
(305, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL4_2-400x267.jpg', '', 'Reduced by 4.6% (691 B)', 14443, 15134, '', 10, 0, 1, '2018-08-23 20:38:17', NULL),
(306, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-1-400x300.jpg', '', 'Reduced by 4.1% (881 B)', 20861, 21742, '', 10, 0, 1, '2018-08-23 20:38:33', NULL),
(307, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3090-400x711.jpg', '', 'Reduced by 6.2% (4.5 KB)', 70744, 75398, '', 10, 0, 1, '2018-08-23 20:38:44', NULL),
(308, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3045-400x711.jpg', '', 'Reduced by 3.2% (1,013 B)', 31083, 32096, '', 10, 0, 1, '2018-08-23 20:38:49', NULL),
(309, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6680-400x267.jpg', '', 'Reduced by 3.8% (596 B)', 15041, 15637, '', 10, 0, 1, '2018-08-23 20:39:05', NULL),
(310, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-1-400x267.jpg', '', 'Reduced by 4.0% (716 B)', 17188, 17904, '', 10, 0, 1, '2018-08-23 20:39:13', NULL),
(311, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6676-400x267.jpg', '', 'Reduced by 2.9% (483 B)', 16104, 16587, '', 10, 0, 1, '2018-08-23 20:39:35', NULL),
(312, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6670-400x267.jpg', '', 'Reduced by 3.6% (598 B)', 16149, 16747, '', 10, 0, 1, '2018-08-23 20:39:41', NULL),
(313, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3_2-400x600.jpg', '', 'Reduced by 4.7% (1.5 KB)', 30695, 32196, '', 10, 0, 1, '2018-08-23 20:40:07', NULL),
(314, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_ANUAL3-400x267.jpg', '', 'Reduced by 4.5% (833 B)', 17739, 18572, '', 10, 0, 1, '2018-08-23 20:40:17', NULL),
(315, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3105-400x225.jpg', '', 'Reduced by 7.1% (2.2 KB)', 30214, 32512, '', 10, 0, 1, '2018-08-23 20:40:49', NULL),
(316, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3064-400x684.jpg', '', 'Reduced by 2.7% (1,017 B)', 37077, 38094, '', 10, 0, 1, '2018-08-23 20:41:05', NULL),
(317, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_3014-400x225.jpg', '', 'Reduced by 4.7% (790 B)', 15845, 16635, '', 10, 0, 1, '2018-08-23 20:41:09', NULL),
(318, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2991-400x225.jpg', '', 'Reduced by 4.9% (579 B)', 11224, 11803, '', 10, 0, 1, '2018-08-23 20:41:23', NULL),
(319, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2990-400x225.jpg', '', 'Reduced by 4.7% (516 B)', 10566, 11082, '', 10, 0, 1, '2018-08-23 20:41:38', NULL),
(320, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/DSC_2989-400x225.jpg', '', 'Reduced by 3.7% (484 B)', 12563, 13047, '', 10, 0, 1, '2018-08-23 20:41:50', NULL),
(321, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6674-400x267.jpg', '', 'Reduced by 4.0% (663 B)', 15915, 16578, '', 10, 0, 1, '2018-08-23 20:42:06', NULL),
(322, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6677-400x267.jpg', '', 'Reduced by 4.0% (716 B)', 17188, 17904, '', 10, 0, 1, '2018-08-23 20:42:27', NULL),
(323, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6684-400x267.jpg', '', 'Reduced by 3.8% (663 B)', 16591, 17254, '', 10, 0, 1, '2018-08-23 20:42:49', NULL),
(324, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/MG_6613-400x267.jpg', '', 'Reduced by 4.6% (822 B)', 16930, 17752, '', 10, 0, 1, '2018-08-23 20:43:10', NULL),
(325, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria3-400x300.jpg', '', 'Reduced by 5.2% (924 B)', 16865, 17789, '', 10, 0, 1, '2018-08-23 20:43:18', NULL),
(326, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria2-400x300.jpg', '', 'Reduced by 5.6% (1.9 KB)', 32686, 34626, '', 10, 0, 1, '2018-08-23 20:43:20', NULL),
(327, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/galeria1-400x300.jpg', '', 'Reduced by 4.1% (881 B)', 20861, 21742, '', 10, 0, 1, '2018-08-23 20:43:22', NULL),
(328, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog2-400x300.jpg', '', 'Reduced by 5.1% (914 B)', 17076, 17990, '', 10, 0, 1, '2018-08-23 20:43:34', NULL),
(329, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/blog1-400x300.jpg', '', 'Reduced by 5.0% (1.4 KB)', 27455, 28885, '', 10, 0, 1, '2018-08-23 20:43:36', NULL),
(330, NULL, NULL, NULL, '/home/feg7mariana/public_html/wp-content/uploads/2018/08/planificador_RECETAS2-400x267.jpg', '', 'Reduced by 5.6% (972 B)', 16274, 17246, '', 10, 0, 1, '2018-08-23 20:45:06', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_links`
--

CREATE TABLE `dp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_options`
--

CREATE TABLE `dp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_options`
--

INSERT INTO `dp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888', 'yes'),
(2, 'home', 'http://localhost:8888', 'yes'),
(3, 'blogname', 'De Papel Tienda', 'yes'),
(4, 'blogdescription', 'Otro sitio de WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mariana.j.ambrosetti@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:36:\"contact-form-7/wp-contact-form-7.php\";i:1;s:25:\"duplicator/duplicator.php\";i:2;s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";i:3;s:47:\"show-current-template/show-current-template.php\";i:5;s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";i:6;s:27:\"woocommerce/woocommerce.php\";i:7;s:24:\"wordpress-seo/wp-seo.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:103:\"C:\\Users\\maria\\Desktop\\Proyecto_Final\\De_papel_Tienda\\WP-Depapel/wp-content/plugins/akismet/akismet.php\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'depapel-theme', 'yes'),
(41, 'stylesheet', 'depapel-theme', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:1:{s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:30:\"ewww_image_optimizer_uninstall\";}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'dp_user_roles', 'a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'WPLANG', 'es_ES', 'yes'),
(97, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'sidebars_widgets', 'a:5:{s:10:\"categorias\";a:1:{i:0;s:32:\"woocommerce_product_categories-2\";}s:19:\"wp_inactive_widgets\";a:6:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:8:\"search-2\";i:3;s:12:\"categories-2\";i:4;s:14:\"recent-posts-2\";i:5;s:17:\"recent-comments-2\";}s:14:\"contact_widget\";a:0:{}s:14:\"sidebar_widget\";a:1:{i:0;s:32:\"woocommerce_product_categories-3\";}s:13:\"array_version\";i:3;}', 'yes'),
(103, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'cron', 'a:16:{i:1535578113;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1535578432;a:1:{s:21:\"wordfence_hourly_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1535578732;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1535585932;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535587200;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535589699;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535596732;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1535606913;a:2:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1535606914;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1535650280;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535650355;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535650432;a:1:{s:20:\"wordfence_daily_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535661532;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1535661542;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1536019200;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}', 'yes'),
(113, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1533836660;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(126, 'can_compress_scripts', '0', 'no'),
(141, 'dismissed_update_core', 'a:1:{s:11:\"4.9.8|es_CL\";b:1;}', 'no'),
(143, 'core_updater.lock', '1533836011', 'no'),
(151, 'current_theme', 'Desafío Latam', 'yes'),
(152, 'theme_mods_depapel-theme', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:20;}s:18:\"custom_css_post_id\";i:54;}', 'yes'),
(153, 'theme_switched', '', 'yes'),
(154, 'page_navigation', 'a:6:{s:10:\"first_text\";s:14:\"&laquo; Inicio\";s:9:\"last_text\";s:11:\"Fin &raquo;\";s:9:\"prev_text\";s:7:\"&laquo;\";s:9:\"next_text\";s:7:\"&raquo;\";s:5:\"style\";s:7:\"default\";s:5:\"align\";s:4:\"left\";}', 'yes'),
(220, 'recently_activated', 'a:1:{s:63:\"woo-related-products-refresh-on-reload/woo-related-products.php\";i:1535055260;}', 'yes'),
(331, '_transient_woocommerce_webhook_ids', 'a:0:{}', 'yes'),
(345, '_transient_wc_attribute_taxonomies', 'a:0:{}', 'yes'),
(346, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(369, 'default_product_cat', '26', 'yes'),
(415, 'ewww_image_optimizer_background_optimization', '1', 'yes'),
(419, 'ewww_image_optimizer_disable_pngout', '1', 'no'),
(420, 'ewww_image_optimizer_optipng_level', '2', 'no'),
(421, 'ewww_image_optimizer_pngout_level', '2', 'no'),
(422, 'ewww_image_optimizer_jpegtran_copy', '1', 'no'),
(423, 'ewww_image_optimizer_jpg_level', '10', 'no'),
(424, 'ewww_image_optimizer_png_level', '10', 'no'),
(425, 'ewww_image_optimizer_gif_level', '10', 'no'),
(426, 'ewww_image_optimizer_pdf_level', '0', 'no'),
(427, 'exactdn_all_the_things', '1', 'no'),
(428, 'ewww_image_optimizer_version', '432.0', 'yes'),
(429, 'ewww_image_optimizer_tracking_notice', '1', 'yes'),
(432, 'widget_akismet_widget', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(437, 'wpseo', 'a:19:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:3:\"8.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1534354279;}', 'yes'),
(438, 'wpseo_titles', 'a:90:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:41:\"%%name%%, Author at %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:63:\"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:35:\"Page not found %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:53:\"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:25:\"Error 404: Page not found\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:12:\"Archives for\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:4:\"Home\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:16:\"You searched for\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:0:\"\";s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:13:\"title-product\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:16:\"metadesc-product\";s:0:\"\";s:15:\"noindex-product\";b:0;s:16:\"showdate-product\";b:0;s:26:\"display-metabox-pt-product\";b:1;s:23:\"title-ptarchive-product\";s:51:\"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%\";s:26:\"metadesc-ptarchive-product\";s:0:\"\";s:25:\"bctitle-ptarchive-product\";s:0:\"\";s:25:\"noindex-ptarchive-product\";b:0;s:18:\"title-tax-category\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;s:21:\"title-tax-product_cat\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_cat\";s:0:\"\";s:31:\"display-metabox-tax-product_cat\";b:1;s:23:\"noindex-tax-product_cat\";b:0;s:21:\"title-tax-product_tag\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-product_tag\";s:0:\"\";s:31:\"display-metabox-tax-product_tag\";b:1;s:23:\"noindex-tax-product_tag\";b:0;s:32:\"title-tax-product_shipping_class\";s:53:\"%%term_title%% Archives %%page%% %%sep%% %%sitename%%\";s:35:\"metadesc-tax-product_shipping_class\";s:0:\"\";s:42:\"display-metabox-tax-product_shipping_class\";b:1;s:34:\"noindex-tax-product_shipping_class\";b:0;s:23:\"post_types-post-maintax\";i:0;s:26:\"post_types-product-maintax\";i:0;s:29:\"taxonomy-product_cat-ptparent\";i:0;s:29:\"taxonomy-product_tag-ptparent\";i:0;s:40:\"taxonomy-product_shipping_class-ptparent\";i:0;}', 'yes'),
(439, 'wpseo_social', 'a:18:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:14:\"plus-publisher\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:15:\"google_plus_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}', 'yes'),
(440, 'wpseo_flush_rewrite', '1', 'yes'),
(441, '_transient_timeout_wpseo_link_table_inaccessible', '1565890280', 'no'),
(442, '_transient_wpseo_link_table_inaccessible', '0', 'no'),
(443, '_transient_timeout_wpseo_meta_table_inaccessible', '1565890280', 'no'),
(444, '_transient_wpseo_meta_table_inaccessible', '0', 'no'),
(449, 'wordfence_version', '7.1.10', 'yes'),
(450, 'wordfence_installed', '1', 'yes'),
(451, 'wordfenceActivated', '1', 'yes'),
(473, 'duplicator_settings', 'a:10:{s:7:\"version\";s:6:\"1.2.42\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}', 'yes'),
(474, 'duplicator_version_plugin', '1.2.42', 'yes'),
(482, '_transient_shipping-transient-version', '1534965773', 'yes'),
(493, 'wpseo_sitemap_1_cache_validator', '6qUkj', 'no'),
(494, 'wpseo_sitemap_page_cache_validator', '6qUlr', 'no'),
(503, 'wc_ppec_version', '1.6.3', 'yes'),
(515, '_transient_timeout_wc_shipping_method_count_0_1534357142', '1536967977', 'no'),
(516, '_transient_wc_shipping_method_count_0_1534357142', '0', 'no'),
(529, '_transient_timeout_wc_shipping_method_count_0_1534378925', '1536970975', 'no'),
(530, '_transient_wc_shipping_method_count_0_1534378925', '0', 'no'),
(536, '_transient_timeout_wc_shipping_method_count_0_1534379350', '1536971424', 'no'),
(537, '_transient_wc_shipping_method_count_0_1534379350', '0', 'no'),
(549, '_transient_timeout_wc_shipping_method_count_1_1534379350', '1536972055', 'no'),
(550, '_transient_wc_shipping_method_count_1_1534379350', '0', 'no'),
(558, 'wc_gateway_ppec_prompt_to_connect_message_dismissed', 'yes', 'yes'),
(568, '_transient_product_query-transient-version', '1535039361', 'yes'),
(569, 'wpseo_sitemap_product_cache_validator', '57X8X', 'no'),
(572, 'wpseo_sitemap_product_cat_cache_validator', '57X8R', 'no'),
(576, 'wpseo_taxonomy_meta', 'a:1:{s:11:\"product_cat\";a:5:{i:16;a:3:{s:13:\"wpseo_focuskw\";s:11:\"Disponibles\";s:13:\"wpseo_linkdex\";s:2:\"11\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:17;a:3:{s:13:\"wpseo_focuskw\";s:14:\"Personalizados\";s:13:\"wpseo_linkdex\";s:2:\"11\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:18;a:3:{s:13:\"wpseo_focuskw\";s:13:\"Profesionales\";s:13:\"wpseo_linkdex\";s:2:\"11\";s:19:\"wpseo_content_score\";s:2:\"30\";}i:27;a:3:{s:13:\"wpseo_focuskw\";s:14:\"Planificadores\";s:13:\"wpseo_linkdex\";s:2:\"15\";s:19:\"wpseo_content_score\";s:2:\"60\";}i:31;a:3:{s:13:\"wpseo_focuskw\";s:21:\"Profesiones / Oficios\";s:13:\"wpseo_linkdex\";s:3:\"-20\";s:19:\"wpseo_content_score\";s:2:\"30\";}}}', 'yes'),
(582, 'wpseo_sitemap_shop_coupon_cache_validator', 'iHOa', 'no'),
(592, 'wpseo_sitemap_nav_menu_item_cache_validator', '2i4BM', 'no'),
(593, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(605, 'wpseo_sitemap_post_cache_validator', '5EOdJ', 'no'),
(692, 'wpseo_sitemap_category_cache_validator', 'AbV4', 'no'),
(697, 'category_children', 'a:0:{}', 'yes'),
(703, 'ewww_image_optimizer_cloud_key', '', 'yes'),
(704, 'ewww_image_optimizer_jpg_quality', '', 'yes'),
(705, 'ewww_image_optimizer_aux_paths', '', 'yes'),
(706, 'ewww_image_optimizer_exclude_paths', '', 'yes'),
(707, 'ewww_image_optimizer_allow_tracking', '', 'yes'),
(708, 'ewww_image_optimizer_maxmediawidth', '1024', 'yes'),
(709, 'ewww_image_optimizer_maxmediaheight', '768', 'yes'),
(710, 'ewww_image_optimizer_resize_existing', '1', 'yes'),
(711, 'ewww_image_optimizer_disable_resizes', '', 'yes'),
(712, 'ewww_image_optimizer_disable_resizes_opt', '', 'yes'),
(713, 'ewww_image_optimizer_jpg_background', '', 'yes'),
(714, 'ewww_image_optimizer_webp_paths', '', 'yes'),
(725, 'wp_ewwwio_media_optimize_batch_a', '', 'no'),
(731, 'wpseo_sitemap_attachment_cache_validator', '57I96', 'no'),
(732, 'wpseo_sitemap_46_cache_validator', '6L1g4', 'no'),
(741, 'wp_ewwwio_media_optimize_batch_b', '', 'no'),
(794, 'wpseo_sitemap_custom_css_cache_validator', '5Xb5E', 'no'),
(795, 'wpseo_sitemap_customize_changeset_cache_validator', '5Xb6w', 'no'),
(889, '_transient_product-transient-version', '1535039361', 'yes'),
(892, '_transient_orders-transient-version', '1534959684', 'yes'),
(893, '_transient_timeout_wc_cbp_c93ef27882930ffa2219d39d6d9effed', '1537551684', 'no'),
(894, '_transient_wc_cbp_c93ef27882930ffa2219d39d6d9effed', 'a:0:{}', 'no'),
(909, 'wpseo_sitemap_66_cache_validator', '5Hx2R', 'no'),
(957, 'woocommerce_store_address', 'Jackson 867, Torre z, departamento 206, quinta claude', 'yes'),
(958, 'woocommerce_store_address_2', '', 'yes'),
(959, 'woocommerce_store_city', 'Viña del Mar', 'yes'),
(960, 'woocommerce_default_country', 'CL', 'yes'),
(961, 'woocommerce_store_postcode', '2520000', 'yes'),
(962, 'woocommerce_allowed_countries', 'specific', 'yes'),
(963, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(964, 'woocommerce_specific_allowed_countries', 'a:1:{i:0;s:2:\"CL\";}', 'yes'),
(965, 'woocommerce_ship_to_countries', 'specific', 'yes'),
(966, 'woocommerce_specific_ship_to_countries', 'a:1:{i:0;s:2:\"CL\";}', 'yes'),
(967, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(968, 'woocommerce_calc_taxes', 'yes', 'yes'),
(969, 'woocommerce_enable_coupons', 'yes', 'yes'),
(970, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(971, 'woocommerce_currency', 'CLP', 'yes'),
(972, 'woocommerce_currency_pos', 'left', 'yes'),
(973, 'woocommerce_price_thousand_sep', ',', 'yes'),
(974, 'woocommerce_price_decimal_sep', '.', 'yes'),
(975, 'woocommerce_price_num_decimals', '3', 'yes'),
(976, 'woocommerce_shop_page_id', '70', 'yes'),
(977, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(978, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(979, 'woocommerce_weight_unit', 'kg', 'yes'),
(980, 'woocommerce_dimension_unit', 'cm', 'yes'),
(981, 'woocommerce_enable_reviews', 'no', 'yes'),
(982, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(983, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(984, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(985, 'woocommerce_review_rating_required', 'yes', 'no'),
(986, 'woocommerce_manage_stock', 'yes', 'yes'),
(987, 'woocommerce_hold_stock_minutes', '60', 'no'),
(988, 'woocommerce_notify_low_stock', 'yes', 'no'),
(989, 'woocommerce_notify_no_stock', 'yes', 'no'),
(990, 'woocommerce_stock_email_recipient', 'mariana.j.ambrosetti@gmail.com', 'no'),
(991, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(992, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(993, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(994, 'woocommerce_stock_format', '', 'yes'),
(995, 'woocommerce_file_download_method', 'force', 'no'),
(996, 'woocommerce_downloads_require_login', 'yes', 'no'),
(997, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(998, 'woocommerce_prices_include_tax', 'yes', 'yes'),
(999, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(1000, 'woocommerce_shipping_tax_class', '', 'yes'),
(1001, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(1002, 'woocommerce_tax_classes', 'Reduced rate\r\nZero rate', 'yes'),
(1003, 'woocommerce_tax_display_shop', 'incl', 'yes'),
(1004, 'woocommerce_tax_display_cart', 'incl', 'yes'),
(1005, 'woocommerce_price_display_suffix', 'IVA incluído', 'yes'),
(1006, 'woocommerce_tax_total_display', 'itemized', 'no'),
(1007, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(1008, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(1009, 'woocommerce_ship_to_destination', 'billing', 'no'),
(1010, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(1011, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(1012, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(1013, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(1014, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(1015, 'woocommerce_registration_generate_username', 'yes', 'no'),
(1016, 'woocommerce_registration_generate_password', 'yes', 'no'),
(1017, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(1018, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(1019, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(1020, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(1021, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(1022, 'woocommerce_trash_pending_orders', '', 'no'),
(1023, 'woocommerce_trash_failed_orders', '', 'no'),
(1024, 'woocommerce_trash_cancelled_orders', '', 'no'),
(1025, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(1026, 'woocommerce_email_from_name', 'De Papel Tienda', 'no'),
(1027, 'woocommerce_email_from_address', 'mariana.j.ambrosetti@gmail.com', 'no'),
(1028, 'woocommerce_email_header_image', '', 'no'),
(1029, 'woocommerce_email_footer_text', '{site_title}', 'no'),
(1030, 'woocommerce_email_base_color', '#96588a', 'no'),
(1031, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(1032, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(1033, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(1034, 'woocommerce_cart_page_id', '6', 'yes'),
(1035, 'woocommerce_checkout_page_id', '7', 'yes'),
(1036, 'woocommerce_myaccount_page_id', '8', 'yes'),
(1037, 'woocommerce_terms_page_id', '13', 'no'),
(1038, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(1039, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(1040, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(1041, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(1042, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(1043, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(1044, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(1045, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(1046, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(1047, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(1048, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(1049, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(1050, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(1051, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(1052, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(1053, 'woocommerce_api_enabled', 'no', 'yes'),
(1054, 'woocommerce_single_image_width', '400', 'yes'),
(1055, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(1056, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(1057, 'woocommerce_demo_store', 'no', 'no'),
(1058, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:19:\"/shop/%product_cat%\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:1;}', 'yes'),
(1064, 'woocommerce_admin_notices', 'a:1:{i:0;s:20:\"no_secure_connection\";}', 'yes'),
(1065, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1066, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1067, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1068, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1069, 'widget_woocommerce_product_categories', 'a:3:{i:2;a:8:{s:5:\"title\";s:10:\"Categorias\";s:7:\"orderby\";s:5:\"order\";s:8:\"dropdown\";i:0;s:5:\"count\";i:0;s:12:\"hierarchical\";i:1;s:18:\"show_children_only\";i:0;s:10:\"hide_empty\";i:0;s:9:\"max_depth\";s:0:\"\";}i:3;a:8:{s:5:\"title\";s:0:\"\";s:7:\"orderby\";s:4:\"name\";s:8:\"dropdown\";i:0;s:5:\"count\";i:1;s:12:\"hierarchical\";i:1;s:18:\"show_children_only\";i:0;s:10:\"hide_empty\";i:1;s:9:\"max_depth\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(1070, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1071, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1072, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1073, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1074, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1075, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1076, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1078, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(1083, 'woocommerce_product_type', 'both', 'yes'),
(1084, 'woocommerce_allow_tracking', 'yes', 'yes'),
(1087, 'woocommerce_ppec_paypal_settings', 'a:2:{s:16:\"reroute_requests\";b:0;s:5:\"email\";s:30:\"mariana.j.ambrosetti@gmail.com\";}', 'yes'),
(1088, 'woocommerce_cheque_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(1089, 'woocommerce_bacs_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(1090, 'woocommerce_cod_settings', 'a:1:{s:7:\"enabled\";s:2:\"no\";}', 'yes'),
(1091, 'woocommerce_tracker_last_send', '1535572726', 'yes'),
(1096, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(1097, 'wpseo_sitemap_cache_validator_global', '6lslm', 'no'),
(1108, 'wpseo_sitemap_author_cache_validator', '619gG', 'no'),
(1118, '_transient_timeout_wc_shipping_method_count_0_1534965773', '1537557810', 'no'),
(1119, '_transient_wc_shipping_method_count_0_1534965773', '0', 'no'),
(1120, 'woocommerce_gateway_order', 'a:5:{s:11:\"ppec_paypal\";i:0;s:4:\"bacs\";i:1;s:6:\"cheque\";i:2;s:3:\"cod\";i:3;s:6:\"paypal\";i:4;}', 'yes'),
(1126, 'wpseo_sitemap_36_cache_validator', '478w', 'no'),
(1127, 'wpseo_sitemap_37_cache_validator', 'w1et', 'no'),
(1128, 'wpseo_sitemap_38_cache_validator', '663ah', 'no'),
(1129, 'wpseo_sitemap_41_cache_validator', '663aJ', 'no'),
(1146, 'woocommerce_default_catalog_orderby', 'price', 'yes'),
(1147, 'woocommerce_catalog_columns', '6', 'yes'),
(1148, 'woocommerce_maybe_regenerate_images_hash', 'a672f1f46ff66b011d20917e81c1d892', 'yes'),
(1181, '_transient_timeout_wc_shipping_method_count_1_1534965773', '1537558820', 'no'),
(1183, '_transient_wc_shipping_method_count_1_1534965773', '0', 'no'),
(1195, 'woosidebars-version', '1.4.5', 'yes'),
(1196, 'wpseo_sitemap_sidebar_cache_validator', 'xl2S', 'no'),
(1210, 'wpseo_sitemap_71_cache_validator', '6ch6a', 'no'),
(1226, 'product_cat_children', 'a:1:{i:27;a:3:{i:0;i:28;i:1;i:30;i:2;i:31;}}', 'yes'),
(1254, 'wpseo_sitemap_33_cache_validator', '6YaDV', 'no'),
(1257, '_transient_timeout_external_ip_address_191.119.65.179', '1535585691', 'no'),
(1258, '_transient_external_ip_address_191.119.65.179', '186.64.118.50', 'no'),
(1260, '_transient_timeout_external_ip_address_200.104.60.90', '1535587214', 'no'),
(1261, '_transient_external_ip_address_200.104.60.90', '186.64.118.50', 'no'),
(1292, '_transient_timeout_external_ip_address_66.102.8.38', '1535635649', 'no'),
(1293, '_transient_external_ip_address_66.102.8.38', '186.64.118.50', 'no'),
(1298, '_transient_timeout_external_ip_address_66.102.8.40', '1535635660', 'no'),
(1299, '_transient_external_ip_address_66.102.8.40', '186.64.118.50', 'no'),
(1300, '_transient_timeout_external_ip_address_201.239.23.96', '1535638235', 'no'),
(1301, '_transient_external_ip_address_201.239.23.96', '186.64.118.50', 'no'),
(1304, 'woocommerce_tracker_ua', 'a:1:{i:0;s:131:\"mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/67.0.3396.87 safari/537.36 opr/54.0.2952.64\";}', 'yes'),
(1401, 'wpseo_sitemap_158_cache_validator', '56AHV', 'no'),
(1413, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(1414, '_transient_timeout_wc_term_counts', '1537631506', 'no'),
(1415, '_transient_wc_term_counts', 'a:3:{i:28;s:1:\"4\";i:30;s:1:\"1\";i:27;s:1:\"5\";}', 'no'),
(1433, '_transient_timeout_wc_low_stock_count', '1537633065', 'no'),
(1434, '_transient_wc_low_stock_count', '5', 'no'),
(1435, '_transient_timeout_wc_outofstock_count', '1537633065', 'no'),
(1436, '_transient_wc_outofstock_count', '0', 'no'),
(1815, '_transient_timeout_external_ip_address_168.196.201.225', '1535651364', 'no'),
(1816, '_transient_external_ip_address_168.196.201.225', '186.64.118.50', 'no'),
(1843, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.0.3\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1535051802;s:7:\"version\";s:5:\"5.0.3\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(1844, 'wpseo_sitemap_wpcf7_contact_form_cache_validator', '63gSE', 'no'),
(1877, '_transient_timeout_wc_addons_sections', '1535659264', 'no'),
(1878, '_transient_wc_addons_sections', 'a:9:{i:0;O:8:\"stdClass\":2:{s:4:\"slug\";s:9:\"_featured\";s:5:\"label\";s:8:\"Featured\";}i:1;O:8:\"stdClass\":2:{s:4:\"slug\";s:4:\"_all\";s:5:\"label\";s:3:\"All\";}i:2;O:8:\"stdClass\":2:{s:4:\"slug\";s:7:\"bundles\";s:5:\"label\";s:7:\"Bundles\";}i:3;O:8:\"stdClass\":2:{s:4:\"slug\";s:18:\"product-extensions\";s:5:\"label\";s:12:\"Enhancements\";}i:4;O:8:\"stdClass\":2:{s:4:\"slug\";s:20:\"marketing-extensions\";s:5:\"label\";s:9:\"Marketing\";}i:5;O:8:\"stdClass\":2:{s:4:\"slug\";s:16:\"payment-gateways\";s:5:\"label\";s:8:\"Payments\";}i:6;O:8:\"stdClass\":2:{s:4:\"slug\";s:12:\"product-type\";s:5:\"label\";s:12:\"Product Type\";}i:7;O:8:\"stdClass\":2:{s:4:\"slug\";s:16:\"shipping-methods\";s:5:\"label\";s:8:\"Shipping\";}i:8;O:8:\"stdClass\":2:{s:4:\"slug\";s:10:\"operations\";s:5:\"label\";s:16:\"Store Management\";}}', 'no'),
(1879, '_transient_timeout_wc_addons_featured', '1535659265', 'no');
INSERT INTO `dp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1880, '_transient_wc_addons_featured', 'O:8:\"stdClass\":1:{s:8:\"sections\";a:11:{i:0;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"banner_block\";s:5:\"title\";s:50:\"Take your store beyond the typical - sell anything\";s:11:\"description\";s:81:\"From services to content, there\'s no limit to what you can sell with WooCommerce.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:139:\"https://woocommerce.com/products/woocommerce-subscriptions/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:13:\"Subscriptions\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/subscriptions-icon@2x.png\";s:11:\"description\";s:98:\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\";s:6:\"button\";s:10:\"From: $199\";s:6:\"plugin\";s:55:\"woocommerce-subscriptions/woocommerce-subscriptions.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:134:\"https://woocommerce.com/products/woocommerce-bookings/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:8:\"Bookings\";s:5:\"image\";s:66:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/bookings-icon@2x.png\";s:11:\"description\";s:76:\"Allow customers to book appointments for services without leaving your site.\";s:6:\"button\";s:10:\"From: $249\";s:6:\"plugin\";s:45:\"woocommerce-bookings/woocommerce-bookings.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:137:\"https://woocommerce.com/products/woocommerce-memberships/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:11:\"Memberships\";s:5:\"image\";s:69:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/memberships-icon@2x.png\";s:11:\"description\";s:76:\"Give members access to restricted content or products, for a fee or for free\";s:6:\"button\";s:10:\"From: $149\";s:6:\"plugin\";s:51:\"woocommerce-memberships/woocommerce-memberships.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:129:\"https://woocommerce.com/products/product-bundles/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:15:\"Product Bundles\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:50:\"Offer customizable bundles and assembled products.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:59:\"woocommerce-product-bundles/woocommerce-product-bundles.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:132:\"https://woocommerce.com/products/composite-products/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:18:\"Composite Products\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:59:\"Create and offer product kits with configurable components.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:65:\"woocommerce-composite-products/woocommerce-composite-products.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:129:\"https://woocommerce.com/products/product-vendors/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:15:\"Product Vendors\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:47:\"Turn your store into a multi-vendor marketplace\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:59:\"woocommerce-product-vendors/woocommerce-product-vendors.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:132:\"https://woocommerce.com/products/groups-woocommerce/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:22:\"Groups for WooCommerce\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:94:\"Sell memberships using the free &#039;Groups&#039; plugin, Groups integration and WooCommerce.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:41:\"groups-woocommerce/groups-woocommerce.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:136:\"https://woocommerce.com/products/woocommerce-pre-orders/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:22:\"WooCommerce Pre-Orders\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:60:\"Allow customers to order products before they are available.\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:49:\"woocommerce-pre-orders/woocommerce-pre-orders.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:130:\"https://woocommerce.com/products/chained-products/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:16:\"Chained Products\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:69:\"Create and sell pre-configured product bundles and discounted combos.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-chained-products/woocommerce-chained-products.php\";}}}i:1;O:8:\"stdClass\":1:{s:6:\"module\";s:16:\"wcs_banner_block\";}i:2;O:8:\"stdClass\":2:{s:6:\"module\";s:12:\"column_start\";s:9:\"container\";s:22:\"column_container_start\";}i:3;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"column_block\";s:5:\"title\";s:46:\"Improve the main features of your online store\";s:11:\"description\";s:71:\"Sell more by helping customers find the products and options they want.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:129:\"https://woocommerce.com/products/product-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:15:\"Product Add-ons\";s:5:\"image\";s:73:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/product-add-ons-icon@2x.png\";s:11:\"description\";s:82:\"Give your customers the option to customize their purchase or add personalization.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:57:\"woocommerce-product-addons/woocommerce-product-addons.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:140:\"https://woocommerce.com/products/woocommerce-product-search/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:14:\"Product Search\";s:5:\"image\";s:72:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/product-search-icon@2x.png\";s:11:\"description\";s:67:\"Make sure customers find what they want when they search your site.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:57:\"woocommerce-product-search/woocommerce-product-search.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:142:\"https://woocommerce.com/products/woocommerce-checkout-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:16:\"Checkout Add-ons\";s:5:\"image\";s:74:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/checkout-add-ons-icon@2x.png\";s:11:\"description\";s:89:\"Highlight relevant products, offers like free shipping and other upsells during checkout.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-checkout-add-ons/woocommerce-checkout-add-ons.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:147:\"https://woocommerce.com/products/woocommerce-checkout-field-editor/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:21:\"Checkout Field Editor\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:128:\"The checkout field editor provides you with an interface to add, edit and remove fields shown on your WooCommerce checkout page.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:71:\"woocommerce-checkout-field-editor/woocommerce-checkout-field-editor.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:138:\"https://woocommerce.com/products/woocommerce-social-login/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:24:\"WooCommerce Social Login\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:62:\"Enable Social Login for Seamless Checkout and Account Creation\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:53:\"woocommerce-social-login/woocommerce-social-login.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:135:\"https://woocommerce.com/products/woocommerce-wishlists/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:21:\"WooCommerce Wishlists\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:113:\"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:47:\"woocommerce-wishlists/woocommerce-wishlists.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/cart-notices/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:12:\"Cart Notices\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:73:\"Display dynamic, actionable messages to your customers as they check out.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:53:\"woocommerce-cart-notices/woocommerce-cart-notices.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/cart-add-ons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:12:\"Cart Add-ons\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:109:\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:53:\"woocommerce-cart-add-ons/woocommerce-cart-add-ons.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:134:\"https://woocommerce.com/products/woocommerce-waitlist/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:20:\"WooCommerce Waitlist\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:117:\"With WooCommerce Waitlist customers can register for email notifications when out-of-stock products become available.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:45:\"woocommerce-waitlist/woocommerce-waitlist.php\";}}}i:4;O:8:\"stdClass\":5:{s:6:\"module\";s:17:\"small_light_block\";s:5:\"title\";s:34:\"Get the official WooCommerce theme\";s:11:\"description\";s:128:\"Storefront is the lean, flexible, and free theme, built by the people who make WooCommerce - everything you need to get started.\";s:5:\"image\";s:70:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/storefront-screen@2x.png\";s:7:\"buttons\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"href\";s:44:\"/wp-admin/theme-install.php?theme=storefront\";s:4:\"text\";s:7:\"Install\";}i:1;O:8:\"stdClass\":2:{s:4:\"href\";s:115:\"https://woocommerce.com/storefront/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:4:\"text\";s:9:\"Read More\";}}}i:5;O:8:\"stdClass\":1:{s:6:\"module\";s:10:\"column_end\";}i:6;O:8:\"stdClass\":1:{s:6:\"module\";s:12:\"column_start\";}i:7;O:8:\"stdClass\":4:{s:6:\"module\";s:16:\"small_dark_block\";s:5:\"title\";s:20:\"Square + WooCommerce\";s:11:\"description\";s:176:\"Keep your WooCommerce and brick-and-mortar stores in sync. Use Square to take payments both online and offline, keep inventory updated between the two and sync product changes.\";s:5:\"items\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"href\";s:120:\"https://woocommerce.com/products/square/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:6:\"button\";s:5:\"Free!\";}}}i:8;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"column_block\";s:5:\"title\";s:19:\"Get deeper insights\";s:11:\"description\";s:58:\"Learn how your store is performing with enhanced reporting\";s:5:\"items\";a:8:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:142:\"https://woocommerce.com/products/woocommerce-google-analytics/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:16:\"Google Analytics\";s:5:\"image\";s:60:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/ga-icon@2x.png\";s:11:\"description\";s:93:\"Understand your customers and increase revenue with the world’s leading analytics platform.\";s:6:\"button\";s:4:\"Free\";s:6:\"plugin\";s:85:\"woocommerce-google-analytics-integration/woocommerce-google-analytics-integration.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:138:\"https://woocommerce.com/products/woocommerce-cart-reports/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:12:\"Cart reports\";s:5:\"image\";s:70:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/cart-reports-icon@2x.png\";s:11:\"description\";s:66:\"Get real-time reports on what customers are leaving in their cart.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:53:\"woocommerce-cart-reports/woocommerce-cart-reports.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:139:\"https://woocommerce.com/products/woocommerce-cost-of-goods/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:13:\"Cost of Goods\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/cost-of-goods-icon@2x.png\";s:11:\"description\";s:64:\"Easily track profit by including  cost of goods in your reports.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:55:\"woocommerce-cost-of-goods/woocommerce-cost-of-goods.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:146:\"https://woocommerce.com/products/woocommerce-google-analytics-pro/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:32:\"WooCommerce Google Analytics Pro\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:85:\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:69:\"woocommerce-google-analytics-pro/woocommerce-google-analytics-pro.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:142:\"https://woocommerce.com/products/woocommerce-customer-history/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:28:\"WooCommerce Customer History\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:125:\"Observe how your customers use your store, keep a full purchase history log, and calculate the total customer lifetime value.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-customer-history/woocommerce-customer-history.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/kiss-metrics/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:11:\"Kissmetrics\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:79:\"Easily add Kissmetrics event tracking to your WooCommerce store with one click.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:52:\"woocommerce-kiss-metrics/woocommerce-kissmetrics.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:122:\"https://woocommerce.com/products/mixpanel/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:8:\"Mixpanel\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:65:\"Add event tracking powered by Mixpanel to your WooCommerce store.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:45:\"woocommerce-mixpanel/woocommerce-mixpanel.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:144:\"https://woocommerce.com/products/woocommerce-sales-report-email/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:30:\"WooCommerce Sales Report Email\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:107:\"Receive emails daily, weekly or monthly with meaningful information about how your products are performing.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:65:\"woocommerce-sales-report-email/woocommerce-sales-report-email.php\";}}}i:9;O:8:\"stdClass\":2:{s:6:\"module\";s:10:\"column_end\";s:9:\"container\";s:20:\"column_container_end\";}i:10;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"banner_block\";s:5:\"title\";s:40:\"Promote your products and increase sales\";s:11:\"description\";s:77:\"From coupons to emails, these extensions can power up your marketing efforts.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:127:\"https://woocommerce.com/products/smart-coupons/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:13:\"Smart Coupons\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/smart-coupons-icon@2x.png\";s:11:\"description\";s:106:\"Enhance your coupon options - create gift certificates, store credit, coupons based on purchases and more.\";s:6:\"button\";s:9:\"From: $99\";s:6:\"plugin\";s:55:\"woocommerce-smart-coupons/woocommerce-smart-coupons.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:130:\"https://woocommerce.com/products/follow-up-emails/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:16:\"Follow Up Emails\";s:5:\"image\";s:74:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/follow-up-emails-icon@2x.png\";s:11:\"description\";s:140:\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\";s:6:\"button\";s:9:\"From: $99\";s:6:\"plugin\";s:61:\"woocommerce-follow-up-emails/woocommerce-follow-up-emails.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:133:\"https://woocommerce.com/products/google-product-feed/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:19:\"Google Product Feed\";s:5:\"image\";s:77:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/google-product-feed-icon@2x.png\";s:11:\"description\";s:61:\"Let customers find you when shopping for products via Google.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:45:\"woocommerce-product-feeds/woocommerce-gpf.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:129:\"https://woocommerce.com/products/dynamic-pricing/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:15:\"Dynamic Pricing\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:48:\"Bulk discounts, role-based pricing and much more\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:59:\"woocommerce-dynamic-pricing/woocommerce-dynamic-pricing.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:144:\"https://woocommerce.com/products/woocommerce-points-and-rewards/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:30:\"WooCommerce Points and Rewards\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:102:\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:65:\"woocommerce-points-and-rewards/woocommerce-points-and-rewards.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/store-credit/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:24:\"WooCommerce Store Credit\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:152:\"Generate store credit coupons that enable customers to make multiple purchases until the total value specified is exhausted or the coupons life expires.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:53:\"woocommerce-store-credit/woocommerce-store-credit.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:122:\"https://woocommerce.com/products/facebook/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:24:\"Facebook for WooCommerce\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:89:\"Get the Facebook for WooCommerce plugin for two powerful ways to help grow your business.\";s:6:\"button\";s:4:\"Free\";s:6:\"plugin\";s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:137:\"https://woocommerce.com/products/newsletter-subscription/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:23:\"Newsletter Subscription\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:127:\"Allow customers to subscribe to your MailChimp or CampaignMonitor mailing list(s) via a widget or by opting in during checkout.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:63:\"woocommerce-subscribe-to-newsletter/subscribe-to-newsletter.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:142:\"https://woocommerce.com/products/woocommerce-email-customizer/?utm_source=product&utm_medium=upsell&utm_campaign=wcaddons&utm_content=featured\";s:5:\"title\";s:28:\"WooCommerce Email Customizer\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:125:\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:61:\"woocommerce-email-customizer/woocommerce-email-customizer.php\";}}}}}', 'no'),
(1881, 'woorelated_wtitle', '', 'yes'),
(1882, 'woorelated_nproducts', '4', 'yes'),
(1883, 'woorelated_basedon', 'product_cat', 'yes'),
(1884, 'woorelated_exclude', '', 'yes'),
(1885, 'woorelated_slider', 'Enabled', 'yes'),
(1896, '_transient_timeout_external_ip_address_201.219.236.96', '1535726248', 'no'),
(1897, '_transient_external_ip_address_201.219.236.96', '186.64.118.50', 'no'),
(1902, '_transient_timeout_external_ip_address_200.29.136.231', '1535726373', 'no'),
(1903, '_transient_external_ip_address_200.29.136.231', '186.64.118.50', 'no'),
(1915, '_transient_timeout_external_ip_address_190.160.113.98', '1535754103', 'no'),
(1916, '_transient_external_ip_address_190.160.113.98', '186.64.118.50', 'no'),
(1962, '_transient_timeout_external_ip_address_66.102.8.42', '1535823169', 'no'),
(1963, '_transient_external_ip_address_66.102.8.42', '186.64.118.50', 'no'),
(1968, '_site_transient_timeout_browser_6f477aefe22511778a7fa5e677f61f3c', '1535824417', 'no'),
(1969, '_site_transient_browser_6f477aefe22511778a7fa5e677f61f3c', 'a:10:{s:4:\"name\";s:5:\"Opera\";s:7:\"version\";s:12:\"54.0.2952.64\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:22:\"https://www.opera.com/\";s:7:\"img_src\";s:42:\"http://s.w.org/images/browsers/opera.png?1\";s:11:\"img_src_ssl\";s:43:\"https://s.w.org/images/browsers/opera.png?1\";s:15:\"current_version\";s:5:\"12.18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(2013, '_transient_timeout_external_ip_address_190.164.243.105', '1535942766', 'no'),
(2014, '_transient_external_ip_address_190.164.243.105', '186.64.118.50', 'no'),
(2016, '_transient_timeout_external_ip_address_127.0.0.1', '1535945447', 'no'),
(2017, '_transient_external_ip_address_127.0.0.1', '190.164.243.105', 'no'),
(2043, 'wpseo_sitemap_118_cache_validator', '2hDdi', 'no'),
(2084, '_transient_timeout_ewww_image_optimizer_images_reoptimized', '1535578089', 'no'),
(2085, '_transient_ewww_image_optimizer_images_reoptimized', 'zero', 'no'),
(2086, '_transient_timeout_wc_report_sales_by_date', '1535661577', 'no'),
(2087, '_transient_wc_report_sales_by_date', 'a:24:{s:32:\"37be4143dc946eb3ca30088915429155\";a:0:{}s:32:\"9884956948c357e042ff79019afe9768\";a:0:{}s:32:\"4dd3a9250c09ab6b0c20c2246eb97715\";a:0:{}s:32:\"f0c1274ce416976f66472b527b2575d5\";N;s:32:\"8577487f07d8137a8008af42711eb793\";a:0:{}s:32:\"8407e4d6aedc79817e05d2768ca1f790\";a:0:{}s:32:\"95e79b500110586419a1eb4f0cc69a8f\";a:0:{}s:32:\"dddd5515fd5120ad67a439261bb8a81f\";a:0:{}s:32:\"649d217e0866cb732d0045adea63141f\";a:0:{}s:32:\"ff1bb4cb89a8728a3c8c1d5369115ac7\";a:0:{}s:32:\"f02cf7717f6ec98ad24ec77e38330293\";a:0:{}s:32:\"76483492e4a425f13c883589c47e6f14\";N;s:32:\"037343208d80186dc4472b3827363723\";a:0:{}s:32:\"5bd8370f9f1a3741b7b571438cb7d1b2\";a:0:{}s:32:\"f1bcaea2e3395fc37a9ef414879508c2\";a:0:{}s:32:\"100969421622bd7bc20f365d438ff033\";a:0:{}s:32:\"1e219a84d77ea932950a96e43d925fc5\";a:0:{}s:32:\"c02862d14df30cd7375efe80ada04653\";a:0:{}s:32:\"d96e6481b1d0ab04f6c7e7f2af8bed72\";a:0:{}s:32:\"1aa25f9023b9d5c07afa5423ad26d0a1\";N;s:32:\"622321c4aecc3aac2d93e395741dc900\";a:0:{}s:32:\"246df382acfed77f383ba032be0e6cc8\";a:0:{}s:32:\"1f4c3923d52c56c6528f06862eb109b2\";a:0:{}s:32:\"3aae6c2868dbcd18b939ccc7348d862f\";a:0:{}}', 'no'),
(2088, '_transient_timeout_wc_admin_report', '1535660890', 'no'),
(2089, '_transient_wc_admin_report', 'a:1:{s:32:\"0c8ab41e8824af86f854cac62de61d41\";a:0:{}}', 'no'),
(2090, '_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e', '1535617695', 'no'),
(2091, '_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e', 'a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:0:{}}', 'no'),
(2092, '_transient_timeout_wpseo-statistics-totals', '1535660895', 'no'),
(2093, '_transient_wpseo-statistics-totals', 'a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:46:\"Posts <strong>without</strong> a focus keyword\";s:5:\"count\";s:1:\"2\";s:4:\"link\";s:98:\"http://localhost:8888/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}', 'no'),
(2095, '_transient_timeout_plugin_slugs', '1535661557', 'no'),
(2096, '_transient_plugin_slugs', 'a:7:{i:0;s:36:\"contact-form-7/wp-contact-form-7.php\";i:1;s:25:\"duplicator/duplicator.php\";i:2;s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";i:3;s:47:\"show-current-template/show-current-template.php\";i:4;s:27:\"woocommerce/woocommerce.php\";i:5;s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";i:6;s:24:\"wordpress-seo/wp-seo.php\";}', 'no'),
(2097, '_transient_timeout_wc_upgrade_notice_3.4.5', '1535660948', 'no'),
(2098, '_transient_wc_upgrade_notice_3.4.5', '', 'no'),
(2099, '_transient_timeout__woocommerce_helper_subscriptions', '1535575474', 'no'),
(2100, '_transient__woocommerce_helper_subscriptions', 'a:0:{}', 'no'),
(2101, '_site_transient_timeout_theme_roots', '1535576374', 'no'),
(2102, '_site_transient_theme_roots', 'a:1:{s:13:\"depapel-theme\";s:7:\"/themes\";}', 'no'),
(2103, '_transient_timeout__woocommerce_helper_updates', '1535617774', 'no'),
(2104, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1535574574;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no'),
(2107, 'rewrite_rules', 'a:157:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:25:\"index.php?xsl=$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:36:\"shop/.+?/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"shop/.+?/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"shop/.+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"shop/.+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"shop/.+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"shop/.+?/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\"shop/(.+?)/([^/]+)/embed/?$\";s:64:\"index.php?product_cat=$matches[1]&product=$matches[2]&embed=true\";s:31:\"shop/(.+?)/([^/]+)/trackback/?$\";s:58:\"index.php?product_cat=$matches[1]&product=$matches[2]&tb=1\";s:51:\"shop/(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:70:\"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]\";s:46:\"shop/(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:70:\"index.php?product_cat=$matches[1]&product=$matches[2]&feed=$matches[3]\";s:39:\"shop/(.+?)/([^/]+)/page/?([0-9]{1,})/?$\";s:71:\"index.php?product_cat=$matches[1]&product=$matches[2]&paged=$matches[3]\";s:46:\"shop/(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:71:\"index.php?product_cat=$matches[1]&product=$matches[2]&cpage=$matches[3]\";s:36:\"shop/(.+?)/([^/]+)/wc-api(/(.*))?/?$\";s:72:\"index.php?product_cat=$matches[1]&product=$matches[2]&wc-api=$matches[4]\";s:40:\"shop/.+?/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:51:\"shop/.+?/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:35:\"shop/(.+?)/([^/]+)(?:/([0-9]+))?/?$\";s:70:\"index.php?product_cat=$matches[1]&product=$matches[2]&page=$matches[3]\";s:25:\"shop/.+?/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"shop/.+?/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"shop/.+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"shop/.+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"shop/.+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"shop/.+?/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:25:\"([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?name=$matches[1]&wc-api=$matches[3]\";s:31:\"[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(2110, 'woocommerce_version', '3.4.5', 'yes'),
(2111, 'woocommerce_db_version', '3.4.5', 'yes'),
(2116, 'ewww_image_optimizer_bulk_attachments', '', 'no'),
(2117, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(2118, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(2120, '_site_transient_timeout_available_translations', '1535585989', 'no');
INSERT INTO `dp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2121, '_site_transient_available_translations', 'a:113:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-06 13:56:09\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.4/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-18 03:20:46\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-04 08:43:29\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.6\";s:7:\"updated\";s:19:\"2018-06-23 07:27:43\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.6/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Напред\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-26 07:51:00\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-25 04:47:06\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 08:58:57\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-27 10:53:54\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-07-06 08:46:24\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsæt\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 00:30:25\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-13 13:32:08\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:48:22\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 11:47:36\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-28 18:56:04\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-31 14:47:16\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-16 14:33:05\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-24 23:12:03\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-24 21:31:15\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-30 17:20:26\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-01 16:09:29\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 20:43:09\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-25 19:18:20\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-21 14:41:13\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2017-07-31 15:12:02\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.6/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-28 15:49:41\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-09 15:53:36\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-02 12:18:54\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-06 16:13:32\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-26 17:19:07\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-25 14:30:50\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-02-14 06:16:04\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-15 08:49:46\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"המשך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-14 10:04:37\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 10:29:39\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Folytatás\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 13:16:13\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-04-13 13:55:54\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-23 06:29:23\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-24 22:32:40\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Nerusaké\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-21 12:12:01\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-22 22:24:38\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.5/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Kemmel\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-04 12:57:46\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"ຕໍ່​ໄປ\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.6\";s:7:\"updated\";s:19:\"2018-05-24 09:42:27\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.6/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.6/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.6\";s:7:\"updated\";s:19:\"2018-05-23 08:05:19\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.6/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ဆောင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 07:24:43\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:43:\"जारी राख्नुहोस्\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-29 11:28:05\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-15 06:55:24\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-06 12:43:59\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.8/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-13 11:47:22\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-29 17:20:37\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"دوام ورکړه\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-24 16:20:30\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 09:30:48\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.5/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-09 13:28:31\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-27 22:23:19\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-03 12:07:46\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-28 12:46:02\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Nadaljuj\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-24 22:24:39\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-02 20:59:54\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-24 18:15:31\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-02 17:08:41\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-02 21:09:54\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-05 13:55:11\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.6\";s:7:\"updated\";s:19:\"2018-06-20 11:37:47\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.6/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-09 10:37:43\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Davom etish\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-24 07:41:18\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-09 00:56:52\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.4\";s:7:\"updated\";s:19:\"2018-02-13 02:41:15\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.4/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-11-17 22:20:52\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}', 'no'),
(2122, 'new_admin_email', 'mariana.j.ambrosetti@gmail.com', 'yes'),
(2128, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/es_ES/wordpress-4.9.8.zip\";s:6:\"locale\";s:5:\"es_ES\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/es_ES/wordpress-4.9.8.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.8\";s:7:\"version\";s:5:\"4.9.8\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1535575246;s:15:\"version_checked\";s:5:\"4.9.8\";s:12:\"translations\";a:0:{}}', 'no');
INSERT INTO `dp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(2129, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1535575248;s:7:\"checked\";a:7:{s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.0.3\";s:25:\"duplicator/duplicator.php\";s:6:\"1.2.42\";s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:5:\"4.3.2\";s:47:\"show-current-template/show-current-template.php\";s:5:\"0.3.0\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.4.5\";s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";s:5:\"1.6.3\";s:24:\"wordpress-seo/wp-seo.php\";s:3:\"8.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.0.3\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.0.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.42\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.42.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}}s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:34:\"w.org/plugins/ewww-image-optimizer\";s:4:\"slug\";s:20:\"ewww-image-optimizer\";s:6:\"plugin\";s:45:\"ewww-image-optimizer/ewww-image-optimizer.php\";s:11:\"new_version\";s:5:\"4.3.2\";s:3:\"url\";s:51:\"https://wordpress.org/plugins/ewww-image-optimizer/\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/plugin/ewww-image-optimizer.4.3.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-256x256.png?rev=1582276\";s:2:\"1x\";s:73:\"https://ps.w.org/ewww-image-optimizer/assets/icon-128x128.png?rev=1582276\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/ewww-image-optimizer/assets/banner-1544x500.jpg?rev=1582276\";s:2:\"1x\";s:75:\"https://ps.w.org/ewww-image-optimizer/assets/banner-772x250.jpg?rev=1582276\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"show-current-template/show-current-template.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:35:\"w.org/plugins/show-current-template\";s:4:\"slug\";s:21:\"show-current-template\";s:6:\"plugin\";s:47:\"show-current-template/show-current-template.php\";s:11:\"new_version\";s:5:\"0.3.0\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/show-current-template/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/show-current-template.0.3.0.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:73:\"https://ps.w.org/show-current-template/assets/icon-256x256.png?rev=976031\";s:2:\"1x\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";s:3:\"svg\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.4.5\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.4.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}}s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:57:\"w.org/plugins/woocommerce-gateway-paypal-express-checkout\";s:4:\"slug\";s:43:\"woocommerce-gateway-paypal-express-checkout\";s:6:\"plugin\";s:91:\"woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php\";s:11:\"new_version\";s:5:\"1.6.3\";s:3:\"url\";s:74:\"https://wordpress.org/plugins/woocommerce-gateway-paypal-express-checkout/\";s:7:\"package\";s:92:\"https://downloads.wordpress.org/plugin/woocommerce-gateway-paypal-express-checkout.1.6.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:96:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-256x256.png?rev=1900204\";s:2:\"1x\";s:96:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/icon-128x128.png?rev=1900204\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:99:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-1544x500.png?rev=1900204\";s:2:\"1x\";s:98:\"https://ps.w.org/woocommerce-gateway-paypal-express-checkout/assets/banner-772x250.png?rev=1900204\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:3:\"8.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/wordpress-seo.8.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1859687\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1859687\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}', 'no'),
(2130, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1535575248;s:7:\"checked\";a:1:{s:13:\"depapel-theme\";s:4:\"1.0.\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_postmeta`
--

CREATE TABLE `dp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_postmeta`
--

INSERT INTO `dp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 6, '_edit_last', '1'),
(4, 6, '_edit_lock', '1534380037:1'),
(5, 8, '_edit_last', '1'),
(6, 8, '_edit_lock', '1534380273:1'),
(7, 3, '_edit_last', '1'),
(8, 3, '_edit_lock', '1534380258:1'),
(9, 5, '_edit_last', '1'),
(10, 5, '_edit_lock', '1534961223:1'),
(11, 13, '_edit_last', '1'),
(12, 13, '_yoast_wpseo_content_score', '30'),
(13, 13, '_edit_lock', '1534380235:1'),
(22, 18, '_edit_last', '1'),
(23, 18, '_edit_lock', '1535575622:1'),
(24, 18, '_yoast_wpseo_content_score', '60'),
(25, 20, '_edit_last', '1'),
(26, 20, '_edit_lock', '1534385889:1'),
(27, 20, '_yoast_wpseo_content_score', '30'),
(28, 22, '_edit_last', '1'),
(29, 22, '_edit_lock', '1534385921:1'),
(30, 22, '_yoast_wpseo_content_score', '30'),
(31, 24, '_edit_last', '1'),
(32, 24, '_edit_lock', '1535053904:1'),
(33, 24, '_yoast_wpseo_content_score', '90'),
(34, 26, '_edit_last', '1'),
(35, 26, '_edit_lock', '1534385961:1'),
(36, 26, '_yoast_wpseo_content_score', '30'),
(37, 28, '_edit_last', '1'),
(38, 28, '_yoast_wpseo_content_score', '60'),
(39, 28, '_edit_lock', '1535052928:1'),
(40, 30, '_edit_last', '1'),
(41, 30, '_edit_lock', '1534386057:1'),
(42, 30, '_yoast_wpseo_content_score', '30'),
(43, 32, '_menu_item_type', 'post_type'),
(44, 32, '_menu_item_menu_item_parent', '0'),
(45, 32, '_menu_item_object_id', '28'),
(46, 32, '_menu_item_object', 'page'),
(47, 32, '_menu_item_target', ''),
(48, 32, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(49, 32, '_menu_item_xfn', ''),
(50, 32, '_menu_item_url', ''),
(51, 32, '_menu_item_orphaned', '1534386231'),
(61, 34, '_menu_item_type', 'post_type'),
(62, 34, '_menu_item_menu_item_parent', '0'),
(63, 34, '_menu_item_object_id', '24'),
(64, 34, '_menu_item_object', 'page'),
(65, 34, '_menu_item_target', ''),
(66, 34, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(67, 34, '_menu_item_xfn', ''),
(68, 34, '_menu_item_url', ''),
(70, 35, '_menu_item_type', 'post_type'),
(71, 35, '_menu_item_menu_item_parent', '0'),
(72, 35, '_menu_item_object_id', '18'),
(73, 35, '_menu_item_object', 'page'),
(74, 35, '_menu_item_target', ''),
(75, 35, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(76, 35, '_menu_item_xfn', ''),
(77, 35, '_menu_item_url', ''),
(106, 39, '_menu_item_type', 'post_type'),
(107, 39, '_menu_item_menu_item_parent', '0'),
(108, 39, '_menu_item_object_id', '8'),
(109, 39, '_menu_item_object', 'page'),
(110, 39, '_menu_item_target', ''),
(111, 39, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(112, 39, '_menu_item_xfn', ''),
(113, 39, '_menu_item_url', ''),
(115, 40, '_menu_item_type', 'post_type'),
(116, 40, '_menu_item_menu_item_parent', '0'),
(117, 40, '_menu_item_object_id', '6'),
(118, 40, '_menu_item_object', 'page'),
(119, 40, '_menu_item_target', ''),
(120, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(121, 40, '_menu_item_xfn', ''),
(122, 40, '_menu_item_url', ''),
(132, 1, '_edit_lock', '1534716511:1'),
(133, 1, '_edit_last', '1'),
(136, 1, '_yoast_wpseo_content_score', '90'),
(137, 1, '_wp_old_slug', 'hola-mundo'),
(138, 1, '_yoast_wpseo_primary_category', ''),
(141, 45, '_wp_attached_file', '2018/08/blog1.jpg'),
(142, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:17:\"2018/08/blog1.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"blog1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"blog1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"blog1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"blog1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"blog1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:17:\"blog1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:17:\"blog1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"blog1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"blog1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:17:\"blog1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"blog1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"blog1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(143, 1, '_thumbnail_id', '45'),
(146, 46, '_edit_last', '1'),
(147, 46, '_edit_lock', '1534718083:1'),
(148, 47, '_wp_attached_file', '2018/08/blog2.jpg'),
(149, 47, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:17:\"2018/08/blog2.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"blog2-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"blog2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"blog2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"blog2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:18:\"blog2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:17:\"blog2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:17:\"blog2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"blog2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"blog2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:17:\"blog2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"blog2-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"blog2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(150, 46, '_thumbnail_id', '47'),
(153, 46, '_yoast_wpseo_content_score', '90'),
(154, 46, '_yoast_wpseo_primary_category', '21'),
(155, 49, '_wp_attached_file', '2018/08/galeria1.jpg'),
(156, 49, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2018/08/galeria1.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"galeria1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"galeria1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"galeria1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"galeria1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"galeria1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"galeria1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"galeria1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"galeria1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"galeria1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(157, 50, '_wp_attached_file', '2018/08/galeria2.jpg'),
(158, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2018/08/galeria2.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"galeria2-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"galeria2-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"galeria2-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"galeria2-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"galeria2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"galeria2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"galeria2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"galeria2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"galeria2-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(159, 51, '_wp_attached_file', '2018/08/galeria3.jpg'),
(160, 51, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2018/08/galeria3.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"galeria3-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"galeria3-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"galeria3-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"galeria3-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"galeria3-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"galeria3-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"galeria3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"galeria3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"galeria3-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"galeria3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(163, 53, '_wp_trash_meta_status', 'publish'),
(164, 53, '_wp_trash_meta_time', '1534812915'),
(165, 56, '_edit_lock', '1534813221:1'),
(166, 56, '_wp_trash_meta_status', 'publish'),
(167, 56, '_wp_trash_meta_time', '1534813251'),
(168, 58, '_edit_lock', '1534813312:1'),
(169, 58, '_wp_trash_meta_status', 'publish'),
(170, 58, '_wp_trash_meta_time', '1534813315'),
(171, 60, '_wp_trash_meta_status', 'publish'),
(172, 60, '_wp_trash_meta_time', '1534813775'),
(173, 61, '_wp_trash_meta_status', 'publish'),
(174, 61, '_wp_trash_meta_time', '1534813949'),
(175, 62, '_wp_trash_meta_status', 'publish'),
(176, 62, '_wp_trash_meta_time', '1534819016'),
(177, 64, '_edit_lock', '1534821133:1'),
(178, 64, '_wp_trash_meta_status', 'publish'),
(179, 64, '_wp_trash_meta_time', '1534821145'),
(183, 67, '_wp_attached_file', '2018/08/MG_6613.jpg'),
(184, 67, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6613.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6613-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6613-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6613-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6613-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6613-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6613-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6613-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6613-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6613-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6613-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6613-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6613-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:19:\"MG_6613-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(218, 20, '_wp_trash_meta_status', 'publish'),
(219, 20, '_wp_trash_meta_time', '1534961266'),
(220, 20, '_wp_desired_post_slug', 'cumpleanos'),
(221, 30, '_wp_trash_meta_status', 'publish'),
(222, 30, '_wp_trash_meta_time', '1534961278'),
(223, 30, '_wp_desired_post_slug', 'bautizos'),
(224, 22, '_wp_trash_meta_status', 'publish'),
(225, 22, '_wp_trash_meta_time', '1534961285'),
(226, 22, '_wp_desired_post_slug', 'matrimonios'),
(227, 5, '_wp_trash_meta_status', 'publish'),
(228, 5, '_wp_trash_meta_time', '1534964068'),
(229, 5, '_wp_desired_post_slug', 'shop'),
(230, 6, '_wp_trash_meta_status', 'publish'),
(231, 6, '_wp_trash_meta_time', '1534964068'),
(233, 7, '_wp_trash_meta_status', 'publish'),
(234, 7, '_wp_trash_meta_time', '1534964068'),
(236, 8, '_wp_trash_meta_status', 'publish'),
(237, 8, '_wp_trash_meta_time', '1534964068'),
(239, 71, '_wc_review_count', '0'),
(240, 71, '_wc_rating_count', 'a:0:{}'),
(241, 71, '_wc_average_rating', '0'),
(242, 71, '_edit_last', '1'),
(243, 71, '_edit_lock', '1535038599:1'),
(244, 71, '_thumbnail_id', '67'),
(245, 71, '_sku', '1'),
(246, 71, '_regular_price', '10.000'),
(247, 71, '_sale_price', ''),
(248, 71, '_sale_price_dates_from', ''),
(249, 71, '_sale_price_dates_to', ''),
(250, 71, 'total_sales', '0'),
(251, 71, '_tax_status', 'taxable'),
(252, 71, '_tax_class', ''),
(253, 71, '_manage_stock', 'yes'),
(254, 71, '_backorders', 'no'),
(255, 71, '_sold_individually', 'no'),
(256, 71, '_weight', ''),
(257, 71, '_length', ''),
(258, 71, '_width', ''),
(259, 71, '_height', ''),
(260, 71, '_upsell_ids', 'a:0:{}'),
(261, 71, '_crosssell_ids', 'a:0:{}'),
(262, 71, '_purchase_note', ''),
(263, 71, '_default_attributes', 'a:0:{}'),
(264, 71, '_virtual', 'no'),
(265, 71, '_downloadable', 'no'),
(266, 71, '_product_image_gallery', '157,156,155,154,153,152,151'),
(267, 71, '_download_limit', '-1'),
(268, 71, '_download_expiry', '-1'),
(269, 71, '_stock', '1'),
(270, 71, '_stock_status', 'instock'),
(271, 71, '_product_version', '3.4.4'),
(272, 71, '_price', '10.000'),
(273, 71, '_yoast_wpseo_primary_product_cat', ''),
(274, 71, '_yoast_wpseo_content_score', '30'),
(275, 72, '_menu_item_type', 'post_type'),
(276, 72, '_menu_item_menu_item_parent', '0'),
(277, 72, '_menu_item_object_id', '70'),
(278, 72, '_menu_item_object', 'page'),
(279, 72, '_menu_item_target', ''),
(280, 72, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(281, 72, '_menu_item_xfn', ''),
(282, 72, '_menu_item_url', ''),
(284, 73, '_edit_lock', '1534966659:1'),
(285, 73, '_wp_trash_meta_status', 'publish'),
(286, 73, '_wp_trash_meta_time', '1534966673'),
(288, 70, '_edit_lock', '1535402610:1'),
(289, 70, '_edit_last', '1'),
(290, 70, '_yoast_wpseo_content_score', '30'),
(293, 77, '_edit_last', '1'),
(295, 77, '_sidebar_to_replace', 'sidebar_widget'),
(296, 77, '_edit_lock', '1534969094:1'),
(300, 74, '_edit_lock', '1534968960:1'),
(306, 77, '_condition', 'post-70'),
(307, 77, '_condition', 'postwc-70'),
(308, 77, '_wp_trash_meta_status', 'publish'),
(309, 77, '_wp_trash_meta_time', '1534969378'),
(310, 77, '_wp_desired_post_slug', 'categorias'),
(311, 74, '_customize_restore_dismissed', '1'),
(312, 78, '_wp_trash_meta_status', 'publish'),
(313, 78, '_wp_trash_meta_time', '1534973116'),
(314, 80, '_edit_lock', '1534973253:1'),
(315, 80, '_wp_trash_meta_status', 'publish'),
(316, 80, '_wp_trash_meta_time', '1534973269'),
(317, 82, '_wp_trash_meta_status', 'publish'),
(318, 82, '_wp_trash_meta_time', '1534973354'),
(319, 84, '_wp_trash_meta_status', 'publish'),
(320, 84, '_wp_trash_meta_time', '1534973404'),
(321, 86, '_wp_trash_meta_status', 'publish'),
(322, 86, '_wp_trash_meta_time', '1534974052'),
(323, 88, '_wp_trash_meta_status', 'publish'),
(324, 88, '_wp_trash_meta_time', '1534974151'),
(325, 90, '_edit_lock', '1534974579:1'),
(326, 90, '_wp_trash_meta_status', 'publish'),
(327, 90, '_wp_trash_meta_time', '1534974601'),
(328, 92, '_edit_lock', '1534974814:1'),
(329, 92, '_wp_trash_meta_status', 'publish'),
(330, 92, '_wp_trash_meta_time', '1534974827'),
(331, 94, '_wp_trash_meta_status', 'publish'),
(332, 94, '_wp_trash_meta_time', '1534975175'),
(333, 96, '_edit_lock', '1534975453:1'),
(334, 96, '_wp_trash_meta_status', 'publish'),
(335, 96, '_wp_trash_meta_time', '1534975482'),
(336, 98, '_wp_trash_meta_status', 'publish'),
(337, 98, '_wp_trash_meta_time', '1534975524'),
(338, 100, '_wp_trash_meta_status', 'publish'),
(339, 100, '_wp_trash_meta_time', '1534975740'),
(340, 102, '_wp_trash_meta_status', 'publish'),
(341, 102, '_wp_trash_meta_time', '1534975903'),
(342, 104, '_edit_lock', '1534976058:1'),
(343, 104, '_wp_trash_meta_status', 'publish'),
(344, 104, '_wp_trash_meta_time', '1534976074'),
(345, 106, '_edit_lock', '1534976556:1'),
(346, 106, '_wp_trash_meta_status', 'publish'),
(347, 106, '_wp_trash_meta_time', '1534976564'),
(348, 108, '_edit_lock', '1534976693:1'),
(349, 108, '_wp_trash_meta_status', 'publish'),
(350, 108, '_wp_trash_meta_time', '1534976710'),
(351, 110, '_edit_lock', '1534977379:1'),
(352, 110, '_wp_trash_meta_status', 'publish'),
(353, 110, '_wp_trash_meta_time', '1534977387'),
(354, 112, '_edit_lock', '1534977458:1'),
(355, 112, '_wp_trash_meta_status', 'publish'),
(356, 112, '_wp_trash_meta_time', '1534977470'),
(357, 114, '_edit_lock', '1534977718:1'),
(358, 114, '_wp_trash_meta_status', 'publish'),
(359, 114, '_wp_trash_meta_time', '1534977743'),
(360, 116, '_edit_lock', '1534977896:1'),
(361, 116, '_wp_trash_meta_status', 'publish'),
(362, 116, '_wp_trash_meta_time', '1534977907'),
(372, 127, '_wp_attached_file', '2018/08/MG_6684.jpg'),
(373, 127, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6684.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6684-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6684-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6684-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6684-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6684-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6684-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6684-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6684-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6684-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6684-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6684-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6684-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(374, 2, '_wp_trash_meta_status', 'publish'),
(375, 2, '_wp_trash_meta_time', '1534986541'),
(376, 2, '_wp_desired_post_slug', 'pagina-de-ejemplo'),
(377, 133, '_wp_attached_file', '2018/08/MG_6677.jpg'),
(378, 133, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6677.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6677-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6677-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6677-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6677-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6677-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6677-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6677-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6677-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6677-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6677-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6677-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6677-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(379, 135, '_wp_trash_meta_status', 'publish'),
(380, 135, '_wp_trash_meta_time', '1535036195'),
(381, 137, '_wp_trash_meta_status', 'publish'),
(382, 137, '_wp_trash_meta_time', '1535036418'),
(383, 139, '_wp_trash_meta_status', 'publish'),
(384, 139, '_wp_trash_meta_time', '1535036535'),
(385, 141, '_wc_review_count', '0'),
(386, 141, '_wc_rating_count', 'a:0:{}'),
(387, 141, '_wc_average_rating', '0'),
(388, 142, '_wp_attached_file', '2018/08/MG_6674.jpg'),
(389, 142, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6674.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6674-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6674-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6674-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6674-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6674-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6674-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6674-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6674-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6674-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6674-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6674-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6674-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(390, 143, '_wp_attached_file', '2018/08/DSC_2989.jpg'),
(391, 143, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:576;s:4:\"file\";s:20:\"2018/08/DSC_2989.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_2989-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2989-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_2989-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC_2989-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC_2989-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_2989-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_2989-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_2989-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2989-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_2989-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC_2989-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2989-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(392, 144, '_wp_attached_file', '2018/08/DSC_2990.jpg'),
(393, 144, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:576;s:4:\"file\";s:20:\"2018/08/DSC_2990.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_2990-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2990-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_2990-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC_2990-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC_2990-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_2990-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_2990-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_2990-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2990-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_2990-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC_2990-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2990-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(394, 145, '_wp_attached_file', '2018/08/DSC_2991.jpg'),
(395, 145, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:576;s:4:\"file\";s:20:\"2018/08/DSC_2991.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_2991-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2991-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_2991-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC_2991-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC_2991-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_2991-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_2991-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_2991-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2991-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_2991-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC_2991-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_2991-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(396, 146, '_wp_attached_file', '2018/08/DSC_3014.jpg'),
(397, 146, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:576;s:4:\"file\";s:20:\"2018/08/DSC_3014.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_3014-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3014-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_3014-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC_3014-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC_3014-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_3014-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_3014-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_3014-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3014-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_3014-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC_3014-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3014-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(398, 147, '_wp_attached_file', '2018/08/DSC_3064.jpg'),
(399, 147, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:449;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2018/08/DSC_3064.jpg\";s:5:\"sizes\";a:9:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_3064-400x684.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:684;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3064-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_3064-175x300.jpg\";s:5:\"width\";i:175;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_3064-449x600.jpg\";s:5:\"width\";i:449;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_3064-449x600.jpg\";s:5:\"width\";i:449;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_3064-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3064-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_3064-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3064-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(400, 148, '_wp_attached_file', '2018/08/DSC_3105.jpg'),
(401, 148, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:576;s:4:\"file\";s:20:\"2018/08/DSC_3105.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_3105-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_3105-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3105-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_3105-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"DSC_3105-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"DSC_3105-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_3105-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_3105-800x576.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3105-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_3105-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"DSC_3105-400x225.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3105-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(402, 149, '_wp_attached_file', '2018/08/planificador_ANUAL3.jpg'),
(403, 149, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:31:\"2018/08/planificador_ANUAL3.jpg\";s:5:\"sizes\";a:12:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"planificador_ANUAL3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"planificador_ANUAL3-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:31:\"planificador_ANUAL3-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL3-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(404, 150, '_wp_attached_file', '2018/08/planificador_ANUAL3_2.jpg');
INSERT INTO `dp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(405, 150, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:768;s:4:\"file\";s:33:\"2018/08/planificador_ANUAL3_2.jpg\";s:5:\"sizes\";a:10:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-400x600.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-512x600.jpg\";s:5:\"width\";i:512;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-512x600.jpg\";s:5:\"width\";i:512;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_thumbnail_preview\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL3_2-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(406, 141, '_edit_last', '1'),
(407, 141, '_edit_lock', '1535038518:1'),
(408, 151, '_wp_attached_file', '2018/08/MG_6670.jpg'),
(409, 151, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6670.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6670-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6670-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6670-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6670-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6670-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6670-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6670-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6670-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6670-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6670-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6670-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6670-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:19:\"MG_6670-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(410, 152, '_wp_attached_file', '2018/08/MG_6676.jpg'),
(411, 152, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6676.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6676-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6676-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6676-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6676-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6676-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6676-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6676-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6676-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6676-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6676-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6676-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6676-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:19:\"MG_6676-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(412, 153, '_wp_attached_file', '2018/08/MG_6677-1.jpg'),
(413, 153, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:21:\"2018/08/MG_6677-1.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"MG_6677-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"MG_6677-1-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:21:\"MG_6677-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:21:\"MG_6677-1-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(414, 154, '_wp_attached_file', '2018/08/MG_6680.jpg'),
(415, 154, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:19:\"2018/08/MG_6680.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"MG_6680-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"MG_6680-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6680-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"MG_6680-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"MG_6680-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"MG_6680-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:19:\"MG_6680-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:19:\"MG_6680-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6680-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:19:\"MG_6680-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"MG_6680-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"MG_6680-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:19:\"MG_6680-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(416, 155, '_wp_attached_file', '2018/08/DSC_3045.jpg'),
(417, 155, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:432;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2018/08/DSC_3045.jpg\";s:5:\"sizes\";a:10:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_3045-400x711.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:711;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_3045-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3045-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_3045-169x300.jpg\";s:5:\"width\";i:169;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_3045-432x600.jpg\";s:5:\"width\";i:432;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_3045-432x600.jpg\";s:5:\"width\";i:432;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3045-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_3045-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3045-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:20:\"DSC_3045-200x356.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:356;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(418, 156, '_wp_attached_file', '2018/08/DSC_3090.jpg'),
(419, 156, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:432;s:6:\"height\";i:768;s:4:\"file\";s:20:\"2018/08/DSC_3090.jpg\";s:5:\"sizes\";a:10:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"DSC_3090-400x711.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:711;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"DSC_3090-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3090-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"DSC_3090-169x300.jpg\";s:5:\"width\";i:169;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:20:\"DSC_3090-432x600.jpg\";s:5:\"width\";i:432;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:20:\"DSC_3090-432x600.jpg\";s:5:\"width\";i:432;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3090-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:20:\"DSC_3090-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"DSC_3090-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:20:\"DSC_3090-200x356.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:356;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(420, 157, '_wp_attached_file', '2018/08/galeria1-1.jpg'),
(421, 157, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:768;s:4:\"file\";s:22:\"2018/08/galeria1-1.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:22:\"galeria1-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:22:\"galeria1-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"galeria1-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"galeria1-1-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"galeria1-1-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"galeria1-1-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:22:\"galeria1-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:22:\"galeria1-1-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:22:\"galeria1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:22:\"galeria1-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:22:\"galeria1-1-400x300.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:22:\"galeria1-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:22:\"galeria1-1-200x150.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(422, 141, '_thumbnail_id', '150'),
(423, 141, '_sku', ''),
(424, 141, '_regular_price', '10.000'),
(425, 141, '_sale_price', ''),
(426, 141, '_sale_price_dates_from', ''),
(427, 141, '_sale_price_dates_to', ''),
(428, 141, 'total_sales', '0'),
(429, 141, '_tax_status', 'taxable'),
(430, 141, '_tax_class', ''),
(431, 141, '_manage_stock', 'yes'),
(432, 141, '_backorders', 'no'),
(433, 141, '_sold_individually', 'no'),
(434, 141, '_weight', ''),
(435, 141, '_length', ''),
(436, 141, '_width', ''),
(437, 141, '_height', ''),
(438, 141, '_upsell_ids', 'a:0:{}'),
(439, 141, '_crosssell_ids', 'a:0:{}'),
(440, 141, '_purchase_note', ''),
(441, 141, '_default_attributes', 'a:0:{}'),
(442, 141, '_virtual', 'no'),
(443, 141, '_downloadable', 'no'),
(444, 141, '_product_image_gallery', '151,152,153,154,155,156,157'),
(445, 141, '_download_limit', '-1'),
(446, 141, '_download_expiry', '-1'),
(447, 141, '_stock', '1'),
(448, 141, '_stock_status', 'instock'),
(449, 141, '_product_version', '3.4.4'),
(450, 141, '_price', '10.000'),
(451, 141, '_yoast_wpseo_primary_product_cat', '27'),
(452, 141, '_yoast_wpseo_content_score', '30'),
(453, 158, '_wc_review_count', '0'),
(454, 158, '_wc_rating_count', 'a:0:{}'),
(455, 158, '_wc_average_rating', '0'),
(456, 158, '_edit_last', '1'),
(457, 158, '_edit_lock', '1535039049:1'),
(458, 159, '_wp_attached_file', '2018/08/planificador_ANUAL4_2.jpg'),
(459, 159, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:33:\"2018/08/planificador_ANUAL4_2.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"planificador_ANUAL4_2-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_thumbnail_preview\";a:4:{s:4:\"file\";s:33:\"planificador_ANUAL4_2-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(460, 158, '_thumbnail_id', '159'),
(461, 158, '_sku', ''),
(462, 158, '_regular_price', '10.000'),
(463, 158, '_sale_price', ''),
(464, 158, '_sale_price_dates_from', ''),
(465, 158, '_sale_price_dates_to', ''),
(466, 158, 'total_sales', '0'),
(467, 158, '_tax_status', 'taxable'),
(468, 158, '_tax_class', ''),
(469, 158, '_manage_stock', 'yes'),
(470, 158, '_backorders', 'no'),
(471, 158, '_sold_individually', 'no'),
(472, 158, '_weight', ''),
(473, 158, '_length', ''),
(474, 158, '_width', ''),
(475, 158, '_height', ''),
(476, 158, '_upsell_ids', 'a:0:{}'),
(477, 158, '_crosssell_ids', 'a:0:{}'),
(478, 158, '_purchase_note', ''),
(479, 158, '_default_attributes', 'a:0:{}'),
(480, 158, '_virtual', 'no'),
(481, 158, '_downloadable', 'no'),
(482, 158, '_product_image_gallery', '157,156,155,154,153,152,151'),
(483, 158, '_download_limit', '-1'),
(484, 158, '_download_expiry', '-1'),
(485, 158, '_stock', '1'),
(486, 158, '_stock_status', 'instock'),
(487, 158, '_product_version', '3.4.4'),
(488, 158, '_price', '10.000'),
(489, 158, '_yoast_wpseo_primary_product_cat', ''),
(490, 158, '_yoast_wpseo_content_score', '30'),
(491, 160, '_wc_review_count', '0'),
(492, 160, '_wc_rating_count', 'a:0:{}'),
(493, 160, '_wc_average_rating', '0'),
(494, 160, '_edit_last', '1'),
(495, 160, '_edit_lock', '1535038883:1'),
(496, 161, '_wp_attached_file', '2018/08/planificador_ANUAL5.jpg'),
(497, 161, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:31:\"2018/08/planificador_ANUAL5.jpg\";s:5:\"sizes\";a:13:{s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"planificador_ANUAL5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:32:\"planificador_ANUAL5-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:31:\"planificador_ANUAL5-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_thumbnail_preview\";a:4:{s:4:\"file\";s:31:\"planificador_ANUAL5-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(498, 160, '_thumbnail_id', '161'),
(499, 160, '_sku', ''),
(500, 160, '_regular_price', '10.000'),
(501, 160, '_sale_price', ''),
(502, 160, '_sale_price_dates_from', ''),
(503, 160, '_sale_price_dates_to', ''),
(504, 160, 'total_sales', '0'),
(505, 160, '_tax_status', 'taxable'),
(506, 160, '_tax_class', ''),
(507, 160, '_manage_stock', 'yes'),
(508, 160, '_backorders', 'no'),
(509, 160, '_sold_individually', 'no'),
(510, 160, '_weight', ''),
(511, 160, '_length', ''),
(512, 160, '_width', ''),
(513, 160, '_height', ''),
(514, 160, '_upsell_ids', 'a:0:{}'),
(515, 160, '_crosssell_ids', 'a:0:{}'),
(516, 160, '_purchase_note', ''),
(517, 160, '_default_attributes', 'a:0:{}'),
(518, 160, '_virtual', 'no'),
(519, 160, '_downloadable', 'no'),
(520, 160, '_product_image_gallery', '157,156,155,154,153,152,151'),
(521, 160, '_download_limit', '-1'),
(522, 160, '_download_expiry', '-1'),
(523, 160, '_stock', '1'),
(524, 160, '_stock_status', 'instock'),
(525, 160, '_product_version', '3.4.4'),
(526, 160, '_price', '10.000'),
(527, 160, '_yoast_wpseo_primary_product_cat', '27'),
(528, 160, '_yoast_wpseo_content_score', '30'),
(529, 162, '_wc_review_count', '0'),
(530, 162, '_wc_rating_count', 'a:0:{}'),
(531, 162, '_wc_average_rating', '0'),
(532, 162, '_edit_last', '1'),
(533, 162, '_edit_lock', '1535039367:1'),
(534, 163, '_wp_attached_file', '2018/08/planificador_RECETAS2.jpg'),
(535, 163, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:683;s:4:\"file\";s:33:\"2018/08/planificador_RECETAS2.jpg\";s:5:\"sizes\";a:14:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"planificador_RECETAS2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:34:\"planificador_RECETAS2-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"slideshow\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"custom_logo\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-800x600.jpg\";s:5:\"width\";i:800;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:5:{s:4:\"file\";s:33:\"planificador_RECETAS2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:1;}s:11:\"shop_single\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-200x133.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:133;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_thumbnail_preview\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-200x200.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:26:\"woocommerce_single_preview\";a:4:{s:4:\"file\";s:33:\"planificador_RECETAS2-400x267.jpg\";s:5:\"width\";i:400;s:6:\"height\";i:267;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(536, 162, '_thumbnail_id', '163'),
(537, 162, '_sku', ''),
(538, 162, '_regular_price', '10.000'),
(539, 162, '_sale_price', ''),
(540, 162, '_sale_price_dates_from', ''),
(541, 162, '_sale_price_dates_to', ''),
(542, 162, 'total_sales', '0'),
(543, 162, '_tax_status', 'taxable'),
(544, 162, '_tax_class', ''),
(545, 162, '_manage_stock', 'yes'),
(546, 162, '_backorders', 'no'),
(547, 162, '_sold_individually', 'no'),
(548, 162, '_weight', ''),
(549, 162, '_length', ''),
(550, 162, '_width', ''),
(551, 162, '_height', ''),
(552, 162, '_upsell_ids', 'a:0:{}'),
(553, 162, '_crosssell_ids', 'a:0:{}'),
(554, 162, '_purchase_note', ''),
(555, 162, '_default_attributes', 'a:0:{}'),
(556, 162, '_virtual', 'no'),
(557, 162, '_downloadable', 'no'),
(558, 162, '_product_image_gallery', '157,156,155,154,153,152,151'),
(559, 162, '_download_limit', '-1'),
(560, 162, '_download_expiry', '-1'),
(561, 162, '_stock', '1'),
(562, 162, '_stock_status', 'instock'),
(563, 162, '_product_version', '3.4.4'),
(564, 162, '_price', '10.000'),
(565, 162, '_yoast_wpseo_primary_product_cat', '27'),
(566, 162, '_yoast_wpseo_content_score', '30'),
(567, 164, '_wp_trash_meta_status', 'publish'),
(568, 164, '_wp_trash_meta_time', '1535040343'),
(569, 166, '_wp_trash_meta_status', 'publish'),
(570, 166, '_wp_trash_meta_time', '1535040650'),
(571, 168, '_wp_trash_meta_status', 'publish'),
(572, 168, '_wp_trash_meta_time', '1535040759'),
(573, 170, '_wp_trash_meta_status', 'publish'),
(574, 170, '_wp_trash_meta_time', '1535041230'),
(575, 172, '_wp_trash_meta_status', 'publish'),
(576, 172, '_wp_trash_meta_time', '1535041469'),
(577, 174, '_edit_lock', '1535042239:1'),
(578, 174, '_wp_trash_meta_status', 'publish'),
(579, 174, '_wp_trash_meta_time', '1535042259'),
(580, 176, '_wp_trash_meta_status', 'publish'),
(581, 176, '_wp_trash_meta_time', '1535042364'),
(582, 178, '_wp_trash_meta_status', 'publish'),
(583, 178, '_wp_trash_meta_time', '1535042422'),
(584, 180, '_edit_lock', '1535042649:1'),
(585, 180, '_wp_trash_meta_status', 'publish'),
(586, 180, '_wp_trash_meta_time', '1535042652'),
(587, 182, '_wp_trash_meta_status', 'publish'),
(588, 182, '_wp_trash_meta_time', '1535042766'),
(589, 184, '_edit_lock', '1535044212:1'),
(590, 184, '_wp_trash_meta_status', 'publish'),
(591, 184, '_wp_trash_meta_time', '1535044234'),
(592, 186, '_edit_lock', '1535044516:1'),
(593, 186, '_wp_trash_meta_status', 'publish'),
(594, 186, '_wp_trash_meta_time', '1535044526'),
(595, 188, '_wp_trash_meta_status', 'publish'),
(596, 188, '_wp_trash_meta_time', '1535044550'),
(597, 190, '_wp_trash_meta_status', 'publish'),
(598, 190, '_wp_trash_meta_time', '1535044627'),
(599, 192, '_edit_lock', '1535044698:1'),
(600, 192, '_wp_trash_meta_status', 'publish'),
(601, 192, '_wp_trash_meta_time', '1535044694'),
(602, 194, '_wp_trash_meta_status', 'publish'),
(603, 194, '_wp_trash_meta_time', '1535044779'),
(604, 196, '_edit_lock', '1535044838:1'),
(605, 196, '_wp_trash_meta_status', 'publish'),
(606, 196, '_wp_trash_meta_time', '1535044839'),
(607, 198, '_edit_lock', '1535045114:1'),
(608, 198, '_wp_trash_meta_status', 'publish'),
(609, 198, '_wp_trash_meta_time', '1535045118'),
(610, 199, '_wp_trash_meta_status', 'publish'),
(611, 199, '_wp_trash_meta_time', '1535045255'),
(612, 200, '_wp_trash_meta_status', 'publish'),
(613, 200, '_wp_trash_meta_time', '1535045501'),
(614, 202, '_wp_trash_meta_status', 'publish'),
(615, 202, '_wp_trash_meta_time', '1535045572'),
(616, 204, '_wp_trash_meta_status', 'publish'),
(617, 204, '_wp_trash_meta_time', '1535045598'),
(618, 206, '_wp_trash_meta_status', 'publish'),
(619, 206, '_wp_trash_meta_time', '1535045757'),
(620, 208, '_edit_lock', '1535045853:1'),
(621, 208, '_wp_trash_meta_status', 'publish'),
(622, 208, '_wp_trash_meta_time', '1535045844'),
(623, 209, '_edit_lock', '1535046058:1'),
(624, 209, '_wp_trash_meta_status', 'publish'),
(625, 209, '_wp_trash_meta_time', '1535046062'),
(626, 211, '_edit_lock', '1535046178:1'),
(627, 211, '_wp_trash_meta_status', 'publish'),
(628, 211, '_wp_trash_meta_time', '1535046184'),
(629, 213, '_wp_trash_meta_status', 'publish'),
(630, 213, '_wp_trash_meta_time', '1535046286'),
(631, 215, '_wp_trash_meta_status', 'publish'),
(632, 215, '_wp_trash_meta_time', '1535046398'),
(633, 217, '_wp_trash_meta_status', 'publish'),
(634, 217, '_wp_trash_meta_time', '1535047092'),
(635, 219, '_wp_trash_meta_status', 'publish'),
(636, 219, '_wp_trash_meta_time', '1535047283'),
(637, 221, '_edit_lock', '1535047747:1'),
(638, 221, '_wp_trash_meta_status', 'publish'),
(639, 221, '_wp_trash_meta_time', '1535047758'),
(640, 223, '_edit_lock', '1535047882:1'),
(641, 223, '_wp_trash_meta_status', 'publish'),
(642, 223, '_wp_trash_meta_time', '1535047898'),
(643, 225, '_edit_lock', '1535049526:1'),
(644, 225, '_customize_restore_dismissed', '1'),
(645, 226, '_wp_trash_meta_status', 'publish'),
(646, 226, '_wp_trash_meta_time', '1535049568'),
(647, 228, '_wp_trash_meta_status', 'publish'),
(648, 228, '_wp_trash_meta_time', '1535050177'),
(649, 230, '_wp_trash_meta_status', 'publish'),
(650, 230, '_wp_trash_meta_time', '1535050818'),
(651, 232, '_edit_lock', '1535050973:1'),
(652, 232, '_wp_trash_meta_status', 'publish'),
(653, 232, '_wp_trash_meta_time', '1535050985'),
(654, 234, '_form', '<label> Tu Nombre (requerido)\n    [text* your-name] </label>\n\n<label> Tu Correo (requerido)\n    [email* your-email] </label>\n\n<label> Asunto\n    [text your-subject] </label>\n\n<label> Tu Mensaje\n    [textarea your-message] </label>\n\n[submit \"Enviar\"]'),
(655, 234, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:32:\"De Papel Tienda \"[your-subject]\"\";s:6:\"sender\";s:37:\"[your-name] <wordpress@186.64.118.50>\";s:9:\"recipient\";s:19:\"Tudepapel@gmail.com\";s:4:\"body\";s:196:\"De: [your-name] <[your-email]>\nAsunto: [your-subject]\n\nCuerpo del Mensaje\n[your-message]\n\n-- \nEste correo fue enviado utilizando contact form en De Papel Tienda (http://186.64.118.50/~feg7mariana)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(656, 234, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:32:\"De Papel Tienda \"[your-subject]\"\";s:6:\"sender\";s:41:\"De Papel Tienda <wordpress@186.64.118.50>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:141:\"Cuerpo del Mensaje\n[your-message]\n\n-- \nEste correo fue enviado utilizando contact form en De Papel Tienda (http://186.64.118.50/~feg7mariana)\";s:18:\"additional_headers\";s:40:\"Reply-To: mariana.j.ambrosetti@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(657, 234, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:59:\"Gracias por contactarnos, te responderemos a la brevedad :D\";s:12:\"mail_sent_ng\";s:69:\"Hubo un error tratando de enviar el mensaje. Porfavor trata de nuevo.\";s:16:\"validation_error\";s:70:\"Uno o más campos tienen un error. Porfavor revisa e intenta otra vez.\";s:4:\"spam\";s:69:\"Hubo un error tratando de enviar el mensaje. Porfavor trata de nuevo.\";s:12:\"accept_terms\";s:69:\"Debes aceptar los términos y condiciones antes de enviar el mensaje.\";s:16:\"invalid_required\";s:24:\"Este campo es requerido.\";s:16:\"invalid_too_long\";s:24:\"Este campo es muy largo.\";s:17:\"invalid_too_short\";s:24:\"Este campo es muy corto.\";s:12:\"invalid_date\";s:33:\"El formato de fecha es incorrecto\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:11:\"El código \";s:13:\"invalid_email\";s:37:\"La dirección ingresada es inválida.\";s:11:\"invalid_url\";s:18:\"La URL es inálida\";s:11:\"invalid_tel\";s:24:\"El número es inválido.\";}'),
(658, 234, '_additional_settings', ''),
(659, 234, '_locale', 'es_CL'),
(660, 236, '_menu_item_type', 'post_type'),
(661, 236, '_menu_item_menu_item_parent', '0'),
(662, 236, '_menu_item_object_id', '28'),
(663, 236, '_menu_item_object', 'page'),
(664, 236, '_menu_item_target', ''),
(665, 236, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(666, 236, '_menu_item_xfn', ''),
(667, 236, '_menu_item_url', ''),
(668, 247, '_edit_last', '1'),
(669, 247, '_yoast_wpseo_content_score', '30'),
(670, 247, '_edit_lock', '1535345124:1'),
(671, 249, '_menu_item_type', 'custom'),
(672, 249, '_menu_item_menu_item_parent', '0'),
(673, 249, '_menu_item_object_id', '249'),
(674, 250, '_menu_item_type', 'custom'),
(675, 249, '_menu_item_object', 'custom'),
(676, 250, '_menu_item_menu_item_parent', '0'),
(677, 249, '_menu_item_target', ''),
(678, 250, '_menu_item_object_id', '250'),
(679, 249, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(680, 250, '_menu_item_object', 'custom'),
(681, 249, '_menu_item_xfn', ''),
(682, 250, '_menu_item_target', ''),
(683, 249, '_menu_item_url', 'http://186.64.118.50/~feg7mariana/'),
(684, 250, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(686, 250, '_menu_item_xfn', ''),
(687, 250, '_menu_item_url', 'http://186.64.118.50/~feg7mariana/'),
(688, 250, '_menu_item_orphaned', '1535345584');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_posts`
--

CREATE TABLE `dp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_posts`
--

INSERT INTO `dp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-08-09 17:28:31', '2018-08-09 17:28:31', '<p style=\"text-align: center;\">Cuando el amor por la papelería se transforma en fanatismo<!--more--></p>\r\nSi te declaras un/a fanático/a de los papeles, lapices y libretas, disfrutas del olor a nuevo que expelen las hojas al moverlas, De Papel te podrá poner los pelos de punta con los mejores diseños hechos a mano.\r\n\r\n[gallery link=\"file\" ids=\"49,50,51\" orderby=\"rand\"]\r\n\r\n&nbsp;', 'El Amor por la Papelería', '', 'publish', 'open', 'open', '', 'amor-papeleria', '', '', '2018-08-19 22:10:48', '2018-08-19 22:10:48', '', 0, 'http://localhost:8888/?p=1', 0, 'post', '', 1),
(2, 1, '2018-08-09 17:28:31', '2018-08-09 17:28:31', 'Esta es una página de ejemplo. Es diferente a una entrada del blog, ya que se quedará en un lugar y se mostrará en la navegación del sitio (en la mayoría de temas). La mayoría de personas empieza con una página \"Acerca de\" que brinda información a los visitantes. Se podría decir algo como esto:\n\n<blockquote>¡Hola! Durante el día soy un mensajero, un aspirante a actor por la noche, y este es mi blog. Vivo en Valparaíso, tengo un enorme perro llamado Pocho, y me gustan las cervezas muy heladas. (Y caminar por la playa.)</blockquote>\n\n...o algo como esto:\n\n<blockquote>La compañía XYZ, se fundó en 1971, y ha estado desde entonces, proporcionando artilugios de calidad al público. Está situada en la ciudad de Concepción, Chile y emplea a más de 2,000 personas. Hace todo tipo de cosas sorprendentes para la comunidad penquista.</blockquote>\n\nComo nuevo usuario de WordPress,  debes ir a <a href=\"http://localhost:8888/wp-admin/\">tu panel</a> para eliminar esta página y crear nuevas para tu contenido. ¡Que te diviertas!', 'Página de ejemplo', '', 'trash', 'closed', 'open', '', 'pagina-de-ejemplo__trashed', '', '', '2018-08-23 01:09:01', '2018-08-23 01:09:01', '', 0, 'http://localhost:8888/?page_id=2', 0, 'page', '', 0),
(3, 1, '2018-08-09 17:28:31', '2018-08-09 17:28:31', '<h2>Who we are</h2><p>Our website address is: http://localhost:8888.</p><h2>What personal data we collect and why we collect it</h2><h3>Comentarios</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Multimedia</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Política de Privacidad', '', 'draft', 'closed', 'closed', '', 'politica-privacidad', '', '', '2018-08-16 00:44:18', '2018-08-16 00:44:18', '', 0, 'http://localhost:8888/?page_id=3', 0, 'page', '', 0),
(5, 1, '2018-08-15 21:04:18', '2018-08-15 21:04:18', '', 'Tienda', '', 'trash', 'closed', 'closed', '', 'shop__trashed', '', '', '2018-08-22 18:54:28', '2018-08-22 18:54:28', '', 0, 'http://localhost:8888/shop/', 0, 'page', '', 0),
(6, 1, '2018-08-15 21:04:19', '2018-08-15 21:04:19', '[woocommerce_cart]', 'Carrito', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2018-08-22 19:06:47', '2018-08-22 19:06:47', '', 0, 'http://localhost:8888/cart/', 0, 'page', '', 0),
(7, 1, '2018-08-15 21:04:19', '2018-08-15 21:04:19', '[woocommerce_checkout]', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2018-08-22 19:06:47', '2018-08-22 19:06:47', '', 0, 'http://localhost:8888/checkout/', 0, 'page', '', 0),
(8, 1, '2018-08-15 21:04:19', '2018-08-15 21:04:19', '[woocommerce_my_account]', 'Mi Cuenta', '', 'publish', 'closed', 'closed', '', 'mi-cuenta', '', '', '2018-08-22 19:06:47', '2018-08-22 19:06:47', '', 0, 'http://localhost:8888/my-account/', 0, 'page', '', 0),
(9, 1, '2018-08-16 00:40:37', '2018-08-16 00:40:37', '[woocommerce_cart]', 'Carrito', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2018-08-16 00:40:37', '2018-08-16 00:40:37', '', 6, 'http://localhost:8888/2018/08/16/6-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2018-08-16 00:40:55', '2018-08-16 00:40:55', '[woocommerce_my_account]', 'Mi Cuenta', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2018-08-16 00:40:55', '2018-08-16 00:40:55', '', 8, 'http://localhost:8888/2018/08/16/8-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2018-08-16 00:41:14', '2018-08-16 00:41:14', '<h2>Who we are</h2><p>Our website address is: http://localhost:8888.</p><h2>What personal data we collect and why we collect it</h2><h3>Comentarios</h3><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><h3>Multimedia</h3><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><h3>Contact forms</h3><h3>Cookies</h3><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><p>If you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><h3>Embedded content from other websites</h3><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><h3>Analytics</h3><h2>Who we share your data with</h2><h2>How long we retain your data</h2><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><h2>What rights you have over your data</h2><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><h2>Where we send your data</h2><p>Visitor comments may be checked through an automated spam detection service.</p><h2>Your contact information</h2><h2>Additional information</h2><h3>How we protect your data</h3><h3>What data breach procedures we have in place</h3><h3>What third parties we receive data from</h3><h3>What automated decision making and/or profiling we do with user data</h3><h3>Industry regulatory disclosure requirements</h3>', 'Política de Privacidad', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2018-08-16 00:41:14', '2018-08-16 00:41:14', '', 3, 'http://localhost:8888/2018/08/16/3-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2018-08-16 00:41:30', '2018-08-16 00:41:30', '', 'Tienda', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-08-16 00:41:30', '2018-08-16 00:41:30', '', 5, 'http://localhost:8888/2018/08/16/5-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2018-08-16 00:41:54', '2018-08-16 00:41:54', '', 'Términos y Condiciones', '', 'publish', 'closed', 'closed', '', 'terminos-y-condiciones', '', '', '2018-08-16 00:43:55', '2018-08-16 00:43:55', '', 0, 'http://localhost:8888/?page_id=13', 0, 'page', '', 0),
(14, 1, '2018-08-16 00:41:54', '2018-08-16 00:41:54', '', 'Términos de Condiciones', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-08-16 00:41:54', '2018-08-16 00:41:54', '', 13, 'http://localhost:8888/2018/08/16/13-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2018-08-16 00:43:55', '2018-08-16 00:43:55', '', 'Términos y Condiciones', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2018-08-16 00:43:55', '2018-08-16 00:43:55', '', 13, 'http://localhost:8888/2018/08/16/13-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-08-16 02:20:11', '2018-08-16 02:20:11', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n\r\n<a class=\"btn-lg btn-success\" href=\"http://186.64.118.50/~feg7mariana/contacto\">Contáctanos</a>\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'publish', 'closed', 'closed', '', 'eventos', '', '', '2018-08-27 20:51:48', '2018-08-27 20:51:48', '', 0, 'http://localhost:8888/?page_id=18', 0, 'page', '', 0),
(19, 1, '2018-08-16 02:20:11', '2018-08-16 02:20:11', '', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-16 02:20:11', '2018-08-16 02:20:11', '', 18, 'http://localhost:8888/2018/08/16/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2018-08-16 02:20:30', '2018-08-16 02:20:30', '', 'Cumpleaños', '', 'trash', 'closed', 'closed', '', 'cumpleanos__trashed', '', '', '2018-08-22 18:07:46', '2018-08-22 18:07:46', '', 18, 'http://localhost:8888/?page_id=20', 0, 'page', '', 0),
(21, 1, '2018-08-16 02:20:30', '2018-08-16 02:20:30', '', 'Cumpleaños', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2018-08-16 02:20:30', '2018-08-16 02:20:30', '', 20, 'http://localhost:8888/2018/08/16/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2018-08-16 02:20:41', '2018-08-16 02:20:41', '', 'Matrimonios', '', 'trash', 'closed', 'closed', '', 'matrimonios__trashed', '', '', '2018-08-22 18:08:05', '2018-08-22 18:08:05', '', 18, 'http://localhost:8888/?page_id=22', 0, 'page', '', 0),
(23, 1, '2018-08-16 02:20:41', '2018-08-16 02:20:41', '', 'Matrimonios', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2018-08-16 02:20:41', '2018-08-16 02:20:41', '', 22, 'http://localhost:8888/2018/08/16/22-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2018-08-16 02:21:20', '2018-08-16 02:21:20', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nTenemos la convicción que la marca es parte importante de una empresa, es por esto que te invitamos a personalizar junto a nosotras tus productos en papelería con tu sello, porque tu marca lo vale!\r\n&nbsp;\r\n<a href=\"http://186.64.118.50/~feg7mariana/contacto/\" class=\"btn-lg btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-133 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6677-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Servicios Corporativos', '', 'publish', 'closed', 'closed', '', 'servicios-corporativos', '', '', '2018-08-23 19:53:53', '2018-08-23 19:53:53', '', 0, 'http://localhost:8888/?page_id=24', 0, 'page', '', 0),
(25, 1, '2018-08-16 02:21:20', '2018-08-16 02:21:20', '', 'Servicios Corporativos', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2018-08-16 02:21:20', '2018-08-16 02:21:20', '', 24, 'http://localhost:8888/2018/08/16/24-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2018-08-16 02:21:32', '2018-08-16 02:21:32', '', 'Coaching', '', 'publish', 'closed', 'closed', '', 'coaching', '', '', '2018-08-16 02:21:32', '2018-08-16 02:21:32', '', 0, 'http://localhost:8888/?page_id=26', 0, 'page', '', 0),
(27, 1, '2018-08-16 02:21:32', '2018-08-16 02:21:32', '', 'Coaching', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2018-08-16 02:21:32', '2018-08-16 02:21:32', '', 26, 'http://localhost:8888/2018/08/16/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2018-08-16 02:21:57', '2018-08-16 02:21:57', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Contáctanos</h2>\r\n&nbsp;\r\n\r\nPodemos ayudarte a generar tu planificador spñado, tu organizador personal o incluso, papelería personalizada para tus eventos! Cumpleaños, Bautizos, Matrimonios y Servicios Corporativos.\r\n</div>\r\n<div class=\" col-md-6\">[contact-form-7 id=\"234\" title=\"Formulario de contacto 1\"]</div>\r\n</div>\r\n</div>', 'Contacto', '', 'publish', 'closed', 'closed', '', 'contacto', '', '', '2018-08-23 19:29:19', '2018-08-23 19:29:19', '', 0, 'http://localhost:8888/?page_id=28', 0, 'page', '', 0),
(29, 1, '2018-08-16 02:21:57', '2018-08-16 02:21:57', '', 'Contacto', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2018-08-16 02:21:57', '2018-08-16 02:21:57', '', 28, 'http://localhost:8888/2018/08/16/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2018-08-16 02:22:47', '2018-08-16 02:22:47', '', 'Bautizos', '', 'trash', 'closed', 'closed', '', 'bautizos__trashed', '', '', '2018-08-22 18:07:58', '2018-08-22 18:07:58', '', 18, 'http://localhost:8888/?page_id=30', 0, 'page', '', 0),
(31, 1, '2018-08-16 02:22:47', '2018-08-16 02:22:47', '', 'Bautizos', '', 'inherit', 'closed', 'closed', '', '30-revision-v1', '', '', '2018-08-16 02:22:47', '2018-08-16 02:22:47', '', 30, 'http://localhost:8888/2018/08/16/30-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2018-08-16 02:23:50', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-08-16 02:23:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=32', 1, 'nav_menu_item', '', 0),
(34, 1, '2018-08-16 02:24:48', '2018-08-16 02:24:48', ' ', '', '', 'publish', 'closed', 'closed', '', '34', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://localhost:8888/?p=34', 4, 'nav_menu_item', '', 0),
(35, 1, '2018-08-16 02:24:47', '2018-08-16 02:24:47', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://localhost:8888/?p=35', 3, 'nav_menu_item', '', 0),
(39, 1, '2018-08-16 02:24:48', '2018-08-16 02:24:48', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://localhost:8888/?p=39', 5, 'nav_menu_item', '', 0),
(40, 1, '2018-08-16 02:24:48', '2018-08-16 02:24:48', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://localhost:8888/?p=40', 6, 'nav_menu_item', '', 0),
(43, 1, '2018-08-19 22:10:45', '2018-08-19 22:10:45', '<p style=\"text-align: center;\">Cuando el amor por la papelería se transforma en fanatismo<!--more--></p>\nSi te declaras un/a fanático/a de los papeles, lapices y libretas, disfrutas del olor a nuevo que expelen las hojas al moverlas, De Papel te podrá poner los pelos de punta con los mejores diseños hechos a mano.\n\n[gallery link=\"file\" ids=\"49,50,51\" orderby=\"rand\"]\n\n&nbsp;', 'El Amor por la Papelería', '', 'inherit', 'closed', 'closed', '', '1-autosave-v1', '', '', '2018-08-19 22:10:45', '2018-08-19 22:10:45', '', 1, 'http://localhost:8888/2018/08/19/1-autosave-v1/', 0, 'revision', '', 0),
(44, 1, '2018-08-19 21:41:53', '2018-08-19 21:41:53', '<p style=\"text-align: center;\">Cuando el amor por la papelería se transforma en fanatismo<!--more--></p>\r\nSi te declaras un/a fanático/a de los papeles, lapices y libretas, disfrutas del olor a nuevo que expelen las hojas al moverlas, De Papel te podrá poner los pelos de punta con los mejores diseños hechos a mano.\r\n\r\n&nbsp;', 'El Amor por la Papelería', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-08-19 21:41:53', '2018-08-19 21:41:53', '', 1, 'http://localhost:8888/2018/08/19/1-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2018-08-19 21:58:49', '2018-08-19 21:58:49', '', 'blog1', '', 'inherit', 'open', 'closed', '', 'blog1', '', '', '2018-08-19 21:58:49', '2018-08-19 21:58:49', '', 1, 'http://localhost:8888/wp-content/uploads/2018/08/blog1.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2018-08-19 22:09:36', '2018-08-19 22:09:36', '<p style=\"text-align: center;\">Creativas Emprenden, organizarán talleres y workshops en la V región<!--more--></p>\r\nPorque Amamos lo que hacemos es que hoy trabajamos intensamente en la organización de nuevos Talleres y Workshop que harán que nuestros emprendimientos crezcan cada vez más!!!\r\nCon mujeres emprendedoras y power que compartirán sus conocimientos y experiencias con nosotras.\r\nAtentas a las fechas porque no te los puedes perder!', 'Talleres y Workshops', '', 'publish', 'open', 'open', '', 'talleres-y-workshops', '', '', '2018-08-19 22:09:36', '2018-08-19 22:09:36', '', 0, 'http://localhost:8888/?p=46', 0, 'post', '', 0),
(47, 1, '2018-08-19 22:09:14', '2018-08-19 22:09:14', '', 'blog2', '', 'inherit', 'open', 'closed', '', 'blog2', '', '', '2018-08-19 22:09:14', '2018-08-19 22:09:14', '', 46, 'http://localhost:8888/wp-content/uploads/2018/08/blog2.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2018-08-19 22:09:36', '2018-08-19 22:09:36', '<p style=\"text-align: center;\">Creativas Emprenden, organizarán talleres y workshops en la V región<!--more--></p>\r\nPorque Amamos lo que hacemos es que hoy trabajamos intensamente en la organización de nuevos Talleres y Workshop que harán que nuestros emprendimientos crezcan cada vez más!!!\r\nCon mujeres emprendedoras y power que compartirán sus conocimientos y experiencias con nosotras.\r\nAtentas a las fechas porque no te los puedes perder!', 'Talleres y Workshops', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2018-08-19 22:09:36', '2018-08-19 22:09:36', '', 46, 'http://localhost:8888/46-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2018-08-19 22:10:12', '2018-08-19 22:10:12', '', 'galeria1', '', 'inherit', 'open', 'closed', '', 'galeria1', '', '', '2018-08-19 22:10:12', '2018-08-19 22:10:12', '', 1, 'http://localhost:8888/wp-content/uploads/2018/08/galeria1.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2018-08-19 22:10:15', '2018-08-19 22:10:15', '', 'galeria2', '', 'inherit', 'open', 'closed', '', 'galeria2', '', '', '2018-08-19 22:10:15', '2018-08-19 22:10:15', '', 1, 'http://localhost:8888/wp-content/uploads/2018/08/galeria2.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2018-08-19 22:10:18', '2018-08-19 22:10:18', '', 'galeria3', '', 'inherit', 'open', 'closed', '', 'galeria3', '', '', '2018-08-19 22:10:18', '2018-08-19 22:10:18', '', 1, 'http://localhost:8888/wp-content/uploads/2018/08/galeria3.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2018-08-19 22:10:48', '2018-08-19 22:10:48', '<p style=\"text-align: center;\">Cuando el amor por la papelería se transforma en fanatismo<!--more--></p>\r\nSi te declaras un/a fanático/a de los papeles, lapices y libretas, disfrutas del olor a nuevo que expelen las hojas al moverlas, De Papel te podrá poner los pelos de punta con los mejores diseños hechos a mano.\r\n\r\n[gallery link=\"file\" ids=\"49,50,51\" orderby=\"rand\"]\r\n\r\n&nbsp;', 'El Amor por la Papelería', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2018-08-19 22:10:48', '2018-08-19 22:10:48', '', 1, 'http://localhost:8888/1-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2018-08-21 00:55:13', '2018-08-21 00:55:13', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \".site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 0em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 00:55:13\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '35f3f0b1-3ef6-4946-82cd-b195c9aa2a72', '', '', '2018-08-21 00:55:13', '2018-08-21 00:55:13', '', 0, 'http://localhost:8888/35f3f0b1-3ef6-4946-82cd-b195c9aa2a72/', 0, 'customize_changeset', '', 0),
(54, 1, '2018-08-21 00:55:13', '2018-08-21 00:55:13', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media screen and (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n	\n	.product_title {\n		margin-top: 11.5em;\n	}\n	.woocommerce-product-gallery {\n		width: 21em;}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'publish', 'closed', 'closed', '', 'depapel-theme', '', '', '2018-08-23 19:03:05', '2018-08-23 19:03:05', '', 0, 'http://localhost:8888/depapel-theme/', 0, 'custom_css', '', 0),
(55, 1, '2018-08-21 00:55:13', '2018-08-21 00:55:13', '.site-main {\n	text-align: center;\n    padding: 9em 0 0em 0;\n    color: white;\n    background-color: darkcyan;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-21 00:55:13', '2018-08-21 00:55:13', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2018-08-21 01:00:51', '2018-08-21 01:00:51', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \".site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 0em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #add;\\n\\ttext-decoration: none;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 01:00:51\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4be43f45-b262-4b83-ba90-b06ce6a8a2e1', '', '', '2018-08-21 01:00:51', '2018-08-21 01:00:51', '', 0, 'http://localhost:8888/?p=56', 0, 'customize_changeset', '', 0),
(57, 1, '2018-08-21 01:00:51', '2018-08-21 01:00:51', '.site-main {\n	text-align: center;\n    padding: 9em 0 0em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #add;\n	text-decoration: none;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-21 01:00:51', '2018-08-21 01:00:51', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2018-08-21 01:01:53', '2018-08-21 01:01:53', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \".site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 0em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 01:01:52\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '25c3795e-9f89-4a45-82f9-7299b9a47e37', '', '', '2018-08-21 01:01:53', '2018-08-21 01:01:53', '', 0, 'http://localhost:8888/?p=58', 0, 'customize_changeset', '', 0),
(59, 1, '2018-08-21 01:01:54', '2018-08-21 01:01:54', '.site-main {\n	text-align: center;\n    padding: 9em 0 0em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-21 01:01:54', '2018-08-21 01:01:54', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2018-08-21 01:09:35', '2018-08-21 01:09:35', '{\n    \"woocommerce_shop_page_display\": {\n        \"value\": \"both\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 01:09:35\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4aa48e9f-ffdb-47f1-95ab-f495bdfbeb75', '', '', '2018-08-21 01:09:35', '2018-08-21 01:09:35', '', 0, 'http://localhost:8888/4aa48e9f-ffdb-47f1-95ab-f495bdfbeb75/', 0, 'customize_changeset', '', 0),
(61, 1, '2018-08-21 01:12:28', '2018-08-21 01:12:28', '{\n    \"sidebars_widgets[sidebar_widget]\": {\n        \"value\": [],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 01:12:28\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '38d28805-690c-4c11-aac8-69a39a49ad30', '', '', '2018-08-21 01:12:28', '2018-08-21 01:12:28', '', 0, 'http://localhost:8888/38d28805-690c-4c11-aac8-69a39a49ad30/', 0, 'customize_changeset', '', 0),
(62, 1, '2018-08-21 02:36:55', '2018-08-21 02:36:55', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \".site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 02:36:55\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8f86b405-6eaf-4da9-880b-e2c13b4aae72', '', '', '2018-08-21 02:36:55', '2018-08-21 02:36:55', '', 0, 'http://localhost:8888/8f86b405-6eaf-4da9-880b-e2c13b4aae72/', 0, 'customize_changeset', '', 0),
(63, 1, '2018-08-21 02:36:56', '2018-08-21 02:36:56', '.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-21 02:36:56', '2018-08-21 02:36:56', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2018-08-21 03:12:23', '2018-08-21 03:12:23', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-21 03:12:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8f6d68b8-79e0-416b-8395-8621dc1c981e', '', '', '2018-08-21 03:12:23', '2018-08-21 03:12:23', '', 0, 'http://localhost:8888/?p=64', 0, 'customize_changeset', '', 0),
(65, 1, '2018-08-21 03:12:24', '2018-08-21 03:12:24', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-21 03:12:24', '2018-08-21 03:12:24', '', 54, 'http://localhost:8888/54-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2018-08-22 17:37:57', '2018-08-22 17:37:57', '', '_MG_6613', '', 'inherit', 'open', 'closed', '', '_mg_6613', '', '', '2018-08-22 17:37:57', '2018-08-22 17:37:57', '', 66, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6613.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2018-08-22 18:00:19', '2018-08-22 18:00:19', '', 'Planificador Anual', '<span style=\"font-weight: 400;\">Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.</span>', 'inherit', 'closed', 'closed', '', '66-autosave-v1', '', '', '2018-08-22 18:00:19', '2018-08-22 18:00:19', '', 66, 'http://186.64.118.50/~feg7mariana/66-autosave-v1/', 0, 'revision', '', 0),
(69, 1, '2018-08-22 18:54:28', '2018-08-22 18:54:28', '[woocommerce_checkout]', 'Checkout', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2018-08-22 18:54:28', '2018-08-22 18:54:28', '', 7, 'http://186.64.118.50/~feg7mariana/7-revision-v1/', 0, 'revision', '', 0),
(70, 1, '2018-08-22 19:06:47', '2018-08-22 19:06:47', '', 'Tienda', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2018-08-22 19:45:27', '2018-08-22 19:45:27', '', 0, 'http://186.64.118.50/~feg7mariana/shop/', 0, 'page', '', 0),
(71, 1, '2018-08-22 19:31:34', '2018-08-22 19:31:34', '', 'Planificador Anual', '<span style=\"font-weight: 400;\">Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.\r\n<strong>Diseño:</strong> Flores</span>', 'publish', 'closed', 'closed', '', 'planificador-anual', '', '', '2018-08-23 15:38:38', '2018-08-23 15:38:38', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=product&#038;p=71', 0, 'product', '', 0),
(72, 1, '2018-08-22 19:32:47', '2018-08-22 19:32:47', ' ', '', '', 'publish', 'closed', 'closed', '', 'tienda', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://186.64.118.50/~feg7mariana/?p=72', 2, 'nav_menu_item', '', 0),
(73, 1, '2018-08-22 19:37:52', '2018-08-22 19:37:52', '{\n    \"woocommerce_default_catalog_orderby\": {\n        \"value\": \"price\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 19:37:39\"\n    },\n    \"woocommerce_catalog_columns\": {\n        \"value\": \"6\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 19:37:52\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'a4ded220-8217-47d8-8f40-c2d2993b2a6e', '', '', '2018-08-22 19:37:52', '2018-08-22 19:37:52', '', 0, 'http://186.64.118.50/~feg7mariana/?p=73', 0, 'customize_changeset', '', 0),
(74, 1, '2018-08-22 19:39:21', '0000-00-00 00:00:00', '{\n    \"woocommerce_single_image_width\": {\n        \"value\": \"500\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 19:39:21\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '3d484eae-78ad-47e8-aa95-d49021c55f0e', '', '', '2018-08-22 19:39:21', '0000-00-00 00:00:00', '', 0, 'http://186.64.118.50/~feg7mariana/?p=74', 0, 'customize_changeset', '', 0),
(75, 1, '2018-08-22 19:45:27', '2018-08-22 19:45:27', '', 'Tienda', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2018-08-22 19:45:27', '2018-08-22 19:45:27', '', 70, 'http://186.64.118.50/~feg7mariana/70-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2018-08-22 19:51:05', '2018-08-22 19:51:05', '', 'Categorías', '', 'trash', 'closed', 'closed', '', 'categorias__trashed', '', '', '2018-08-22 20:22:58', '2018-08-22 20:22:58', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=sidebar&#038;p=77', 0, 'sidebar', '', 0),
(78, 1, '2018-08-22 21:25:15', '2018-08-22 21:25:15', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:25:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'be437a8c-745a-439a-b050-d794675f02f3', '', '', '2018-08-22 21:25:15', '2018-08-22 21:25:15', '', 0, 'http://186.64.118.50/~feg7mariana/be437a8c-745a-439a-b050-d794675f02f3/', 0, 'customize_changeset', '', 0),
(79, 1, '2018-08-22 21:25:15', '2018-08-22 21:25:15', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:25:15', '2018-08-22 21:25:15', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2018-08-22 21:27:49', '2018-08-22 21:27:49', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n}\\n\\n.sidebar-wo ul, li {\\n\\tlist-style-type: circle;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:27:49\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'bc01b822-c7ea-4dc2-a869-7ab8992651cd', '', '', '2018-08-22 21:27:49', '2018-08-22 21:27:49', '', 0, 'http://186.64.118.50/~feg7mariana/?p=80', 0, 'customize_changeset', '', 0),
(81, 1, '2018-08-22 21:27:49', '2018-08-22 21:27:49', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n}\n\n.sidebar-wo ul, li {\n	list-style-type: circle;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:27:49', '2018-08-22 21:27:49', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2018-08-22 21:29:14', '2018-08-22 21:29:14', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: circle;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:29:14\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e41a1def-d87f-499c-b90a-64ac241d9662', '', '', '2018-08-22 21:29:14', '2018-08-22 21:29:14', '', 0, 'http://186.64.118.50/~feg7mariana/e41a1def-d87f-499c-b90a-64ac241d9662/', 0, 'customize_changeset', '', 0),
(83, 1, '2018-08-22 21:29:14', '2018-08-22 21:29:14', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: circle;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:29:14', '2018-08-22 21:29:14', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2018-08-22 21:30:04', '2018-08-22 21:30:04', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:30:04\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3e72fad0-ccff-405a-a1a3-a36a0d59f89b', '', '', '2018-08-22 21:30:04', '2018-08-22 21:30:04', '', 0, 'http://186.64.118.50/~feg7mariana/3e72fad0-ccff-405a-a1a3-a36a0d59f89b/', 0, 'customize_changeset', '', 0),
(85, 1, '2018-08-22 21:30:04', '2018-08-22 21:30:04', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:30:04', '2018-08-22 21:30:04', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2018-08-22 21:40:52', '2018-08-22 21:40:52', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.woocommerce-result-count {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:40:52\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4cdec270-6d06-44d2-bd82-a6e96194a24e', '', '', '2018-08-22 21:40:52', '2018-08-22 21:40:52', '', 0, 'http://186.64.118.50/~feg7mariana/4cdec270-6d06-44d2-bd82-a6e96194a24e/', 0, 'customize_changeset', '', 0),
(87, 1, '2018-08-22 21:40:52', '2018-08-22 21:40:52', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.woocommerce-result-count {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:40:52', '2018-08-22 21:40:52', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(88, 1, '2018-08-22 21:42:31', '2018-08-22 21:42:31', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:42:31\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '04220599-b0cb-4c9a-9472-cf4145dfe974', '', '', '2018-08-22 21:42:31', '2018-08-22 21:42:31', '', 0, 'http://186.64.118.50/~feg7mariana/04220599-b0cb-4c9a-9472-cf4145dfe974/', 0, 'customize_changeset', '', 0),
(89, 1, '2018-08-22 21:42:31', '2018-08-22 21:42:31', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:42:31', '2018-08-22 21:42:31', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2018-08-22 21:50:00', '2018-08-22 21:50:00', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:50:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '984246a6-c800-47da-a5eb-38aa933fd0c4', '', '', '2018-08-22 21:50:00', '2018-08-22 21:50:00', '', 0, 'http://186.64.118.50/~feg7mariana/?p=90', 0, 'customize_changeset', '', 0);
INSERT INTO `dp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(91, 1, '2018-08-22 21:50:00', '2018-08-22 21:50:00', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:50:00', '2018-08-22 21:50:00', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2018-08-22 21:53:46', '2018-08-22 21:53:46', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:53:46\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f7412b73-387a-4e71-931d-60c92f5b1aef', '', '', '2018-08-22 21:53:46', '2018-08-22 21:53:46', '', 0, 'http://186.64.118.50/~feg7mariana/?p=92', 0, 'customize_changeset', '', 0),
(93, 1, '2018-08-22 21:53:46', '2018-08-22 21:53:46', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:53:46', '2018-08-22 21:53:46', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2018-08-22 21:59:35', '2018-08-22 21:59:35', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 21:59:35\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'fbd7a5de-b6b2-4026-9ff8-cf825ec80221', '', '', '2018-08-22 21:59:35', '2018-08-22 21:59:35', '', 0, 'http://186.64.118.50/~feg7mariana/fbd7a5de-b6b2-4026-9ff8-cf825ec80221/', 0, 'customize_changeset', '', 0),
(95, 1, '2018-08-22 21:59:35', '2018-08-22 21:59:35', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 21:59:35', '2018-08-22 21:59:35', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2018-08-22 22:04:42', '2018-08-22 22:04:42', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover {\\n\\t  text-decoration: none;\\n    color: darkmagenta;\\n}\\n\\n\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:04:42\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '90412412-15b8-449a-ad73-9f8096fa8a27', '', '', '2018-08-22 22:04:42', '2018-08-22 22:04:42', '', 0, 'http://186.64.118.50/~feg7mariana/?p=96', 0, 'customize_changeset', '', 0),
(97, 1, '2018-08-22 22:04:42', '2018-08-22 22:04:42', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover {\n	  text-decoration: none;\n    color: darkmagenta;\n}\n\n\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:04:42', '2018-08-22 22:04:42', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2018-08-22 22:05:23', '2018-08-22 22:05:23', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:05:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'cd1b14d5-ef14-46d5-8c60-e4707f2939a2', '', '', '2018-08-22 22:05:23', '2018-08-22 22:05:23', '', 0, 'http://186.64.118.50/~feg7mariana/cd1b14d5-ef14-46d5-8c60-e4707f2939a2/', 0, 'customize_changeset', '', 0),
(99, 1, '2018-08-22 22:05:23', '2018-08-22 22:05:23', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:05:23', '2018-08-22 22:05:23', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2018-08-22 22:09:00', '2018-08-22 22:09:00', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .woocommerce-loop-product__title {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .woocommerce-loop-product__title:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:09:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'bf12ebeb-f661-4287-b4fb-219332f9752e', '', '', '2018-08-22 22:09:00', '2018-08-22 22:09:00', '', 0, 'http://186.64.118.50/~feg7mariana/bf12ebeb-f661-4287-b4fb-219332f9752e/', 0, 'customize_changeset', '', 0),
(101, 1, '2018-08-22 22:09:00', '2018-08-22 22:09:00', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .woocommerce-loop-product__title {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .woocommerce-loop-product__title:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:09:00', '2018-08-22 22:09:00', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2018-08-22 22:11:43', '2018-08-22 22:11:43', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:11:43\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ee4710ae-9bd3-4ea2-9991-0293f60dc1a2', '', '', '2018-08-22 22:11:43', '2018-08-22 22:11:43', '', 0, 'http://186.64.118.50/~feg7mariana/ee4710ae-9bd3-4ea2-9991-0293f60dc1a2/', 0, 'customize_changeset', '', 0),
(103, 1, '2018-08-22 22:11:43', '2018-08-22 22:11:43', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:11:43', '2018-08-22 22:11:43', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(104, 1, '2018-08-22 22:14:34', '2018-08-22 22:14:34', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:14:34\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '759ee850-8525-4278-99f3-23124b1b7b9c', '', '', '2018-08-22 22:14:34', '2018-08-22 22:14:34', '', 0, 'http://186.64.118.50/~feg7mariana/?p=104', 0, 'customize_changeset', '', 0),
(105, 1, '2018-08-22 22:14:34', '2018-08-22 22:14:34', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:14:34', '2018-08-22 22:14:34', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2018-08-22 22:22:44', '2018-08-22 22:22:44', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:22:44\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '4abcdf9a-46d6-421f-b2af-23e0c570b74e', '', '', '2018-08-22 22:22:44', '2018-08-22 22:22:44', '', 0, 'http://186.64.118.50/~feg7mariana/?p=106', 0, 'customize_changeset', '', 0),
(107, 1, '2018-08-22 22:22:44', '2018-08-22 22:22:44', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:22:44', '2018-08-22 22:22:44', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2018-08-22 22:25:09', '2018-08-22 22:25:09', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:25:09\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '38e5de73-8221-4f27-93c8-e85069862df0', '', '', '2018-08-22 22:25:09', '2018-08-22 22:25:09', '', 0, 'http://186.64.118.50/~feg7mariana/?p=108', 0, 'customize_changeset', '', 0),
(109, 1, '2018-08-22 22:25:09', '2018-08-22 22:25:09', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:25:09', '2018-08-22 22:25:09', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2018-08-22 22:36:27', '2018-08-22 22:36:27', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.posted_in {\\n\\tdisplay: none;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:36:27\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ecbae12e-7ccf-4572-b970-aacab2f2289e', '', '', '2018-08-22 22:36:27', '2018-08-22 22:36:27', '', 0, 'http://186.64.118.50/~feg7mariana/?p=110', 0, 'customize_changeset', '', 0),
(111, 1, '2018-08-22 22:36:27', '2018-08-22 22:36:27', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.posted_in {\n	display: none;\n}\n\n.woocommerce-result-count, .woocommerce-ordering {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:36:27', '2018-08-22 22:36:27', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2018-08-22 22:37:50', '2018-08-22 22:37:50', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:37:50\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd4f2ef59-c582-4869-97df-ecb7c2ab8ff7', '', '', '2018-08-22 22:37:50', '2018-08-22 22:37:50', '', 0, 'http://186.64.118.50/~feg7mariana/?p=112', 0, 'customize_changeset', '', 0),
(113, 1, '2018-08-22 22:37:50', '2018-08-22 22:37:50', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} ', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:37:50', '2018-08-22 22:37:50', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2018-08-22 22:42:23', '2018-08-22 22:42:23', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n    padding: 9em 0 1em 0;\\n    color: white;\\n    background-color: darkcyan;\\n}\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:42:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7a5b799b-127f-4613-ba52-d04b4ecf6fc8', '', '', '2018-08-22 22:42:23', '2018-08-22 22:42:23', '', 0, 'http://186.64.118.50/~feg7mariana/?p=114', 0, 'customize_changeset', '', 0),
(115, 1, '2018-08-22 22:42:23', '2018-08-22 22:42:23', '/* main wc */\n.site-main {\n	text-align: center;\n    padding: 9em 0 1em 0;\n    color: white;\n    background-color: darkcyan;\n}\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:42:23', '2018-08-22 22:42:23', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2018-08-22 22:45:07', '2018-08-22 22:45:07', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: lemonchiffon;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-22 22:45:07\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'bcbae33d-7aab-49ed-b78f-d885164b117c', '', '', '2018-08-22 22:45:07', '2018-08-22 22:45:07', '', 0, 'http://186.64.118.50/~feg7mariana/?p=116', 0, 'customize_changeset', '', 0),
(117, 1, '2018-08-22 22:45:07', '2018-08-22 22:45:07', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: lemonchiffon;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-22 22:45:07', '2018-08-22 22:45:07', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(119, 1, '2018-08-23 00:48:27', '2018-08-23 00:48:27', '<span style=\"font-weight: 400;\">Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</span>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 00:48:27', '2018-08-23 00:48:27', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2018-08-23 19:45:57', '2018-08-23 19:45:57', '<div class=\"container-fluid\">\n<div class=\"row\">\n<div id=\"quienes_somos1\" class=\" col-md-6\">\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\n&nbsp;\n\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\n&nbsp;\n<a href=\"<?php bloginfo( \'page\' );?>\" class=\"btn-md btn-success\">Contáctanos</a>\n\n\n</div>\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\n</div>\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-autosave-v1', '', '', '2018-08-23 19:45:57', '2018-08-23 19:45:57', '', 18, 'http://186.64.118.50/~feg7mariana/18-autosave-v1/', 0, 'revision', '', 0),
(121, 1, '2018-08-23 00:51:10', '2018-08-23 00:51:10', '<div class=\"description_page\"><p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p></div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 00:51:10', '2018-08-23 00:51:10', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2018-08-23 00:55:53', '2018-08-23 00:55:53', '<div class=\"container-fluid\">\r\n		<div class=\"row\">\r\n			<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n				<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n				<br/>\r\n				<p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p>	\r\n			</div>\r\n			<div id=\"quienes_somos2\" class=\" col-md-6\">\r\n				<img class=\"img-fluid quienes_somos2_img\" src=\"<?php bloginfo(\'template_url\')?>/assets/images/depapel-1.jpg\" alt=\"De papel Tienda\">		\r\n			</div>\r\n		</div>\r\n	</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 00:55:53', '2018-08-23 00:55:53', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(123, 1, '2018-08-23 00:58:09', '2018-08-23 00:58:09', '<div class=\"container-fluid\">\r\n		<div class=\"row\">\r\n			<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n				<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n				<br/>\r\n				<p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p>	\r\n			</div>\r\n		</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 00:58:09', '2018-08-23 00:58:09', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2018-08-23 01:00:32', '2018-08-23 01:00:32', '<div class=\"container-fluid\">\r\n		<div class=\"row\">\r\n			<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n				<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n				<br/>\r\n				<p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p>	\r\n			</div>\r\n                        <div id=\"quienes_somos2\" class=\" col-md-6\">\r\n\r\n</div>\r\n		</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 01:00:32', '2018-08-23 01:00:32', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2018-08-23 01:01:13', '2018-08-23 01:01:13', '<div class=\"container-fluid\">\r\n		<div class=\"row\">\r\n			<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n				<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n				<br/>\r\n				<p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p>	\r\n			</div>\r\n                        <div id=\"quienes_somos2\" class=\" col-md-6\">\r\n<img class=\"img-fluid quienes_somos2_img\" src=\"<?php bloginfo(\'template_url\')?>/assets/images/depapel-1.jpg\" alt=\"De papel Tienda\">\r\n</div>\r\n		</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 01:01:13', '2018-08-23 01:01:13', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2018-08-23 01:01:53', '2018-08-23 01:01:53', '<div class=\"container-fluid\">\r\n		<div class=\"row\">\r\n			<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n				<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n				<br/>\r\n				<p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p>	\r\n			</div>\r\n                        <div id=\"quienes_somos2\" class=\" col-md-6\">\r\n<img class=\"img-fluid\" src=\"<?php bloginfo(\'template_url\')?>/assets/images/depapel-1.jpg\" alt=\"De papel Tienda\">\r\n</div>\r\n		</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 01:01:53', '2018-08-23 01:01:53', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2018-08-23 01:04:07', '2018-08-23 01:04:07', '', '_MG_6684', '', 'inherit', 'open', 'closed', '', '_mg_6684', '', '', '2018-08-23 01:04:07', '2018-08-23 01:04:07', '', 18, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684.jpg', 0, 'attachment', 'image/jpeg', 0),
(128, 1, '2018-08-23 01:04:39', '2018-08-23 01:04:39', '<div class=\"container-fluid\">\r\n		<div class=\"row\">\r\n			<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n				<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n				<br/>\r\n				<p>Porque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.</p>	\r\n			</div>\r\n                        <div id=\"quienes_somos2\" class=\" col-md-6\">\r\n<img src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-300x200.jpg\" alt=\"\" width=\"300\" height=\"200\" class=\"alignnone size-medium wp-image-127\" />\r\n</div>\r\n		</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 01:04:39', '2018-08-23 01:04:39', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2018-08-23 01:05:59', '2018-08-23 01:05:59', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 01:05:59', '2018-08-23 01:05:59', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2018-08-23 01:06:41', '2018-08-23 01:06:41', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 01:06:41', '2018-08-23 01:06:41', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(131, 1, '2018-08-23 01:09:01', '2018-08-23 01:09:01', 'Esta es una página de ejemplo. Es diferente a una entrada del blog, ya que se quedará en un lugar y se mostrará en la navegación del sitio (en la mayoría de temas). La mayoría de personas empieza con una página \"Acerca de\" que brinda información a los visitantes. Se podría decir algo como esto:\n\n<blockquote>¡Hola! Durante el día soy un mensajero, un aspirante a actor por la noche, y este es mi blog. Vivo en Valparaíso, tengo un enorme perro llamado Pocho, y me gustan las cervezas muy heladas. (Y caminar por la playa.)</blockquote>\n\n...o algo como esto:\n\n<blockquote>La compañía XYZ, se fundó en 1971, y ha estado desde entonces, proporcionando artilugios de calidad al público. Está situada en la ciudad de Concepción, Chile y emplea a más de 2,000 personas. Hace todo tipo de cosas sorprendentes para la comunidad penquista.</blockquote>\n\nComo nuevo usuario de WordPress,  debes ir a <a href=\"http://localhost:8888/wp-admin/\">tu panel</a> para eliminar esta página y crear nuevas para tu contenido. ¡Que te diviertas!', 'Página de ejemplo', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-08-23 01:09:01', '2018-08-23 01:09:01', '', 2, 'http://186.64.118.50/~feg7mariana/2-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2018-08-23 01:10:19', '2018-08-23 01:10:19', '<div class=\"container-fluid\">\n<div class=\"row\">\n<div id=\"quienes_somos1\" class=\" col-md-6\">\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\n&nbsp;\n\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\n\n</div>\n<div id=\"quienes_somos2\" class=\" col-md-6\">\n\n</div>\n</div>\n</div>', 'Servicios Corporativos', '', 'inherit', 'closed', 'closed', '', '24-autosave-v1', '', '', '2018-08-23 01:10:19', '2018-08-23 01:10:19', '', 24, 'http://186.64.118.50/~feg7mariana/24-autosave-v1/', 0, 'revision', '', 0);
INSERT INTO `dp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(133, 1, '2018-08-23 01:10:23', '2018-08-23 01:10:23', '', '_MG_6677', '', 'inherit', 'open', 'closed', '', '_mg_6677', '', '', '2018-08-23 01:10:23', '2018-08-23 01:10:23', '', 24, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6677.jpg', 0, 'attachment', 'image/jpeg', 0),
(134, 1, '2018-08-23 01:11:30', '2018-08-23 01:11:30', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nTenemos la convicción que la marca es parte importante de una empresa, es por esto que te invitamos a personalizar junto a nosotras tus productos en papelería con tu sello, porque tu marca lo vale!\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-133 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6677-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Servicios Corporativos', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2018-08-23 01:11:30', '2018-08-23 01:11:30', '', 24, 'http://186.64.118.50/~feg7mariana/24-revision-v1/', 0, 'revision', '', 0),
(135, 1, '2018-08-23 14:56:35', '2018-08-23 14:56:35', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 14:56:35\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '2efeba96-9dd1-426c-9095-939fef1e4b6e', '', '', '2018-08-23 14:56:35', '2018-08-23 14:56:35', '', 0, 'http://186.64.118.50/~feg7mariana/2efeba96-9dd1-426c-9095-939fef1e4b6e/', 0, 'customize_changeset', '', 0),
(136, 1, '2018-08-23 14:56:35', '2018-08-23 14:56:35', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 14:56:35', '2018-08-23 14:56:35', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(137, 1, '2018-08-23 15:00:18', '2018-08-23 15:00:18', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 1em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 15:00:18\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f80722c9-601a-4185-8594-43d00b4482a1', '', '', '2018-08-23 15:00:18', '2018-08-23 15:00:18', '', 0, 'http://186.64.118.50/~feg7mariana/f80722c9-601a-4185-8594-43d00b4482a1/', 0, 'customize_changeset', '', 0),
(138, 1, '2018-08-23 15:00:18', '2018-08-23 15:00:18', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 1em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 15:00:18', '2018-08-23 15:00:18', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2018-08-23 15:02:15', '2018-08-23 15:02:15', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 15:02:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b265766e-653b-4515-9704-a5afd7d8f9b6', '', '', '2018-08-23 15:02:15', '2018-08-23 15:02:15', '', 0, 'http://186.64.118.50/~feg7mariana/b265766e-653b-4515-9704-a5afd7d8f9b6/', 0, 'customize_changeset', '', 0),
(140, 1, '2018-08-23 15:02:15', '2018-08-23 15:02:15', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 15:02:15', '2018-08-23 15:02:15', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2018-08-23 15:32:53', '2018-08-23 15:32:53', '', 'Planificador Anual', 'Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.\r\n<strong>Diseño:</strong> Jardín', 'publish', 'closed', 'closed', '', 'planificador-anual-2', '', '', '2018-08-23 15:37:28', '2018-08-23 15:37:28', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=product&#038;p=141', 0, 'product', '', 0),
(142, 1, '2018-08-23 15:23:27', '2018-08-23 15:23:27', '', '_MG_6674', '', 'inherit', 'open', 'closed', '', '_mg_6674', '', '', '2018-08-23 15:23:27', '2018-08-23 15:23:27', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6674.jpg', 0, 'attachment', 'image/jpeg', 0),
(143, 1, '2018-08-23 15:23:46', '2018-08-23 15:23:46', '', 'DSC_2989', '', 'inherit', 'open', 'closed', '', 'dsc_2989', '', '', '2018-08-23 15:23:46', '2018-08-23 15:23:46', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_2989.jpg', 0, 'attachment', 'image/jpeg', 0),
(144, 1, '2018-08-23 15:23:59', '2018-08-23 15:23:59', '', 'DSC_2990', '', 'inherit', 'open', 'closed', '', 'dsc_2990', '', '', '2018-08-23 15:23:59', '2018-08-23 15:23:59', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_2990.jpg', 0, 'attachment', 'image/jpeg', 0),
(145, 1, '2018-08-23 15:24:21', '2018-08-23 15:24:21', '', 'DSC_2991', '', 'inherit', 'open', 'closed', '', 'dsc_2991', '', '', '2018-08-23 15:24:21', '2018-08-23 15:24:21', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_2991.jpg', 0, 'attachment', 'image/jpeg', 0),
(146, 1, '2018-08-23 15:24:39', '2018-08-23 15:24:39', '', 'DSC_3014', '', 'inherit', 'open', 'closed', '', 'dsc_3014', '', '', '2018-08-23 15:24:39', '2018-08-23 15:24:39', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_3014.jpg', 0, 'attachment', 'image/jpeg', 0),
(147, 1, '2018-08-23 15:24:54', '2018-08-23 15:24:54', '', 'DSC_3064', '', 'inherit', 'open', 'closed', '', 'dsc_3064', '', '', '2018-08-23 15:24:54', '2018-08-23 15:24:54', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_3064.jpg', 0, 'attachment', 'image/jpeg', 0),
(148, 1, '2018-08-23 15:25:09', '2018-08-23 15:25:09', '', 'DSC_3105', '', 'inherit', 'open', 'closed', '', 'dsc_3105', '', '', '2018-08-23 15:25:09', '2018-08-23 15:25:09', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_3105.jpg', 0, 'attachment', 'image/jpeg', 0),
(149, 1, '2018-08-23 15:25:21', '2018-08-23 15:25:21', '', 'planificador_ANUAL3', '', 'inherit', 'open', 'closed', '', 'planificador_anual3', '', '', '2018-08-23 15:25:21', '2018-08-23 15:25:21', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/planificador_ANUAL3.jpg', 0, 'attachment', 'image/jpeg', 0),
(150, 1, '2018-08-23 15:25:38', '2018-08-23 15:25:38', '', 'planificador_ANUAL3_2', '', 'inherit', 'open', 'closed', '', 'planificador_anual3_2', '', '', '2018-08-23 15:25:38', '2018-08-23 15:25:38', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/planificador_ANUAL3_2.jpg', 0, 'attachment', 'image/jpeg', 0),
(151, 1, '2018-08-23 15:28:25', '2018-08-23 15:28:25', '', '_MG_6670', '', 'inherit', 'open', 'closed', '', '_mg_6670', '', '', '2018-08-23 15:28:25', '2018-08-23 15:28:25', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6670.jpg', 0, 'attachment', 'image/jpeg', 0),
(152, 1, '2018-08-23 15:28:43', '2018-08-23 15:28:43', '', '_MG_6676', '', 'inherit', 'open', 'closed', '', '_mg_6676', '', '', '2018-08-23 15:28:43', '2018-08-23 15:28:43', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6676.jpg', 0, 'attachment', 'image/jpeg', 0),
(153, 1, '2018-08-23 15:28:59', '2018-08-23 15:28:59', '', '_MG_6677', '', 'inherit', 'open', 'closed', '', '_mg_6677-2', '', '', '2018-08-23 15:28:59', '2018-08-23 15:28:59', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6677-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(154, 1, '2018-08-23 15:29:19', '2018-08-23 15:29:19', '', '_MG_6680', '', 'inherit', 'open', 'closed', '', '_mg_6680', '', '', '2018-08-23 15:29:19', '2018-08-23 15:29:19', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6680.jpg', 0, 'attachment', 'image/jpeg', 0),
(155, 1, '2018-08-23 15:29:32', '2018-08-23 15:29:32', '', 'DSC_3045', '', 'inherit', 'open', 'closed', '', 'dsc_3045', '', '', '2018-08-23 15:29:32', '2018-08-23 15:29:32', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_3045.jpg', 0, 'attachment', 'image/jpeg', 0),
(156, 1, '2018-08-23 15:29:52', '2018-08-23 15:29:52', '', 'DSC_3090', '', 'inherit', 'open', 'closed', '', 'dsc_3090', '', '', '2018-08-23 15:29:52', '2018-08-23 15:29:52', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/DSC_3090.jpg', 0, 'attachment', 'image/jpeg', 0),
(157, 1, '2018-08-23 15:30:06', '2018-08-23 15:30:06', '', 'galeria1', '', 'inherit', 'open', 'closed', '', 'galeria1-2', '', '', '2018-08-23 15:30:06', '2018-08-23 15:30:06', '', 141, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/galeria1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(158, 1, '2018-08-23 15:41:12', '2018-08-23 15:41:12', '', 'Planificador Anual', '<span style=\"font-weight: 400;\">Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.\r\n<strong>Diseño:</strong> Cielo</span>', 'publish', 'closed', 'closed', '', 'planificador-anual-3', '', '', '2018-08-23 15:44:09', '2018-08-23 15:44:09', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=product&#038;p=158', 0, 'product', '', 0),
(159, 1, '2018-08-23 15:39:42', '2018-08-23 15:39:42', '', 'planificador_ANUAL4_2', '', 'inherit', 'open', 'closed', '', 'planificador_anual4_2', '', '', '2018-08-23 15:39:42', '2018-08-23 15:39:42', '', 158, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/planificador_ANUAL4_2.jpg', 0, 'attachment', 'image/jpeg', 0),
(160, 1, '2018-08-23 15:43:33', '2018-08-23 15:43:33', '', 'Planificador Anual', '<span style=\"font-weight: 400;\">Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.\r\n<strong>Diseño:</strong> Selva</span>', 'publish', 'closed', 'closed', '', 'planificador-anual-4', '', '', '2018-08-23 15:43:34', '2018-08-23 15:43:34', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=product&#038;p=160', 0, 'product', '', 0),
(161, 1, '2018-08-23 15:42:30', '2018-08-23 15:42:30', '', 'planificador_ANUAL5', '', 'inherit', 'open', 'closed', '', 'planificador_anual5', '', '', '2018-08-23 15:42:30', '2018-08-23 15:42:30', '', 160, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/planificador_ANUAL5.jpg', 0, 'attachment', 'image/jpeg', 0),
(162, 1, '2018-08-23 15:49:20', '2018-08-23 15:49:20', '', 'Recetario', '<span style=\"font-weight: 400;\">Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.\r\n<strong>Diseño:</strong> Recetas</span>', 'publish', 'closed', 'closed', '', 'recetario', '', '', '2018-08-23 15:49:21', '2018-08-23 15:49:21', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=product&#038;p=162', 0, 'product', '', 0),
(163, 1, '2018-08-23 15:48:20', '2018-08-23 15:48:20', '', 'planificador_RECETAS2', '', 'inherit', 'open', 'closed', '', 'planificador_recetas2', '', '', '2018-08-23 15:48:20', '2018-08-23 15:48:20', '', 162, 'http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/planificador_RECETAS2.jpg', 0, 'attachment', 'image/jpeg', 0),
(164, 1, '2018-08-23 16:05:43', '2018-08-23 16:05:43', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:05:43\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '2f5f52e1-b8da-4d1d-9257-ec207ec7fbbe', '', '', '2018-08-23 16:05:43', '2018-08-23 16:05:43', '', 0, 'http://186.64.118.50/~feg7mariana/2f5f52e1-b8da-4d1d-9257-ec207ec7fbbe/', 0, 'customize_changeset', '', 0),
(165, 1, '2018-08-23 16:05:43', '2018-08-23 16:05:43', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:05:43', '2018-08-23 16:05:43', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(166, 1, '2018-08-23 16:10:50', '2018-08-23 16:10:50', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:10:50\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3526ad3f-a71f-4c9a-9854-9ab4e5b2701d', '', '', '2018-08-23 16:10:50', '2018-08-23 16:10:50', '', 0, 'http://186.64.118.50/~feg7mariana/3526ad3f-a71f-4c9a-9854-9ab4e5b2701d/', 0, 'customize_changeset', '', 0),
(167, 1, '2018-08-23 16:10:50', '2018-08-23 16:10:50', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:10:50', '2018-08-23 16:10:50', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(168, 1, '2018-08-23 16:12:39', '2018-08-23 16:12:39', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:12:39\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b6fe0bd5-3a48-40da-8e38-0608023cdfe6', '', '', '2018-08-23 16:12:39', '2018-08-23 16:12:39', '', 0, 'http://186.64.118.50/~feg7mariana/b6fe0bd5-3a48-40da-8e38-0608023cdfe6/', 0, 'customize_changeset', '', 0),
(169, 1, '2018-08-23 16:12:39', '2018-08-23 16:12:39', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:12:39', '2018-08-23 16:12:39', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(170, 1, '2018-08-23 16:20:30', '2018-08-23 16:20:30', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:20:30\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ddc0ddaf-ed88-4e98-bbbc-5037866eb617', '', '', '2018-08-23 16:20:30', '2018-08-23 16:20:30', '', 0, 'http://186.64.118.50/~feg7mariana/ddc0ddaf-ed88-4e98-bbbc-5037866eb617/', 0, 'customize_changeset', '', 0),
(171, 1, '2018-08-23 16:20:30', '2018-08-23 16:20:30', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:20:30', '2018-08-23 16:20:30', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(172, 1, '2018-08-23 16:24:29', '2018-08-23 16:24:29', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:24:29\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '39e8a450-89de-4dce-9ca8-3c30528fd455', '', '', '2018-08-23 16:24:29', '2018-08-23 16:24:29', '', 0, 'http://186.64.118.50/~feg7mariana/39e8a450-89de-4dce-9ca8-3c30528fd455/', 0, 'customize_changeset', '', 0),
(173, 1, '2018-08-23 16:24:29', '2018-08-23 16:24:29', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:24:29', '2018-08-23 16:24:29', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(174, 1, '2018-08-23 16:37:39', '2018-08-23 16:37:39', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:37:39\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '917ac38c-c899-4b4b-9507-4aa5c062a147', '', '', '2018-08-23 16:37:39', '2018-08-23 16:37:39', '', 0, 'http://186.64.118.50/~feg7mariana/?p=174', 0, 'customize_changeset', '', 0),
(175, 1, '2018-08-23 16:37:39', '2018-08-23 16:37:39', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:37:39', '2018-08-23 16:37:39', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(176, 1, '2018-08-23 16:39:24', '2018-08-23 16:39:24', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-active {\\n\\tmax-width: 60%;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:39:24\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0a69cd81-2ca9-44e5-99a1-c0d3b214a8cd', '', '', '2018-08-23 16:39:24', '2018-08-23 16:39:24', '', 0, 'http://186.64.118.50/~feg7mariana/0a69cd81-2ca9-44e5-99a1-c0d3b214a8cd/', 0, 'customize_changeset', '', 0),
(177, 1, '2018-08-23 16:39:24', '2018-08-23 16:39:24', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-active {\n	max-width: 60%;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:39:24', '2018-08-23 16:39:24', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(178, 1, '2018-08-23 16:40:22', '2018-08-23 16:40:22', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 60%;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:40:22\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '2fb0949d-f018-40cd-8826-9a041c015f5b', '', '', '2018-08-23 16:40:22', '2018-08-23 16:40:22', '', 0, 'http://186.64.118.50/~feg7mariana/2fb0949d-f018-40cd-8826-9a041c015f5b/', 0, 'customize_changeset', '', 0);
INSERT INTO `dp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(179, 1, '2018-08-23 16:40:22', '2018-08-23 16:40:22', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 60%;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:40:22', '2018-08-23 16:40:22', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(180, 1, '2018-08-23 16:44:11', '2018-08-23 16:44:11', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs {\\n\\tmax-width: 50%;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 60%;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:44:11\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b52c5af0-b4fb-4816-b12a-18bba55e3061', '', '', '2018-08-23 16:44:11', '2018-08-23 16:44:11', '', 0, 'http://186.64.118.50/~feg7mariana/?p=180', 0, 'customize_changeset', '', 0),
(181, 1, '2018-08-23 16:44:11', '2018-08-23 16:44:11', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs {\n	max-width: 50%;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 60%;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:44:11', '2018-08-23 16:44:11', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(182, 1, '2018-08-23 16:46:05', '2018-08-23 16:46:05', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs {\\n\\tmax-width: 50%;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 16:46:05\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '988db2ae-9844-4c43-8831-a3b6be317865', '', '', '2018-08-23 16:46:05', '2018-08-23 16:46:05', '', 0, 'http://186.64.118.50/~feg7mariana/988db2ae-9844-4c43-8831-a3b6be317865/', 0, 'customize_changeset', '', 0),
(183, 1, '2018-08-23 16:46:06', '2018-08-23 16:46:06', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs {\n	max-width: 50%;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 16:46:06', '2018-08-23 16:46:06', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(184, 1, '2018-08-23 17:10:34', '2018-08-23 17:10:34', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tmax-width: 50%;\\n  margin: auto;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs {\\n\\tmax-width: 50%;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:10:34\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ac9ff469-9f36-4581-b8a0-4b3df7d5ea24', '', '', '2018-08-23 17:10:34', '2018-08-23 17:10:34', '', 0, 'http://186.64.118.50/~feg7mariana/?p=184', 0, 'customize_changeset', '', 0),
(185, 1, '2018-08-23 17:10:34', '2018-08-23 17:10:34', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	max-width: 50%;\n  margin: auto;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs {\n	max-width: 50%;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:10:34', '2018-08-23 17:10:34', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(186, 1, '2018-08-23 17:15:25', '2018-08-23 17:15:25', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs {\\n\\tmax-width: 50%;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:15:25\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '30ff299d-90e8-4886-bc58-608ab9d2b055', '', '', '2018-08-23 17:15:25', '2018-08-23 17:15:25', '', 0, 'http://186.64.118.50/~feg7mariana/?p=186', 0, 'customize_changeset', '', 0),
(187, 1, '2018-08-23 17:15:25', '2018-08-23 17:15:25', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs {\n	max-width: 50%;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:15:25', '2018-08-23 17:15:25', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(188, 1, '2018-08-23 17:15:50', '2018-08-23 17:15:50', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs {\\n\\tmax-width: 50%;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:15:50\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '1fdb7f88-50b3-4df1-b874-e18bd3ed0dd9', '', '', '2018-08-23 17:15:50', '2018-08-23 17:15:50', '', 0, 'http://186.64.118.50/~feg7mariana/1fdb7f88-50b3-4df1-b874-e18bd3ed0dd9/', 0, 'customize_changeset', '', 0),
(189, 1, '2018-08-23 17:15:50', '2018-08-23 17:15:50', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs {\n	max-width: 50%;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:15:50', '2018-08-23 17:15:50', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(190, 1, '2018-08-23 17:17:06', '2018-08-23 17:17:06', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs {\\n\\tmax-width: 50%;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:17:06\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3f08b73d-2e51-4da3-ac9e-44906ddf38d4', '', '', '2018-08-23 17:17:06', '2018-08-23 17:17:06', '', 0, 'http://186.64.118.50/~feg7mariana/3f08b73d-2e51-4da3-ac9e-44906ddf38d4/', 0, 'customize_changeset', '', 0),
(191, 1, '2018-08-23 17:17:06', '2018-08-23 17:17:06', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs {\n	max-width: 50%;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:17:06', '2018-08-23 17:17:06', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(192, 1, '2018-08-23 17:18:13', '2018-08-23 17:18:13', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:18:13\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c94a0a49-df15-4121-8b19-70d3469c5878', '', '', '2018-08-23 17:18:13', '2018-08-23 17:18:13', '', 0, 'http://186.64.118.50/~feg7mariana/?p=192', 0, 'customize_changeset', '', 0),
(193, 1, '2018-08-23 17:18:13', '2018-08-23 17:18:13', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:18:13', '2018-08-23 17:18:13', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(194, 1, '2018-08-23 17:19:38', '2018-08-23 17:19:38', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:19:38\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'bdda962b-dcc3-40b1-90c1-6bcfd1ead6a7', '', '', '2018-08-23 17:19:38', '2018-08-23 17:19:38', '', 0, 'http://186.64.118.50/~feg7mariana/bdda962b-dcc3-40b1-90c1-6bcfd1ead6a7/', 0, 'customize_changeset', '', 0),
(195, 1, '2018-08-23 17:19:38', '2018-08-23 17:19:38', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:19:38', '2018-08-23 17:19:38', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(196, 1, '2018-08-23 17:20:39', '2018-08-23 17:20:39', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:20:39\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'f3de7637-7650-41da-9045-f66a91ba8fbc', '', '', '2018-08-23 17:20:39', '2018-08-23 17:20:39', '', 0, 'http://186.64.118.50/~feg7mariana/?p=196', 0, 'customize_changeset', '', 0),
(197, 1, '2018-08-23 17:20:39', '2018-08-23 17:20:39', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 2em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:20:39', '2018-08-23 17:20:39', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(198, 1, '2018-08-23 17:25:17', '2018-08-23 17:25:17', '{\n    \"woocommerce_single_image_width\": {\n        \"value\": \"200\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:25:14\"\n    },\n    \"woocommerce_thumbnail_image_width\": {\n        \"value\": \"100\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:25:17\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd8ef8741-7edb-40f4-9ca3-c72c1704a49b', '', '', '2018-08-23 17:25:17', '2018-08-23 17:25:17', '', 0, 'http://186.64.118.50/~feg7mariana/?p=198', 0, 'customize_changeset', '', 0),
(199, 1, '2018-08-23 17:27:33', '2018-08-23 17:27:33', '{\n    \"woocommerce_thumbnail_image_width\": {\n        \"value\": \"300\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:27:33\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'ac67c8c4-d2f4-493f-9590-69debc4ab16e', '', '', '2018-08-23 17:27:33', '2018-08-23 17:27:33', '', 0, 'http://186.64.118.50/~feg7mariana/ac67c8c4-d2f4-493f-9590-69debc4ab16e/', 0, 'customize_changeset', '', 0),
(200, 1, '2018-08-23 17:31:41', '2018-08-23 17:31:41', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:31:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'a8d5c21e-7b9a-402f-979c-8115695e0ffd', '', '', '2018-08-23 17:31:41', '2018-08-23 17:31:41', '', 0, 'http://186.64.118.50/~feg7mariana/a8d5c21e-7b9a-402f-979c-8115695e0ffd/', 0, 'customize_changeset', '', 0),
(201, 1, '2018-08-23 17:31:41', '2018-08-23 17:31:41', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:31:41', '2018-08-23 17:31:41', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(202, 1, '2018-08-23 17:32:52', '2018-08-23 17:32:52', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:32:52\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '721071e1-0b06-46aa-943e-2650c6cf4c44', '', '', '2018-08-23 17:32:52', '2018-08-23 17:32:52', '', 0, 'http://186.64.118.50/~feg7mariana/721071e1-0b06-46aa-943e-2650c6cf4c44/', 0, 'customize_changeset', '', 0);
INSERT INTO `dp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(203, 1, '2018-08-23 17:32:52', '2018-08-23 17:32:52', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:32:52', '2018-08-23 17:32:52', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(204, 1, '2018-08-23 17:33:17', '2018-08-23 17:33:17', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1.4em;\\n  line-height: 0;\\n  margin-top: 1em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:33:17\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'b65892d8-ecdb-4ab6-8f85-7340aa4d78db', '', '', '2018-08-23 17:33:17', '2018-08-23 17:33:17', '', 0, 'http://186.64.118.50/~feg7mariana/b65892d8-ecdb-4ab6-8f85-7340aa4d78db/', 0, 'customize_changeset', '', 0),
(205, 1, '2018-08-23 17:33:18', '2018-08-23 17:33:18', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1.4em;\n  line-height: 0;\n  margin-top: 1em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:33:18', '2018-08-23 17:33:18', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(206, 1, '2018-08-23 17:35:56', '2018-08-23 17:35:56', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:35:56\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '9fd0ec30-3c52-4250-a73d-2c69d734c004', '', '', '2018-08-23 17:35:56', '2018-08-23 17:35:56', '', 0, 'http://186.64.118.50/~feg7mariana/9fd0ec30-3c52-4250-a73d-2c69d734c004/', 0, 'customize_changeset', '', 0),
(207, 1, '2018-08-23 17:35:56', '2018-08-23 17:35:56', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:35:56', '2018-08-23 17:35:56', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(208, 1, '2018-08-23 17:37:22', '2018-08-23 17:37:22', '{\n    \"woocommerce_single_image_width\": {\n        \"value\": \"400\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:37:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'febcfe18-086c-42d3-908a-20f6914121a3', '', '', '2018-08-23 17:37:22', '2018-08-23 17:37:22', '', 0, 'http://186.64.118.50/~feg7mariana/?p=208', 0, 'customize_changeset', '', 0),
(209, 1, '2018-08-23 17:41:02', '2018-08-23 17:41:02', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: palevioletred;\\ncolor: white;\\ntext-transform: uppercase;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:41:02\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '70155475-4943-4f7d-abb6-b00a5633a6b0', '', '', '2018-08-23 17:41:02', '2018-08-23 17:41:02', '', 0, 'http://186.64.118.50/~feg7mariana/?p=209', 0, 'customize_changeset', '', 0),
(210, 1, '2018-08-23 17:41:02', '2018-08-23 17:41:02', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: palevioletred;\ncolor: white;\ntext-transform: uppercase;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:41:02', '2018-08-23 17:41:02', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2018-08-23 17:43:03', '2018-08-23 17:43:03', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:43:03\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'fed212da-8ed4-45f4-bbf2-a4b63d922eb2', '', '', '2018-08-23 17:43:03', '2018-08-23 17:43:03', '', 0, 'http://186.64.118.50/~feg7mariana/?p=211', 0, 'customize_changeset', '', 0),
(212, 1, '2018-08-23 17:43:03', '2018-08-23 17:43:03', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:43:03', '2018-08-23 17:43:03', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(213, 1, '2018-08-23 17:44:46', '2018-08-23 17:44:46', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:44:46\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '63f4b05e-84b8-4ce3-9b9b-70037d67b8db', '', '', '2018-08-23 17:44:46', '2018-08-23 17:44:46', '', 0, 'http://186.64.118.50/~feg7mariana/63f4b05e-84b8-4ce3-9b9b-70037d67b8db/', 0, 'customize_changeset', '', 0),
(214, 1, '2018-08-23 17:44:46', '2018-08-23 17:44:46', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:44:46', '2018-08-23 17:44:46', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(215, 1, '2018-08-23 17:46:38', '2018-08-23 17:46:38', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:46:38\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'af96728d-f3ca-4d8b-a1aa-584cde08b83c', '', '', '2018-08-23 17:46:38', '2018-08-23 17:46:38', '', 0, 'http://186.64.118.50/~feg7mariana/af96728d-f3ca-4d8b-a1aa-584cde08b83c/', 0, 'customize_changeset', '', 0),
(216, 1, '2018-08-23 17:46:38', '2018-08-23 17:46:38', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:46:38', '2018-08-23 17:46:38', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(217, 1, '2018-08-23 17:58:11', '2018-08-23 17:58:11', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 36em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 17:58:11\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c2fefd03-f039-495a-82d1-7f2c87b3460c', '', '', '2018-08-23 17:58:11', '2018-08-23 17:58:11', '', 0, 'http://186.64.118.50/~feg7mariana/c2fefd03-f039-495a-82d1-7f2c87b3460c/', 0, 'customize_changeset', '', 0),
(218, 1, '2018-08-23 17:58:12', '2018-08-23 17:58:12', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 36em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 17:58:12', '2018-08-23 17:58:12', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(219, 1, '2018-08-23 18:01:23', '2018-08-23 18:01:23', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 18:01:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd5a430e6-858e-4dfd-93cb-4905615ec16d', '', '', '2018-08-23 18:01:23', '2018-08-23 18:01:23', '', 0, 'http://186.64.118.50/~feg7mariana/d5a430e6-858e-4dfd-93cb-4905615ec16d/', 0, 'customize_changeset', '', 0),
(220, 1, '2018-08-23 18:01:23', '2018-08-23 18:01:23', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 18:01:23', '2018-08-23 18:01:23', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(221, 1, '2018-08-23 18:09:17', '2018-08-23 18:09:17', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 18:09:17\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '6dcb80c0-8736-4101-95a6-d03ca0fee864', '', '', '2018-08-23 18:09:17', '2018-08-23 18:09:17', '', 0, 'http://186.64.118.50/~feg7mariana/?p=221', 0, 'customize_changeset', '', 0),
(222, 1, '2018-08-23 18:09:17', '2018-08-23 18:09:17', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 18:09:17', '2018-08-23 18:09:17', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `dp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(223, 1, '2018-08-23 18:11:38', '2018-08-23 18:11:38', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n\\t\\n\\t.product_title {\\n\\t\\tmargin-top: 11.5em;\\n\\t}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 18:11:38\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'a0efae07-2a65-424e-9e62-50b87bc3e323', '', '', '2018-08-23 18:11:38', '2018-08-23 18:11:38', '', 0, 'http://186.64.118.50/~feg7mariana/?p=223', 0, 'customize_changeset', '', 0),
(224, 1, '2018-08-23 18:11:38', '2018-08-23 18:11:38', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n	\n	.product_title {\n		margin-top: 11.5em;\n	}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 18:11:38', '2018-08-23 18:11:38', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(225, 1, '2018-08-23 18:38:40', '0000-00-00 00:00:00', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n\\t.product_title {\\n\\t\\tmargin-top: 11.5em;\\n\\t}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 18:38:40\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', 'ed53dbd5-976e-40e4-bc43-5e3462d674ea', '', '', '2018-08-23 18:38:40', '2018-08-23 18:38:40', '', 0, 'http://186.64.118.50/~feg7mariana/?p=225', 0, 'customize_changeset', '', 0),
(226, 1, '2018-08-23 18:39:28', '2018-08-23 18:39:28', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n\\t\\n\\t.product_title {\\n\\t\\tmargin-top: 11.5em;\\n\\t}\\n\\t.woocommerce-product-gallery {\\n\\t\\twidth: 21em;}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 18:39:28\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'aef73cb8-c1a3-4c03-bf1c-8fb67559c636', '', '', '2018-08-23 18:39:28', '2018-08-23 18:39:28', '', 0, 'http://186.64.118.50/~feg7mariana/aef73cb8-c1a3-4c03-bf1c-8fb67559c636/', 0, 'customize_changeset', '', 0),
(227, 1, '2018-08-23 18:39:28', '2018-08-23 18:39:28', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n	\n	.product_title {\n		margin-top: 11.5em;\n	}\n	.woocommerce-product-gallery {\n		width: 21em;}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 18:39:28', '2018-08-23 18:39:28', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(228, 1, '2018-08-23 18:49:36', '2018-08-23 18:49:36', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n\\t\\n\\t.product_title {\\n\\t\\tmargin-top: 11.5em;\\n\\t}\\n\\t.woocommerce-product-gallery {\\n\\t\\twidth: 30em;}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 18:49:36\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'd1a66a04-4a3d-440a-8b5c-efe476574ec7', '', '', '2018-08-23 18:49:36', '2018-08-23 18:49:36', '', 0, 'http://186.64.118.50/~feg7mariana/d1a66a04-4a3d-440a-8b5c-efe476574ec7/', 0, 'customize_changeset', '', 0),
(229, 1, '2018-08-23 18:49:37', '2018-08-23 18:49:37', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n	\n	.product_title {\n		margin-top: 11.5em;\n	}\n	.woocommerce-product-gallery {\n		width: 30em;}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 18:49:37', '2018-08-23 18:49:37', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(230, 1, '2018-08-23 19:00:18', '2018-08-23 19:00:18', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n\\t\\n\\t.product_title {\\n\\t\\tmargin-top: 11.5em;\\n\\t}\\n\\t.woocommerce-product-gallery {\\n\\t\\twidth: 21em;}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 19:00:18\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '0b9cc89d-dbb9-49d9-8dbd-1a6a43e795a7', '', '', '2018-08-23 19:00:18', '2018-08-23 19:00:18', '', 0, 'http://186.64.118.50/~feg7mariana/0b9cc89d-dbb9-49d9-8dbd-1a6a43e795a7/', 0, 'customize_changeset', '', 0),
(231, 1, '2018-08-23 19:00:18', '2018-08-23 19:00:18', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n	\n	.product_title {\n		margin-top: 11.5em;\n	}\n	.woocommerce-product-gallery {\n		width: 21em;}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 19:00:18', '2018-08-23 19:00:18', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(232, 1, '2018-08-23 19:03:05', '2018-08-23 19:03:05', '{\n    \"custom_css[depapel-theme]\": {\n        \"value\": \"/* main wc */\\n.site-main {\\n\\ttext-align: center;\\n  padding: 9em 0 1em 0;\\n  color: white;\\n  background-color: darkcyan;\\n}\\n\\n\\n\\n.woocommerce-breadcrumb a {\\n\\tcolor: #add;\\n}\\n\\n.woocommerce-breadcrumb a:hover {\\n\\tcolor: #f3abe6;\\n\\ttext-decoration: none;\\n}\\n\\n/* tienda */\\n.sidebar-wo {\\n\\ttext-align:right;\\n\\tcolor: #ffffff;\\n  font-weight: 500;\\n  text-transform: uppercase;\\n  font-size: 76%;\\n\\tpadding-top: 3em;\\n}\\n\\n.contenedor-productos {\\n\\tmargin-top: 2em;\\n}\\n\\n.page-title, .header_1 h1 {\\n\\ttext-transform: uppercase;\\n  margin-bottom: 1.5em;\\n\\tfont-weight: 900;\\n  letter-spacing: 12px;\\n}\\n\\n.sidebar-wo ul, .sidebar-wo li {\\n\\tlist-style-type: none;\\n}\\n\\n.cat-item a, .products a, .count {\\n\\t  text-decoration: none;\\n    color: black;\\n}\\n\\n.cat-item a:hover, .products a:hover {\\n\\t  text-decoration: none;\\n    color: deeppink;\\n}\\n\\n.woocommerce-loop-product__title {\\n\\ttext-transform: uppercase;\\n  font-size: 1em;\\n  line-height: 0;\\n  margin-top: 1.5em;\\n}\\n\\n.product_title {\\n\\ttext-transform: uppercase;\\n  font-size: 2em;\\n}\\n\\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\\n\\tdisplay: none;\\n}\\n\\n.product {\\n\\tfloat: left;\\n\\tlist-style-type: none;\\n\\tmargin: 1em;\\n}\\n\\n/* single.php */\\n\\n#cont_single {\\n\\ttext-align: center;\\n} \\n\\n.entry-summary {\\n\\tpadding: 3em 2em 1em 30em;\\n\\tmax-width: 100%; \\n\\tmargin: 0; \\n}\\n\\n\\n@media screen and (max-width: 600px) {\\n\\t.entry-summary {\\n\\t\\tpadding: 1em 3em 1em 1em;\\n    max-width: 100%;\\n\\t}\\n\\t\\n\\t.product_title {\\n\\t\\tmargin-top: 11.5em;\\n\\t}\\n\\t.woocommerce-product-gallery {\\n\\t\\twidth: 21em;}\\n}\\n\\n.term-description {\\n\\tmax-width: 60%;\\n  margin: auto;\\n  text-align: justify;\\n  margin-bottom: 3em;\\n}\\n\\n.flex-control-thumbs li {\\n\\t float: left;\\n   list-style-type: none;\\n\\tmargin-top: 1em;\\n}\\n\\n.flex-control-thumbs li img {\\n\\tmax-width: 3em;\\n}\\n\\n.woocommerce-product-gallery {\\n\\twidth: 32em;\\n  float: left;\\n}\\n\\n.related {\\n\\tfloat: left;\\n}\\n\\n.related h2 {\\n\\ttext-transform: uppercase;\\n  font-size: 1.5em;\\n\\tmargin-top: 1em;\\n}\\n\\n.single_add_to_cart_button {\\nbackground-color: #5b2768;\\ncolor: #fff;\\n-webkit-font-smoothing: antialiased;\\ntext-transform: uppercase;\\nfont-weight: 900;\\nborder-radius: 8px;\\npadding: 0.5em;\\n}\\n\\n.attachment-woocommerce_thumbnail {\\n\\tmax-width: 100%;\\n\\theight:auto;\\n}\",\n        \"type\": \"custom_css\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2018-08-23 19:02:53\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '8c1301a9-075e-45a9-80c6-96eb70ed34bd', '', '', '2018-08-23 19:03:05', '2018-08-23 19:03:05', '', 0, 'http://186.64.118.50/~feg7mariana/?p=232', 0, 'customize_changeset', '', 0),
(233, 1, '2018-08-23 19:03:05', '2018-08-23 19:03:05', '/* main wc */\n.site-main {\n	text-align: center;\n  padding: 9em 0 1em 0;\n  color: white;\n  background-color: darkcyan;\n}\n\n\n\n.woocommerce-breadcrumb a {\n	color: #add;\n}\n\n.woocommerce-breadcrumb a:hover {\n	color: #f3abe6;\n	text-decoration: none;\n}\n\n/* tienda */\n.sidebar-wo {\n	text-align:right;\n	color: #ffffff;\n  font-weight: 500;\n  text-transform: uppercase;\n  font-size: 76%;\n	padding-top: 3em;\n}\n\n.contenedor-productos {\n	margin-top: 2em;\n}\n\n.page-title, .header_1 h1 {\n	text-transform: uppercase;\n  margin-bottom: 1.5em;\n	font-weight: 900;\n  letter-spacing: 12px;\n}\n\n.sidebar-wo ul, .sidebar-wo li {\n	list-style-type: none;\n}\n\n.cat-item a, .products a, .count {\n	  text-decoration: none;\n    color: black;\n}\n\n.cat-item a:hover, .products a:hover {\n	  text-decoration: none;\n    color: deeppink;\n}\n\n.woocommerce-loop-product__title {\n	text-transform: uppercase;\n  font-size: 1em;\n  line-height: 0;\n  margin-top: 1.5em;\n}\n\n.product_title {\n	text-transform: uppercase;\n  font-size: 2em;\n}\n\n.woocommerce-result-count, .woocommerce-ordering, .sku_wrapper, .posted_in  {\n	display: none;\n}\n\n.product {\n	float: left;\n	list-style-type: none;\n	margin: 1em;\n}\n\n/* single.php */\n\n#cont_single {\n	text-align: center;\n} \n\n.entry-summary {\n	padding: 3em 2em 1em 30em;\n	max-width: 100%; \n	margin: 0; \n}\n\n\n@media screen and (max-width: 600px) {\n	.entry-summary {\n		padding: 1em 3em 1em 1em;\n    max-width: 100%;\n	}\n	\n	.product_title {\n		margin-top: 11.5em;\n	}\n	.woocommerce-product-gallery {\n		width: 21em;}\n}\n\n.term-description {\n	max-width: 60%;\n  margin: auto;\n  text-align: justify;\n  margin-bottom: 3em;\n}\n\n.flex-control-thumbs li {\n	 float: left;\n   list-style-type: none;\n	margin-top: 1em;\n}\n\n.flex-control-thumbs li img {\n	max-width: 3em;\n}\n\n.woocommerce-product-gallery {\n	width: 32em;\n  float: left;\n}\n\n.related {\n	float: left;\n}\n\n.related h2 {\n	text-transform: uppercase;\n  font-size: 1.5em;\n	margin-top: 1em;\n}\n\n.single_add_to_cart_button {\nbackground-color: #5b2768;\ncolor: #fff;\n-webkit-font-smoothing: antialiased;\ntext-transform: uppercase;\nfont-weight: 900;\nborder-radius: 8px;\npadding: 0.5em;\n}\n\n.attachment-woocommerce_thumbnail {\n	max-width: 100%;\n	height:auto;\n}', 'depapel-theme', '', 'inherit', 'closed', 'closed', '', '54-revision-v1', '', '', '2018-08-23 19:03:05', '2018-08-23 19:03:05', '', 54, 'http://186.64.118.50/~feg7mariana/54-revision-v1/', 0, 'revision', '', 0),
(234, 1, '2018-08-23 19:16:42', '2018-08-23 19:16:42', '<label> Tu Nombre (requerido)\r\n    [text* your-name] </label>\r\n\r\n<label> Tu Correo (requerido)\r\n    [email* your-email] </label>\r\n\r\n<label> Asunto\r\n    [text your-subject] </label>\r\n\r\n<label> Tu Mensaje\r\n    [textarea your-message] </label>\r\n\r\n[submit \"Enviar\"]\n1\nDe Papel Tienda \"[your-subject]\"\n[your-name] <wordpress@186.64.118.50>\nTudepapel@gmail.com\nDe: [your-name] <[your-email]>\r\nAsunto: [your-subject]\r\n\r\nCuerpo del Mensaje\r\n[your-message]\r\n\r\n-- \r\nEste correo fue enviado utilizando contact form en De Papel Tienda (http://186.64.118.50/~feg7mariana)\nReply-To: [your-email]\n\n\n\n\nDe Papel Tienda \"[your-subject]\"\nDe Papel Tienda <wordpress@186.64.118.50>\n[your-email]\nCuerpo del Mensaje\r\n[your-message]\r\n\r\n-- \r\nEste correo fue enviado utilizando contact form en De Papel Tienda (http://186.64.118.50/~feg7mariana)\nReply-To: mariana.j.ambrosetti@gmail.com\n\n\n\nGracias por contactarnos, te responderemos a la brevedad :D\nHubo un error tratando de enviar el mensaje. Porfavor trata de nuevo.\nUno o más campos tienen un error. Porfavor revisa e intenta otra vez.\nHubo un error tratando de enviar el mensaje. Porfavor trata de nuevo.\nDebes aceptar los términos y condiciones antes de enviar el mensaje.\nEste campo es requerido.\nEste campo es muy largo.\nEste campo es muy corto.\nEl formato de fecha es incorrecto\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nEl código \nLa dirección ingresada es inválida.\nLa URL es inálida\nEl número es inválido.', 'Formulario de contacto 1', '', 'publish', 'closed', 'closed', '', 'formulario-de-contacto-1', '', '', '2018-08-23 19:22:22', '2018-08-23 19:22:22', '', 0, 'http://186.64.118.50/~feg7mariana/?post_type=wpcf7_contact_form&#038;p=234', 0, 'wpcf7_contact_form', '', 0),
(235, 1, '2018-08-23 19:23:55', '2018-08-23 19:23:55', '[contact-form-7 id=\"234\" title=\"Formulario de contacto 1\"]', 'Contacto', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2018-08-23 19:23:55', '2018-08-23 19:23:55', '', 28, 'http://186.64.118.50/~feg7mariana/28-revision-v1/', 0, 'revision', '', 0),
(236, 1, '2018-08-23 19:24:33', '2018-08-23 19:24:33', ' ', '', '', 'publish', 'closed', 'closed', '', '236', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://186.64.118.50/~feg7mariana/?p=236', 7, 'nav_menu_item', '', 0),
(237, 1, '2018-08-23 19:27:43', '2018-08-23 19:27:43', '<div class=\"container-fluid\">\n<div class=\"row\">\n<div id=\"quienes_somos1\" class=\" col-md-6\">\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\n&nbsp;\n\nTenemos la convicción que la marca es parte importante de una empresa, es por esto que te invitamos a personalizar junto a nosotras tus productos en papelería con tu sello, porque tu marca lo vale!\n</div>\n<div class=\" col-md-6\"> </div>\n</div>\n</div>\n[contact-form-7 id=\"234\" title=\"Formulario de contacto 1\"]', 'Contacto', '', 'inherit', 'closed', 'closed', '', '28-autosave-v1', '', '', '2018-08-23 19:27:43', '2018-08-23 19:27:43', '', 28, 'http://186.64.118.50/~feg7mariana/28-autosave-v1/', 0, 'revision', '', 0),
(238, 1, '2018-08-23 19:29:19', '2018-08-23 19:29:19', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Contáctanos</h2>\r\n&nbsp;\r\n\r\nPodemos ayudarte a generar tu planificador spñado, tu organizador personal o incluso, papelería personalizada para tus eventos! Cumpleaños, Bautizos, Matrimonios y Servicios Corporativos.\r\n</div>\r\n<div class=\" col-md-6\">[contact-form-7 id=\"234\" title=\"Formulario de contacto 1\"]</div>\r\n</div>\r\n</div>', 'Contacto', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2018-08-23 19:29:19', '2018-08-23 19:29:19', '', 28, 'http://186.64.118.50/~feg7mariana/28-revision-v1/', 0, 'revision', '', 0),
(239, 1, '2018-08-23 19:46:06', '2018-08-23 19:46:06', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n&nbsp;\r\n<a href=\"<?php bloginfo( \'page-contacto\' );?>\" class=\"btn-md btn-success\">Contáctanos</a>\r\n\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 19:46:06', '2018-08-23 19:46:06', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(240, 1, '2018-08-23 19:49:17', '2018-08-23 19:49:17', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n<a href=\"<?php bloginfo( \'page-contacto\' );?>\" class=\"btn-md btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 19:49:17', '2018-08-23 19:49:17', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(241, 1, '2018-08-23 19:50:50', '2018-08-23 19:50:50', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n<a href=\"#\" class=\"btn-md btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 19:50:50', '2018-08-23 19:50:50', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(242, 1, '2018-08-23 19:51:27', '2018-08-23 19:51:27', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n<a href=\"#\" class=\"btn-lg btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 19:51:27', '2018-08-23 19:51:27', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(243, 1, '2018-08-23 19:52:20', '2018-08-23 19:52:20', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n&nbsp;\r\n<a href=\"#\" class=\"btn-lg btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 19:52:20', '2018-08-23 19:52:20', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(244, 1, '2018-08-23 19:53:53', '2018-08-23 19:53:53', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nTenemos la convicción que la marca es parte importante de una empresa, es por esto que te invitamos a personalizar junto a nosotras tus productos en papelería con tu sello, porque tu marca lo vale!\r\n&nbsp;\r\n<a href=\"http://186.64.118.50/~feg7mariana/contacto/\" class=\"btn-lg btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-133 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6677-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Servicios Corporativos', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2018-08-23 19:53:53', '2018-08-23 19:53:53', '', 24, 'http://186.64.118.50/~feg7mariana/24-revision-v1/', 0, 'revision', '', 0),
(245, 1, '2018-08-23 19:54:23', '2018-08-23 19:54:23', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n&nbsp;\r\n<a href=\"http://186.64.118.50/~feg7mariana/contacto/\" class=\"btn-lg btn-success\">Contáctanos</a>\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-23 19:54:23', '2018-08-23 19:54:23', '', 18, 'http://186.64.118.50/~feg7mariana/18-revision-v1/', 0, 'revision', '', 0),
(246, 1, '2018-08-25 17:53:38', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2018-08-25 17:53:38', '0000-00-00 00:00:00', '', 0, 'http://186.64.118.50/~feg7mariana/?p=246', 0, 'post', '', 0),
(247, 1, '2018-08-27 04:47:37', '2018-08-27 04:47:37', '', 'Inicio', '', 'publish', 'closed', 'closed', '', 'inicio', '', '', '2018-08-27 04:47:37', '2018-08-27 04:47:37', '', 0, 'http://localhost:8888/?page_id=247', 0, 'page', '', 0),
(248, 1, '2018-08-27 04:47:37', '2018-08-27 04:47:37', '', 'Inicio', '', 'inherit', 'closed', 'closed', '', '247-revision-v1', '', '', '2018-08-27 04:47:37', '2018-08-27 04:47:37', '', 247, 'http://localhost:8888/247-revision-v1/', 0, 'revision', '', 0),
(249, 1, '2018-08-27 04:53:37', '2018-08-27 04:53:37', '', 'Inicio', '', 'publish', 'closed', 'closed', '', 'inicio-2', '', '', '2018-08-27 04:55:16', '2018-08-27 04:55:16', '', 0, 'http://localhost:8888/?p=249', 1, 'nav_menu_item', '', 0),
(250, 1, '2018-08-27 04:53:03', '0000-00-00 00:00:00', '', 'Inicio', '', 'draft', 'closed', 'closed', '', '', '', '', '2018-08-27 04:53:03', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=250', 1, 'nav_menu_item', '', 0),
(251, 1, '2018-08-27 20:50:09', '2018-08-27 20:50:09', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n\r\n<a class=\"btn-lg btn-success\" href=\"<?php bloginfo(\'url\')?>/contacto/\">Contáctanos</a>\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-27 20:50:09', '2018-08-27 20:50:09', '', 18, 'http://localhost:8888/18-revision-v1/', 0, 'revision', '', 0),
(252, 1, '2018-08-27 20:51:48', '2018-08-27 20:51:48', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div id=\"quienes_somos1\" class=\" col-md-6\">\r\n<h2>Cumpleaños, Bautizos y Matrimonios</h2>\r\n&nbsp;\r\n\r\nPorque sabemos que te gusta decorar tus eventos y celebraciones de manera especial, las personalizamos para ti y así disfrutes un momento único con tus seres queridos.\r\n\r\n<a class=\"btn-lg btn-success\" href=\"http://186.64.118.50/~feg7mariana/contacto\">Contáctanos</a>\r\n\r\n</div>\r\n<div id=\"quienes_somos2\" class=\" col-md-6\"><img class=\"img-fluid aligncenter wp-image-127 size-large\" src=\"http://186.64.118.50/~feg7mariana/wp-content/uploads/2018/08/MG_6684-1024x683.jpg\" alt=\"\" width=\"1024\" height=\"683\" /></div>\r\n</div>\r\n</div>', 'Eventos', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2018-08-27 20:51:48', '2018-08-27 20:51:48', '', 18, 'http://localhost:8888/18-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_termmeta`
--

CREATE TABLE `dp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_termmeta`
--

INSERT INTO `dp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(16, 27, 'order', '0'),
(17, 26, 'product_count_product_cat', '0'),
(18, 28, 'order', '0'),
(19, 28, 'display_type', ''),
(20, 28, 'thumbnail_id', '0'),
(24, 27, 'display_type', ''),
(25, 27, 'thumbnail_id', '0'),
(26, 30, 'order', '0'),
(27, 30, 'display_type', ''),
(28, 30, 'thumbnail_id', '0'),
(29, 31, 'order', '0'),
(30, 31, 'display_type', ''),
(31, 31, 'thumbnail_id', '0'),
(32, 27, 'product_count_product_cat', '5'),
(33, 28, 'product_count_product_cat', '4'),
(34, 30, 'product_count_product_cat', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_terms`
--

CREATE TABLE `dp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_terms`
--

INSERT INTO `dp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sin categoría', 'sin-categoria', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(20, 'Principal', 'principal', 0),
(21, 'Blog', 'blog', 0),
(22, 'simple', 'simple', 0),
(23, 'grouped', 'grouped', 0),
(24, 'variable', 'variable', 0),
(25, 'external', 'external', 0),
(26, 'Uncategorized', 'uncategorized', 0),
(27, 'Planificadores', 'planificadores', 0),
(28, 'Disponibles', 'disponibles', 0),
(30, 'Personalizados', 'personalizados', 0),
(31, 'Profesiones / Oficios', 'profesiones-oficios', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_term_relationships`
--

CREATE TABLE `dp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_term_relationships`
--

INSERT INTO `dp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 21, 0),
(34, 20, 0),
(35, 20, 0),
(39, 20, 0),
(40, 20, 0),
(46, 21, 0),
(71, 22, 0),
(71, 27, 0),
(71, 28, 0),
(72, 20, 0),
(141, 22, 0),
(141, 27, 0),
(141, 28, 0),
(158, 22, 0),
(158, 27, 0),
(158, 28, 0),
(160, 22, 0),
(160, 27, 0),
(160, 28, 0),
(162, 22, 0),
(162, 27, 0),
(162, 30, 0),
(236, 20, 0),
(249, 20, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_term_taxonomy`
--

CREATE TABLE `dp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_term_taxonomy`
--

INSERT INTO `dp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(20, 20, 'nav_menu', '', 0, 7),
(21, 21, 'category', '', 0, 2),
(22, 22, 'product_type', '', 0, 5),
(23, 23, 'product_type', '', 0, 0),
(24, 24, 'product_type', '', 0, 0),
(25, 25, 'product_type', '', 0, 0),
(26, 26, 'product_cat', '', 0, 0),
(27, 27, 'product_cat', '<span style=\"font-weight: 400;\">Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.</span>\r\n\r\n&nbsp;', 0, 5),
(28, 28, 'product_cat', 'Nuestros estilosos y únicos diseños disponibles para entrega inmediata así podrás comenzar a organizarte antes de lo que esperabas y volverte una mujer más productiva y la big boss de tu vida.\r\n\r\n', 27, 4),
(30, 30, 'product_cat', 'Nuestros lindos diseños personalizados para ti, con nombre y/o profesión en la portada, para que tengan un tu sello propio y organices con más entusiasmo tus días.\r\n', 27, 1),
(31, 31, 'product_cat', 'Te invitamos a planificar de manera diferente y personalizada tu vida profesional, con nuestros organizadores especiales para diferentes profesiones y oficios: enfermeras, psicólogas, profesoras, nutricionistas, estilistas, etc...', 27, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_usermeta`
--

CREATE TABLE `dp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_usermeta`
--

INSERT INTO `dp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'mjara'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'dp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'dp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"b8889b7654b3c8fd7a10a4466b118752e6623f197785dedd52e012c2a83e85cf\";a:4:{s:10:\"expiration\";i:1535747287;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:131:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36 OPR/54.0.2952.64\";s:5:\"login\";i:1535574487;}}'),
(17, 1, 'dp_dashboard_quick_press_last_post_id', '246'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, 'wc_last_active', '1535500800'),
(20, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:\"cart\";a:0:{}}'),
(21, 1, 'billing_first_name', ''),
(22, 1, 'billing_last_name', ''),
(23, 1, 'billing_company', ''),
(24, 1, 'billing_address_1', ''),
(25, 1, 'billing_address_2', ''),
(26, 1, 'billing_city', ''),
(27, 1, 'billing_postcode', ''),
(28, 1, 'billing_country', ''),
(29, 1, 'billing_state', ''),
(30, 1, 'billing_phone', ''),
(31, 1, 'billing_email', 'mariana.j.ambrosetti@gmail.com'),
(32, 1, 'shipping_first_name', ''),
(33, 1, 'shipping_last_name', ''),
(34, 1, 'shipping_company', ''),
(35, 1, 'shipping_address_1', ''),
(36, 1, 'shipping_address_2', ''),
(37, 1, 'shipping_city', ''),
(38, 1, 'shipping_postcode', ''),
(39, 1, 'shipping_country', ''),
(40, 1, 'shipping_state', ''),
(41, 1, 'last_update', '1534616130'),
(43, 1, 'dismissed_no_secure_connection_notice', '1'),
(44, 1, 'dp_yoast_notifications', 'a:4:{i:0;a:2:{s:7:\"message\";s:638:\"<p>Como puedes ver, hay una traducción de este plugin en Spanish (Chile). Esta traducción está actualmente completa al 42% . Necesitamos su ayuda para completarla y corregir cualquier error. Por favor, regístrate en <a href=\"https://translate.wordpress.org/projects/wp-plugins/wordpress-seo/\">Translating WordPress</a> para ayudar a completar la traducción de Spanish (Chile)!</p><p><a href=\"https://translate.wordpress.org/projects/wp-plugins/wordpress-seo/\">Regístrate ahora &raquo;</a></p><a class=\"button\" href=\"/wp-admin/admin.php?page=wpseo_licenses&#038;remove_i18n_promo=1\">Please don\'t show me this notification anymore</a>\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:31:\"i18nModuleTranslationAssistance\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:20:\"wpseo_manage_options\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:1182:\"Hemos observado que has estado usando Yoast SEO desde hace algún tiempo; ¡esperamos que te guste! ¡Nos encantaría que pudieras <a href=\"https://yoa.st/rate-yoast-seo?php_version=7.2.1&platform=wordpress&platform_version=4.9.8&software=free&software_version=8.1&role=administrator&days_active=14\">dejarnos una valoración de 5 estrellas en WordPress.org</a>!\n\nSi estás teniendo problemas, <a href=\"https://yoa.st/bugreport?php_version=7.2.1&platform=wordpress&platform_version=4.9.8&software=free&software_version=8.1&role=administrator&days_active=14\">por favor, envía un informe de fallos</a> y haremos todo lo posible para ayudarte.\n\nPor cierto, ¿sabías que también tenemos un <a href=\'https://yoa.st/premium-notification?php_version=7.2.1&platform=wordpress&platform_version=4.9.8&software=free&software_version=8.1&role=administrator&days_active=14\'>plugin Premium</a>? Ofrece funcionalidades avanzadas, como un gestor de redirecciones y compatibilidad con múltiples palabras clave. También incluye soporte personal 24/7.\n\n<a class=\"button\" href=\"http://localhost:8888/wp-admin/?page=wpseo_dashboard&yoast_dismiss=upsell\">Por favor, no me muestres más este aviso</a>\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:19:\"wpseo-upsell-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.8000000000000000444089209850062616169452667236328125;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:2;a:2:{s:7:\"message\";s:450:\"Yoast SEO y WooCommerce pueden funcionar juntos mucho mejor añadiendo un plugin que les ayude. Por favor, instala Yoast WooCommerce SEO para hacer tu vida más fácil. <a href=\"https://yoa.st/1o0?php_version=7.2.1&platform=wordpress&platform_version=4.9.8&software=free&software_version=8.1&role=administrator&days_active=14\" aria-label=\"Más información sobre Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">Más información</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:3;a:2:{s:7:\"message\";s:175:\"No te pierdas los errores de rastreo. <a href=\"http://localhost:8888/wp-admin/admin.php?page=wpseo_search_console&tab=settings\">Conecta aquí con la Google Search Console</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:17:\"wpseo-dismiss-gsc\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}'),
(45, 1, 'show_try_gutenberg_panel', '0'),
(46, 1, 'meta-box-order_dashboard', 'a:4:{s:6:\"normal\";s:44:\"dashboard_right_now,wpseo-dashboard-overview\";s:4:\"side\";s:124:\"woocommerce_dashboard_status,woocommerce_dashboard_recent_reviews,dashboard_quick_press,dashboard_activity,dashboard_primary\";s:7:\"column3\";s:0:\"\";s:7:\"column4\";s:0:\"\";}'),
(47, 1, 'closedpostboxes_dashboard', 'a:3:{i:0;s:18:\"dashboard_activity\";i:1;s:21:\"dashboard_quick_press\";i:2;s:17:\"dashboard_primary\";}'),
(48, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(49, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(50, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-product_cat\";i:3;s:15:\"add-product_tag\";}'),
(51, 1, 'nav_menu_recently_edited', '20'),
(52, 1, '_yoast_wpseo_profile_updated', '1534616130'),
(53, 1, 'wpseo_title', ''),
(54, 1, 'wpseo_metadesc', ''),
(55, 1, 'wpseo_noindex_author', ''),
(56, 1, 'wpseo_content_analysis_disable', ''),
(57, 1, 'wpseo_keyword_analysis_disable', ''),
(58, 1, 'googleplus', ''),
(59, 1, 'twitter', ''),
(60, 1, 'facebook', ''),
(61, 1, 'dp_user-settings', 'libraryContent=browse&editor=html'),
(62, 1, 'dp_user-settings-time', '1535403006'),
(63, 1, 'meta-box-order_product', 'a:3:{s:4:\"side\";s:84:\"submitdiv,product_catdiv,tagsdiv-product_tag,postimagediv,woocommerce-product-images\";s:6:\"normal\";s:66:\"wpseo_meta,postcustom,woocommerce-product-data,slugdiv,postexcerpt\";s:8:\"advanced\";s:0:\"\";}'),
(64, 1, 'screen_layout_product', '2'),
(65, 1, 'dismissed_no_shipping_methods_notice', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_users`
--

CREATE TABLE `dp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_users`
--

INSERT INTO `dp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'mjara', '$P$BK7o8NR07PvHfvioKiIeJ2AJROXJ9c/', 'mjara', 'mariana.j.ambrosetti@gmail.com', '', '2018-08-09 17:28:30', '', 0, 'mjara');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wc_download_log`
--

CREATE TABLE `dp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wc_webhooks`
--

CREATE TABLE `dp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfbadleechers`
--

CREATE TABLE `dp_wfbadleechers` (
  `eMin` int(10) UNSIGNED NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfblockedcommentlog`
--

CREATE TABLE `dp_wfblockedcommentlog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `unixday` int(10) UNSIGNED NOT NULL,
  `blockType` varchar(50) NOT NULL DEFAULT 'gsb'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfblockediplog`
--

CREATE TABLE `dp_wfblockediplog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `unixday` int(10) UNSIGNED NOT NULL,
  `blockType` varchar(50) NOT NULL DEFAULT 'generic'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfblocks7`
--

CREATE TABLE `dp_wfblocks7` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) UNSIGNED DEFAULT '0',
  `blockedHits` int(10) UNSIGNED DEFAULT '0',
  `expiration` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `parameters` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfconfig`
--

CREATE TABLE `dp_wfconfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  `autoload` enum('no','yes') NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `dp_wfconfig`
--

INSERT INTO `dp_wfconfig` (`name`, `val`, `autoload`) VALUES
('activatingIP', 0x3132372e302e302e31, 'yes'),
('actUpdateInterval', 0x32, 'yes'),
('addCacheComment', 0x30, 'yes'),
('adminNoticeQueue', 0x613a303a7b7d, 'yes'),
('advancedCommentScanning', 0x31, 'yes'),
('ajaxWatcherDisabled_admin', 0x30, 'yes'),
('ajaxWatcherDisabled_front', 0x30, 'yes'),
('alertEmails', 0x54756465706170656c40676d61696c2e636f6d, 'yes'),
('alertOn_adminLogin', 0x31, 'yes'),
('alertOn_block', 0x31, 'yes'),
('alertOn_breachLogin', 0x31, 'yes'),
('alertOn_critical', 0x31, 'yes'),
('alertOn_firstAdminLoginOnly', 0x30, 'yes'),
('alertOn_firstNonAdminLoginOnly', 0x30, 'yes'),
('alertOn_loginLockout', 0x31, 'yes'),
('alertOn_lostPasswdForm', 0x31, 'yes'),
('alertOn_nonAdminLogin', 0x30, 'yes'),
('alertOn_throttle', 0x30, 'yes'),
('alertOn_update', 0x30, 'yes'),
('alertOn_warnings', 0x31, 'yes'),
('alertOn_wordfenceDeactivated', 0x31, 'yes'),
('alert_maxHourly', 0x30, 'yes'),
('allowed404s', 0x2f66617669636f6e2e69636f0a2f6170706c652d746f7563682d69636f6e2a2e706e670a2f2a4032782e706e670a2f62726f77736572636f6e6669672e786d6c, 'yes'),
('allowed404s6116Migration', 0x31, 'yes'),
('allowHTTPSCaching', 0x30, 'yes'),
('allowMySQLi', 0x31, 'yes'),
('allScansScheduled', 0x613a323a7b693a303b613a323a7b733a393a2274696d657374616d70223b693a313533343538363430303b733a343a2261726773223b613a313a7b693a303b693a313533343538363430303b7d7d693a313b613a323a7b733a393a2274696d657374616d70223b693a313533343834353630303b733a343a2261726773223b613a313a7b693a303b693a313533343834353630303b7d7d7d, 'yes'),
('apiKey', 0x65343337336436623334616263643335326534373763303136386165636563336537353438393465663238643033666139646466363733346332336439393737663934663362623663636639333137356232376561306463326562636132376163326532353531646361396231386263323138326139356638633238653133353738346337616633393539633333336532346262663139386135383636366332, 'yes'),
('autoBlockScanners', 0x31, 'yes'),
('autoUpdate', 0x30, 'yes'),
('autoUpdateAttempts', 0x30, 'yes'),
('autoUpdateChoice', 0x31, 'yes'),
('bannedURLs', '', 'yes'),
('betaThreatDefenseFeed', 0x30, 'yes'),
('blockedTime', 0x333030, 'yes'),
('blockFakeBots', 0x30, 'yes'),
('blocks702Migration', 0x31, 'yes'),
('cacheType', 0x64697361626c6564, 'yes'),
('cbl_action', 0x626c6f636b, 'yes'),
('cbl_bypassRedirDest', '', 'yes'),
('cbl_bypassRedirURL', '', 'yes'),
('cbl_bypassViewURL', '', 'yes'),
('cbl_cookieVal', 0x35623734363364396564343136, 'yes'),
('cbl_loggedInBlocked', '', 'yes'),
('cbl_redirURL', '', 'yes'),
('cbl_restOfSiteBlocked', 0x31, 'yes'),
('checkSpamIP', 0x31, 'yes'),
('config701Migration', 0x31, 'yes'),
('currentCronKey', '', 'yes'),
('dashboardData', 0x613a343a7b733a393a2267656e657261746564223b693a313533343335343238323b733a333a22746466223b613a333a7b733a393a22636f6d6d756e697479223b693a353636383b733a373a227072656d69756d223b693a353636393b733a393a22626c61636b6c697374223b693a333639383b7d733a31303a2261747461636b64617461223b613a333a7b733a333a22323468223b613a32343a7b693a303b613a323a7b733a313a2274223b693a313533343236363030303b733a313a2263223b693a333130383130303b7d693a313b613a323a7b733a313a2274223b693a313533343236393630303b733a313a2263223b693a333139383233303b7d693a323b613a323a7b733a313a2274223b693a313533343237333230303b733a313a2263223b693a333131313436383b7d693a333b613a323a7b733a313a2274223b693a313533343237363830303b733a313a2263223b693a323833393732373b7d693a343b613a323a7b733a313a2274223b693a313533343238303430303b733a313a2263223b693a323834323331313b7d693a353b613a323a7b733a313a2274223b693a313533343238343030303b733a313a2263223b693a323932373436383b7d693a363b613a323a7b733a313a2274223b693a313533343238373630303b733a313a2263223b693a333037383638313b7d693a373b613a323a7b733a313a2274223b693a313533343239313230303b733a313a2263223b693a333131303035313b7d693a383b613a323a7b733a313a2274223b693a313533343239343830303b733a313a2263223b693a333039393436343b7d693a393b613a323a7b733a313a2274223b693a313533343239383430303b733a313a2263223b693a333137303436383b7d693a31303b613a323a7b733a313a2274223b693a313533343330323030303b733a313a2263223b693a333235353431393b7d693a31313b613a323a7b733a313a2274223b693a313533343330353630303b733a313a2263223b693a333237303838363b7d693a31323b613a323a7b733a313a2274223b693a313533343330393230303b733a313a2263223b693a333138303330303b7d693a31333b613a323a7b733a313a2274223b693a313533343331323830303b733a313a2263223b693a333034383536303b7d693a31343b613a323a7b733a313a2274223b693a313533343331363430303b733a313a2263223b693a333139303638303b7d693a31353b613a323a7b733a313a2274223b693a313533343332303030303b733a313a2263223b693a333236343636343b7d693a31363b613a323a7b733a313a2274223b693a313533343332333630303b733a313a2263223b693a333331323238303b7d693a31373b613a323a7b733a313a2274223b693a313533343332373230303b733a313a2263223b693a333432313131353b7d693a31383b613a323a7b733a313a2274223b693a313533343333303830303b733a313a2263223b693a333434303038393b7d693a31393b613a323a7b733a313a2274223b693a313533343333343430303b733a313a2263223b693a333439333138393b7d693a32303b613a323a7b733a313a2274223b693a313533343333383030303b733a313a2263223b693a333439383039303b7d693a32313b613a323a7b733a313a2274223b693a313533343334313630303b733a313a2263223b693a333232333130363b7d693a32323b613a323a7b733a313a2274223b693a313533343334353230303b733a313a2263223b693a333430313636353b7d693a32333b613a323a7b733a313a2274223b693a313533343334383830303b733a313a2263223b693a333131313637333b7d7d733a323a223764223b613a373a7b693a303b613a323a7b733a313a2274223b693a313533333638363430303b733a313a2263223b693a37333236383030303b7d693a313b613a323a7b733a313a2274223b693a313533333737323830303b733a313a2263223b693a37363237333730353b7d693a323b613a323a7b733a313a2274223b693a313533333835393230303b733a313a2263223b693a37323138383038363b7d693a333b613a323a7b733a313a2274223b693a313533333934353630303b733a313a2263223b693a37323239313133383b7d693a343b613a323a7b733a313a2274223b693a313533343033323030303b733a313a2263223b693a37363433353335383b7d693a353b613a323a7b733a313a2274223b693a313533343131383430303b733a313a2263223b693a37393636393839373b7d693a363b613a323a7b733a313a2274223b693a313533343230343830303b733a313a2263223b693a37373934323233363b7d7d733a333a22333064223b613a33303a7b693a303b613a323a7b733a313a2274223b693a313533313639393230303b733a313a2263223b693a37303034383938333b7d693a313b613a323a7b733a313a2274223b693a313533313738353630303b733a313a2263223b693a37333831343634353b7d693a323b613a323a7b733a313a2274223b693a313533313837323030303b733a313a2263223b693a37333830313638393b7d693a333b613a323a7b733a313a2274223b693a313533313935383430303b733a313a2263223b693a37323737303332303b7d693a343b613a323a7b733a313a2274223b693a313533323034343830303b733a313a2263223b693a37323630383830363b7d693a353b613a323a7b733a313a2274223b693a313533323133313230303b733a313a2263223b693a37353737373739373b7d693a363b613a323a7b733a313a2274223b693a313533323231373630303b733a313a2263223b693a37373031373835313b7d693a373b613a323a7b733a313a2274223b693a313533323330343030303b733a313a2263223b693a37333230343536333b7d693a383b613a323a7b733a313a2274223b693a313533323339303430303b733a313a2263223b693a36353839313636333b7d693a393b613a323a7b733a313a2274223b693a313533323437363830303b733a313a2263223b693a36373136353739333b7d693a31303b613a323a7b733a313a2274223b693a313533323536333230303b733a313a2263223b693a37313036363236313b7d693a31313b613a323a7b733a313a2274223b693a313533323634393630303b733a313a2263223b693a37313838313137393b7d693a31323b613a323a7b733a313a2274223b693a313533323733363030303b733a313a2263223b693a36383838303230303b7d693a31333b613a323a7b733a313a2274223b693a313533323832323430303b733a313a2263223b693a37303930373139333b7d693a31343b613a323a7b733a313a2274223b693a313533323930383830303b733a313a2263223b693a37353637383236343b7d693a31353b613a323a7b733a313a2274223b693a313533323939353230303b733a313a2263223b693a37323534323037393b7d693a31363b613a323a7b733a313a2274223b693a313533333038313630303b733a313a2263223b693a36393937323031363b7d693a31373b613a323a7b733a313a2274223b693a313533333136383030303b733a313a2263223b693a37303833333131373b7d693a31383b613a323a7b733a313a2274223b693a313533333235343430303b733a313a2263223b693a36393136343633373b7d693a31393b613a323a7b733a313a2274223b693a313533333334303830303b733a313a2263223b693a36373130313537383b7d693a32303b613a323a7b733a313a2274223b693a313533333432373230303b733a313a2263223b693a36363136303832313b7d693a32313b613a323a7b733a313a2274223b693a313533333531333630303b733a313a2263223b693a36373339383039363b7d693a32323b613a323a7b733a313a2274223b693a313533333630303030303b733a313a2263223b693a36383439363331313b7d693a32333b613a323a7b733a313a2274223b693a313533333638363430303b733a313a2263223b693a37333236383030303b7d693a32343b613a323a7b733a313a2274223b693a313533333737323830303b733a313a2263223b693a37363237333730353b7d693a32353b613a323a7b733a313a2274223b693a313533333835393230303b733a313a2263223b693a37323138383038363b7d693a32363b613a323a7b733a313a2274223b693a313533333934353630303b733a313a2263223b693a37323239313133383b7d693a32373b613a323a7b733a313a2274223b693a313533343033323030303b733a313a2263223b693a37363433353335383b7d693a32383b613a323a7b733a313a2274223b693a313533343131383430303b733a313a2263223b693a37393636393839373b7d693a32393b613a323a7b733a313a2274223b693a313533343230343830303b733a313a2263223b693a37373934323233363b7d7d7d733a393a22636f756e7472696573223b613a313a7b733a323a223764223b613a31303a7b693a303b613a323a7b733a323a226364223b733a323a225553223b733a323a226374223b693a38303537353033323b7d693a313b613a323a7b733a323a226364223b733a323a22434e223b733a323a226374223b693a37353631333731303b7d693a323b613a323a7b733a323a226364223b733a323a225541223b733a323a226374223b693a35393938333530393b7d693a333b613a323a7b733a323a226364223b733a323a224945223b733a323a226374223b693a35373439303234373b7d693a343b613a323a7b733a323a226364223b733a323a225255223b733a323a226374223b693a35343637333634303b7d693a353b613a323a7b733a323a226364223b733a323a225452223b733a323a226374223b693a33353631363432333b7d693a363b613a323a7b733a323a226364223b733a323a22504c223b733a323a226374223b693a32313337383832373b7d693a373b613a323a7b733a323a226364223b733a323a224652223b733a323a226374223b693a32313035343238323b7d693a383b613a323a7b733a323a226364223b733a323a224445223b733a323a226374223b693a31383836363230373b7d693a393b613a323a7b733a323a226364223b733a323a224252223b733a323a226374223b693a31363638333535363b7d7d7d7d, 'yes'),
('dbTest', 0x613a313a7b733a353a226e6f6e6365223b733a36343a2239336363616364386432623661633535636663636264326362646332333833393036343061366464373935373466376266373030626130313566383466613061223b7d, 'no'),
('dbVersion', 0x352e362e33342d6c6f67, 'yes'),
('debugOn', 0x30, 'yes'),
('deleteTablesOnDeact', 0x30, 'yes'),
('detectProxyNextCheck', 0x31353334393539323033, 'no'),
('detectProxyNonce', 0x64343564333933323838306433333531363762363333363831656133383734333638353832353330663561643534636164663735626237353236626161326534, 'no'),
('detectProxyRecommendation', 0x4445464552524544, 'no'),
('disableCodeExecutionUploads', 0x30, 'yes'),
('disableConfigCaching', 0x30, 'yes'),
('disableCookies', 0x30, 'yes'),
('disableWAFIPBlocking', 0x30, 'yes'),
('dismissAutoPrependNotice', 0x30, 'yes'),
('displayAutomaticBlocks', 0x31, 'yes'),
('displayTopLevelBlocking', 0x30, 'yes'),
('displayTopLevelLiveTraffic', 0x30, 'yes'),
('displayTopLevelOptions', 0x31, 'yes'),
('email_summary_dashboard_widget_enabled', 0x31, 'yes'),
('email_summary_enabled', 0x31, 'yes'),
('email_summary_excluded_directories', 0x77702d636f6e74656e742f63616368652c77702d636f6e74656e742f77666c6f6773, 'yes'),
('email_summary_interval', 0x7765656b6c79, 'yes'),
('encKey', 0x38313032613465646663393230323464, 'yes'),
('fileContentsGSB6315Migration', 0x31, 'yes'),
('firewallEnabled', 0x31, 'yes'),
('geoIPVersionHash', 0x66343639356135643564653831353830383536376161613230373432383333663433363136393566636538323838623362633932306561666235653261616166, 'yes'),
('howGetIPs', '', 'yes'),
('howGetIPs_trusted_proxies', '', 'yes'),
('isPaid', '', 'yes'),
('keyType', 0x66726565, 'yes'),
('lastBlockAggregation', 0x31353334333534343031, 'yes'),
('lastDailyCron', 0x31353334333534343636, 'yes'),
('lastDashboardCheck', 0x31353334333534343638, 'yes'),
('lastScanCompleted', 0x6f6b, 'yes'),
('lastScanFailureType', '', 'yes'),
('liveActivityPauseEnabled', 0x31, 'yes'),
('liveTrafficEnabled', 0x31, 'yes'),
('liveTraf_displayExpandedRecords', 0x30, 'no'),
('liveTraf_ignoreIPs', '', 'yes'),
('liveTraf_ignorePublishers', 0x31, 'yes'),
('liveTraf_ignoreUA', '', 'yes'),
('liveTraf_ignoreUsers', '', 'yes'),
('liveTraf_maxAge', 0x3330, 'yes'),
('liveTraf_maxRows', 0x32303030, 'yes'),
('loginSecurityEnabled', 0x31, 'yes'),
('loginSec_blockAdminReg', 0x31, 'yes'),
('loginSec_breachPasswds', 0x61646d696e73, 'yes'),
('loginSec_breachPasswds_enabled', 0x31, 'yes'),
('loginSec_countFailMins', 0x323430, 'yes'),
('loginSec_disableAuthorScan', 0x31, 'yes'),
('loginSec_disableOEmbedAuthor', 0x30, 'yes'),
('loginSec_enableSeparateTwoFactor', '', 'yes'),
('loginSec_lockInvalidUsers', 0x30, 'yes'),
('loginSec_lockoutMins', 0x323430, 'yes'),
('loginSec_maskLoginErrors', 0x31, 'yes'),
('loginSec_maxFailures', 0x3230, 'yes'),
('loginSec_maxForgotPasswd', 0x3230, 'yes'),
('loginSec_requireAdminTwoFactor', 0x30, 'yes'),
('loginSec_strongPasswds', 0x70756273, 'yes'),
('loginSec_strongPasswds_enabled', 0x31, 'yes'),
('loginSec_userBlacklist', '', 'yes'),
('longEncKey', 0x63346564366633366639313764333132353063343232633833376634313164353737653633636230386637663235306335376265393732353562663466313364, 'yes'),
('lowResourceScansEnabled', 0x30, 'yes'),
('lowResourceScanWaitStep', '', 'yes'),
('manualScanType', 0x6f6e63654461696c79, 'yes'),
('max404Crawlers', 0x44495341424c4544, 'yes'),
('max404Crawlers_action', 0x7468726f74746c65, 'yes'),
('max404Humans', 0x44495341424c4544, 'yes'),
('max404Humans_action', 0x7468726f74746c65, 'yes'),
('maxExecutionTime', 0x30, 'yes'),
('maxGlobalRequests', 0x44495341424c4544, 'yes'),
('maxGlobalRequests_action', 0x7468726f74746c65, 'yes'),
('maxMem', 0x323536, 'yes'),
('maxRequestsCrawlers', 0x44495341424c4544, 'yes'),
('maxRequestsCrawlers_action', 0x7468726f74746c65, 'yes'),
('maxRequestsHumans', 0x44495341424c4544, 'yes'),
('maxRequestsHumans_action', 0x7468726f74746c65, 'yes'),
('maxScanHits', 0x44495341424c4544, 'yes'),
('maxScanHits_action', 0x7468726f74746c65, 'yes'),
('migration636_email_summary_excluded_directories', 0x31, 'no'),
('needsNewTour_blocking', 0x31, 'yes'),
('needsNewTour_dashboard', 0x31, 'yes'),
('needsNewTour_firewall', 0x31, 'yes'),
('needsNewTour_livetraffic', 0x31, 'yes'),
('needsNewTour_scan', 0x31, 'yes'),
('needsUpgradeTour_blocking', 0x30, 'yes'),
('needsUpgradeTour_dashboard', 0x30, 'yes'),
('needsUpgradeTour_firewall', 0x30, 'yes'),
('needsUpgradeTour_livetraffic', 0x30, 'yes'),
('needsUpgradeTour_scan', 0x30, 'yes'),
('neverBlockBG', 0x6e65766572426c6f636b5665726966696564, 'yes'),
('noc1ScanSchedule', 0x613a323a7b693a303b693a313533343538363430303b693a313b693a313533343834353630303b7d, 'yes'),
('notification_blogHighlights', 0x31, 'yes'),
('notification_productUpdates', 0x31, 'yes'),
('notification_promotions', 0x31, 'yes'),
('notification_scanStatus', 0x31, 'yes'),
('notification_securityAlerts', 0x31, 'yes'),
('notification_updatesNeeded', 0x31, 'yes'),
('onboardingAttempt1', 0x6c6963656e7365, 'yes'),
('onboardingAttempt2', '', 'no'),
('onboardingAttempt3', '', 'no'),
('onboardingAttempt3Initial', 0x30, 'yes'),
('other_blockBadPOST', 0x30, 'yes'),
('other_bypassLitespeedNoabort', 0x30, 'yes'),
('other_hideWPVersion', 0x30, 'yes'),
('other_noAnonMemberComments', 0x31, 'yes'),
('other_pwStrengthOnUpdate', 0x31, 'yes'),
('other_scanComments', 0x31, 'yes'),
('other_scanOutside', 0x30, 'yes'),
('other_WFNet', 0x31, 'yes'),
('scansEnabled_checkGSB', 0x31, 'yes'),
('scansEnabled_checkHowGetIPs', 0x31, 'yes'),
('scansEnabled_checkReadableConfig', 0x31, 'yes'),
('scansEnabled_comments', 0x31, 'yes'),
('scansEnabled_core', 0x31, 'yes'),
('scansEnabled_coreUnknown', 0x31, 'yes'),
('scansEnabled_diskSpace', 0x31, 'yes'),
('scansEnabled_dns', 0x31, 'yes'),
('scansEnabled_fileContents', 0x31, 'yes'),
('scansEnabled_fileContentsGSB', 0x31, 'yes'),
('scansEnabled_highSense', 0x30, 'yes'),
('scansEnabled_malware', 0x31, 'yes'),
('scansEnabled_oldVersions', 0x31, 'yes'),
('scansEnabled_options', 0x31, 'yes'),
('scansEnabled_passwds', 0x31, 'yes'),
('scansEnabled_plugins', 0x30, 'yes'),
('scansEnabled_posts', 0x31, 'yes'),
('scansEnabled_scanImages', 0x30, 'yes'),
('scansEnabled_suspectedFiles', 0x31, 'yes'),
('scansEnabled_suspiciousAdminUsers', 0x31, 'yes'),
('scansEnabled_suspiciousOptions', 0x31, 'yes'),
('scansEnabled_themes', 0x30, 'yes'),
('scansEnabled_wpscan_directoryListingEnabled', 0x31, 'yes'),
('scansEnabled_wpscan_fullPathDisclosure', 0x31, 'yes'),
('scanTime', 0x313533343335343438372e32343737, 'yes'),
('scanType', 0x7374616e64617264, 'yes'),
('scan_exclude', '', 'yes'),
('scan_include_extra', '', 'yes'),
('scan_maxDuration', '', 'yes'),
('scan_maxIssues', 0x31303030, 'yes'),
('schedMode', 0x6175746f, 'yes'),
('schedStartHour', 0x37, 'yes'),
('scheduledScansEnabled', 0x31, 'yes'),
('serverIP', 0x313533343335343430363b3139302e3136312e3233302e3838, 'yes'),
('showAdminBarMenu', 0x31, 'yes'),
('spamvertizeCheck', 0x31, 'yes'),
('ssl_verify', 0x31, 'yes'),
('startScansRemotely', 0x30, 'yes'),
('supportContent', 0x7b22746f70223a5b7b227469746c65223a224920616d206c6f636b6564206f7574206f66206d792073697465222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f726174652d6c696d6974696e675c2f23692d616d2d6c6f636b65642d6f75742d6f662d6d792d73697465222c226f72646572223a307d2c7b227469746c65223a22576f726466656e63652037222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f74726f75626c6573686f6f74696e675c2f776f726466656e63652d375c2f222c226f72646572223a317d2c7b227469746c65223a22576f726466656e636520576562204170706c69636174696f6e204669726577616c6c202857414629222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f222c226f72646572223a327d2c7b227469746c65223a225363616e2054726f75626c6573686f6f74696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f74726f75626c6573686f6f74696e675c2f222c226f72646572223a337d2c7b227469746c65223a224f7074696d697a696e6720546865204669726577616c6c222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f6f7074696d697a696e672d7468652d6669726577616c6c5c2f222c226f72646572223a347d2c7b227469746c65223a225363616e20526573756c7473222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f7363616e2d726573756c74735c2f222c226f72646572223a357d2c7b227469746c65223a2250485020466174616c206572726f723a204661696c6564206f70656e696e6720726571756972656420776f726466656e63652d7761662e706870222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f237068702d666174616c2d6572726f722d6661696c65642d6f70656e696e672d72657175697265642d776f726466656e63652d7761662d706870222c226f72646572223a367d5d2c22616c6c223a5b7b227469746c65223a22576f726466656e636520616e642047445052202d2047656e6572616c20446174612050726f74656374696f6e20526567756c6174696f6e222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f67656e6572616c2d646174612d70726f74656374696f6e2d726567756c6174696f6e5c2f222c2265786365727074223a2244656669616e742c2074686520636f6d70616e7920626568696e6420576f726466656e63652c20686173207570646174656420697473207465726d73206f66207573652c207072697661637920706f6c696369657320616e6420736f6674776172652c2061732077656c6c206173206d61646520617661696c61626c65206120646174612070726f63657373696e672061677265656d656e7420746f206d656574204744505220636f6d706c69616e63652e20437573746f6d657273206d7573742072657669657720616e6420616772656520746f2075706461746564207465726d7320696e206f7264657220746f20636f6e74696e7565207573696e67206f75722070726f647563747320616e642073657276696365732e20576520616c736f2070726f76696465206120646174612070726f63657373696e672061677265656d656e7420696620796f75207175616c6966792061732061206461746120636f6e74726f6c6c657220756e6465722074686520474450522e222c226f72646572223a307d2c7b227469746c65223a2244617368626f617264222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f64617368626f6172645c2f222c2265786365727074223a2254686520576f726466656e63652044617368626f6172642070726f766964657320696e736967687420696e746f207468652063757272656e74207374617465206f6620796f75722073697465e28099732073656375726974792e222c226368696c6472656e223a5b7b227469746c65223a224f7074696f6e73222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f64617368626f6172645c2f6f7074696f6e735c2f222c226f72646572223a307d2c7b227469746c65223a22416c65727473222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f64617368626f6172645c2f616c657274735c2f222c226f72646572223a317d5d2c226f72646572223a317d2c7b227469746c65223a224669726577616c6c222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f222c2265786365727074223a2254686520576f726466656e636520576562204170706c69636174696f6e204669726577616c6c2069732061205048502062617365642c206170706c69636174696f6e206c6576656c206669726577616c6c20746861742066696c74657273206f7574206d616c6963696f757320726571756573747320746f20796f757220736974652e20222c226368696c6472656e223a5b7b227469746c65223a224f7074696d697a696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f6f7074696d697a696e672d7468652d6669726577616c6c5c2f222c226f72646572223a307d2c7b227469746c65223a224c6561726e696e67204d6f6465222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f6c6561726e696e672d6d6f64655c2f222c226f72646572223a317d2c7b227469746c65223a2253746174697374696373222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f737461746973746963735c2f222c226f72646572223a327d2c7b227469746c65223a224f7074696f6e73222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f6f7074696f6e735c2f222c226f72646572223a337d2c7b227469746c65223a22427275746520466f7263652050726f74656374696f6e222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f62727574652d666f7263655c2f222c226f72646572223a347d2c7b227469746c65223a2252617465204c696d6974696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f726174652d6c696d6974696e675c2f222c226f72646572223a357d2c7b227469746c65223a2254726f75626c6573686f6f74696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f6669726577616c6c5c2f74726f75626c6573686f6f74696e675c2f222c226f72646572223a367d5d2c226f72646572223a327d2c7b227469746c65223a22426c6f636b696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f626c6f636b696e675c2f222c2265786365727074223a2241736964652066726f6d20746865204669726577616c6c2072756c657320746861742070726f7465637420616761696e73742053514c2d696e6a656374696f6e2c2058535320616e64206d6f72652c20576f726466656e636520616c736f2068617320637573746f6d20666561747572657320666f72206164646974696f6e616c20626c6f636b696e672e20222c226368696c6472656e223a5b7b227469746c65223a22426c6f636b6564206f72204c6f636b6564204f7574222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f626c6f636b696e675c2f626c6f636b65642d6f722d6c6f636b65642d6f75745c2f222c226f72646572223a307d2c7b227469746c65223a22436f756e74727920426c6f636b696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f626c6f636b696e675c2f636f756e7472792d626c6f636b696e675c2f222c226f72646572223a317d2c7b227469746c65223a2254726f75626c6573686f6f74696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f626c6f636b696e675c2f74726f75626c6573686f6f74696e675c2f222c226f72646572223a327d5d2c226f72646572223a337d2c7b227469746c65223a225363616e222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f222c2265786365727074223a224120576f726466656e6365207363616e206578616d696e657320616c6c2066696c6573206f6e20796f757220576f726450726573732077656273697465206c6f6f6b696e6720666f72206d616c6963696f757320636f64652c206261636b646f6f72732c207368656c6c732074686174206861636b657273206861766520696e7374616c6c65642c206b6e6f776e206d616c6963696f75732055524c7320616e64206b6e6f776e207061747465726e73206f6620696e66656374696f6e732e222c226368696c6472656e223a5b7b227469746c65223a224f7074696f6e73222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f6f7074696f6e735c2f222c226f72646572223a307d2c7b227469746c65223a22526573756c7473222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f7363616e2d726573756c74735c2f222c226f72646572223a317d2c7b227469746c65223a225363686564756c696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f7363686564756c696e675c2f222c226f72646572223a327d2c7b227469746c65223a2254726f75626c6573686f6f74696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7363616e5c2f74726f75626c6573686f6f74696e675c2f222c226f72646572223a337d5d2c226f72646572223a347d2c7b227469746c65223a22546f6f6c73222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f222c2265786365727074223a22576f726466656e636520546f6f6c7320696e636c7564652054776f20466163746f722041757468656e7469636174696f6e2c2057686f6973204c6f6f6b75702c2050617373776f72642041756469742c20436f6d6d656e74205370616d2046696c7465722c204c697665205472616666696320616e6420446961676e6f73746963732e222c226368696c6472656e223a5b7b227469746c65223a2250617373776f7264204175646974696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f70617373776f72642d6175646974696e675c2f222c226f72646572223a307d2c7b227469746c65223a2257686f6973204c6f6f6b7570222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f77686f69732d6c6f6f6b75705c2f222c226f72646572223a317d2c7b227469746c65223a22436f6d6d656e74205370616d2046696c746572222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f636f6d6d656e742d7370616d2d66696c7465725c2f222c226f72646572223a327d2c7b227469746c65223a22446961676e6f7374696373222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f646961676e6f73746963735c2f222c226f72646572223a337d2c7b227469746c65223a224c6976652054726166666963222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f6c6976652d747261666669635c2f222c226f72646572223a347d2c7b227469746c65223a2254776f20466163746f722041757468656e7469636174696f6e222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f746f6f6c735c2f74776f2d666163746f722d61757468656e7469636174696f6e5c2f222c226f72646572223a357d5d2c226f72646572223a357d2c7b227469746c65223a22416476616e636564222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f222c2265786365727074223a22496620796f752077616e7420746f206b6e6f77206d6f72652061626f75742074686520746563686e6963616c2064657461696c73206f6620576f726466656e63652c20796f75276c6c2066696e642074686520616e737765727320696e20746869732073656374696f6e2e222c226368696c6472656e223a5b7b227469746c65223a2253797374656d20726571756972656d656e7473222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f73797374656d2d726571756972656d656e74735c2f222c226f72646572223a307d2c7b227469746c65223a2252656d6f7665206f72205265736574222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f72656d6f76652d6f722d72657365745c2f222c226f72646572223a317d2c7b227469746c65223a22436f6e7374616e7473222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f636f6e7374616e74735c2f222c226f72646572223a327d2c7b227469746c65223a224368616e67656c6f67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f6368616e67656c6f675c2f222c226f72646572223a337d2c7b227469746c65223a22546563686e6963616c2044657461696c73222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f746563686e6963616c2d64657461696c735c2f222c226f72646572223a347d2c7b227469746c65223a22576f726466656e636520415049222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f776f726466656e63652d6170695c2f222c226f72646572223a357d2c7b227469746c65223a2254726f75626c6573686f6f74696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f616476616e6365645c2f74726f75626c6573686f6f74696e675c2f222c226f72646572223a367d5d2c226f72646572223a367d2c7b227469746c65223a22576f726466656e6365205072656d69756d222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7072656d69756d5c2f222c2265786365727074223a22576f726466656e6365205072656d69756d20636f6d6573207769746820616e20495020426c61636b6c6973742c205265616c2054696d652050726f74656374696f6e20616e64206d756368206d6f72652e222c226368696c6472656e223a5b7b227469746c65223a224c6963656e7365204b6579222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7072656d69756d5c2f6170692d6b65795c2f222c226f72646572223a307d2c7b227469746c65223a2250726963696e67222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f7072656d69756d5c2f70726963696e675c2f222c226f72646572223a317d5d2c226f72646572223a377d2c7b227469746c65223a225369746520436c65616e696e6720616e6420536563757269747920417564697473222c227065726d616c696e6b223a2268747470733a5c2f5c2f7777772e776f726466656e63652e636f6d5c2f68656c705c2f73656375726974792d73657276696365735c2f222c2265786365727074223a224c6574206f6e65206f66206f757220536563757269747920416e616c797374732068656c7020796f7520636c65616e20796f757220696e6665637465642073697465206f7220696e737065637420697420666f722076756c6e65726162696c69746965732e222c226f72646572223a387d5d7d, 'yes'),
('supportHash', 0x62396538323739383539393331646565636336323534356230636232636532313037306264323865613064386363646264383332313936636438303562633535, 'yes'),
('timeoffset_wf', 0x30, 'yes'),
('timeoffset_wf_updated', 0x31353334333534343030, 'yes'),
('totalScansRun', 0x31, 'yes'),
('touppBypassNextCheck', 0x30, 'yes'),
('touppPromptNeeded', 0x30, 'yes'),
('useNoc3Secure', 0x31, 'yes'),
('vulnerabilities_plugin', 0x613a363a7b693a303b613a343a7b733a343a22736c7567223b733a373a22616b69736d6574223b733a31313a2266726f6d56657273696f6e223b733a353a22342e302e38223b733a31303a2276756c6e657261626c65223b623a303b733a343a226c696e6b223b623a303b7d693a313b613a343a7b733a343a22736c7567223b733a31303a226475706c696361746f72223b733a31313a2266726f6d56657273696f6e223b733a363a22312e322e3430223b733a31303a2276756c6e657261626c65223b623a303b733a343a226c696e6b223b623a303b7d693a323b613a343a7b733a343a22736c7567223b733a32303a22657777772d696d6167652d6f7074696d697a6572223b733a31313a2266726f6d56657273696f6e223b733a353a22342e332e31223b733a31303a2276756c6e657261626c65223b623a303b733a343a226c696e6b223b623a303b7d693a333b613a343a7b733a343a22736c7567223b733a31313a22776f6f636f6d6d65726365223b733a31313a2266726f6d56657273696f6e223b733a353a22332e342e34223b733a31303a2276756c6e657261626c65223b623a303b733a343a226c696e6b223b623a303b7d693a343b613a343a7b733a343a22736c7567223b733a393a22776f726466656e6365223b733a31313a2266726f6d56657273696f6e223b733a363a22372e312e3130223b733a31303a2276756c6e657261626c65223b623a303b733a343a226c696e6b223b623a303b7d693a353b613a343a7b733a343a22736c7567223b733a31333a22776f726470726573732d73656f223b733a31313a2266726f6d56657273696f6e223b733a333a22382e30223b733a31303a2276756c6e657261626c65223b623a303b733a343a226c696e6b223b623a303b7d7d, 'yes'),
('vulnRegex', 0x2f283f3a776f726466656e63655f746573745f76756c6e5f6d617463687c5c2f74696d7468756d625c2e7068707c5c2f7468756d625c2e7068707c5c2f7468756d62735c2e7068707c5c2f7468756d626e61696c5c2e7068707c5c2f7468756d626e61696c735c2e7068707c5c2f7468756d6e61696c735c2e7068707c5c2f63726f707065725c2e7068707c5c2f70696373697a655c2e7068707c5c2f726573697a65725c2e7068707c636f6e6e6563746f72735c2f75706c6f6164746573745c2e68746d6c7c636f6e6e6563746f72735c2f746573745c2e68746d6c7c6d696e676c65666f72756d616374696f6e7c75706c6f61646966795c2e7068707c616c6c7765626d656e75732d776f726470726573732d6d656e752d706c7567696e7c77702d6379636c652d706c61796c6973747c636f756e742d7065722d6461797c77702d6175746f796f75747562657c7061792d776974682d74776565747c636f6d6d656e742d726174696e675c2f636b2d70726f636573736b61726d615c2e706870292f69, 'yes'),
('wafAlertInterval', 0x363030, 'yes'),
('wafAlertOnAttacks', 0x31, 'yes'),
('wafAlertThreshold', 0x313030, 'yes'),
('wafAlertWhitelist', '', 'yes'),
('wfKillRequested', 0x30, 'no'),
('wfPeakMemory', 0x3132353832393132, 'no'),
('wfScanStartVersion', 0x342e392e38, 'yes'),
('wfStatusStartMsgs', 0x613a313a7b693a303b733a303a22223b7d, 'yes'),
('wf_scanLastStatusTime', 0x30, 'yes'),
('wf_scanRunning', '', 'yes'),
('wf_summaryItems', 0x613a383a7b733a31323a227363616e6e6564506f737473223b693a303b733a31353a227363616e6e6564436f6d6d656e7473223b693a303b733a31323a227363616e6e656446696c6573223b693a303b733a31343a227363616e6e6564506c7567696e73223b693a303b733a31333a227363616e6e65645468656d6573223b693a303b733a31323a227363616e6e65645573657273223b693a303b733a31313a227363616e6e656455524c73223b693a303b733a31303a226c617374557064617465223b693a313533343335343438353b7d, 'yes'),
('whitelisted', '', 'yes'),
('wp_home_url', 0x687474703a2f2f6c6f63616c686f73743a38383838, 'yes'),
('wp_site_url', 0x687474703a2f2f6c6f63616c686f73743a38383838, 'yes');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfcrawlers`
--

CREATE TABLE `dp_wfcrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) UNSIGNED NOT NULL,
  `PTR` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wffilechanges`
--

CREATE TABLE `dp_wffilechanges` (
  `filenameHash` char(64) NOT NULL,
  `file` varchar(1000) NOT NULL,
  `md5` char(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wffilemods`
--

CREATE TABLE `dp_wffilemods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) UNSIGNED NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  `SHAC` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `stoppedOnSignature` varchar(255) NOT NULL DEFAULT '',
  `stoppedOnPosition` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `isSafeFile` varchar(1) NOT NULL DEFAULT '?'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfhits`
--

CREATE TABLE `dp_wfhits` (
  `id` int(10) UNSIGNED NOT NULL,
  `attackLogTime` double(17,6) UNSIGNED NOT NULL,
  `ctime` double(17,6) UNSIGNED NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `statusCode` int(11) NOT NULL DEFAULT '200',
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) UNSIGNED NOT NULL,
  `newVisit` tinyint(3) UNSIGNED NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  `action` varchar(64) NOT NULL DEFAULT '',
  `actionDescription` text,
  `actionData` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfhoover`
--

CREATE TABLE `dp_wfhoover` (
  `id` int(10) UNSIGNED NOT NULL,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` varbinary(124) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfissues`
--

CREATE TABLE `dp_wfissues` (
  `id` int(10) UNSIGNED NOT NULL,
  `time` int(10) UNSIGNED NOT NULL,
  `lastUpdated` int(10) UNSIGNED NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) UNSIGNED NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfknownfilelist`
--

CREATE TABLE `dp_wfknownfilelist` (
  `id` int(11) UNSIGNED NOT NULL,
  `path` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfleechers`
--

CREATE TABLE `dp_wfleechers` (
  `eMin` int(10) UNSIGNED NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wflivetraffichuman`
--

CREATE TABLE `dp_wflivetraffichuman` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `identifier` binary(32) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `expiration` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wflocs`
--

CREATE TABLE `dp_wflocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) UNSIGNED NOT NULL,
  `failed` tinyint(3) UNSIGNED NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wflogins`
--

CREATE TABLE `dp_wflogins` (
  `id` int(10) UNSIGNED NOT NULL,
  `hitID` int(11) DEFAULT NULL,
  `ctime` double(17,6) UNSIGNED NOT NULL,
  `fail` tinyint(3) UNSIGNED NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) UNSIGNED NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfnotifications`
--

CREATE TABLE `dp_wfnotifications` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `new` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `category` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '1000',
  `ctime` int(10) UNSIGNED NOT NULL,
  `html` text NOT NULL,
  `links` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfpendingissues`
--

CREATE TABLE `dp_wfpendingissues` (
  `id` int(10) UNSIGNED NOT NULL,
  `time` int(10) UNSIGNED NOT NULL,
  `lastUpdated` int(10) UNSIGNED NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) UNSIGNED NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfreversecache`
--

CREATE TABLE `dp_wfreversecache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfscanners`
--

CREATE TABLE `dp_wfscanners` (
  `eMin` int(10) UNSIGNED NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfsnipcache`
--

CREATE TABLE `dp_wfsnipcache` (
  `id` int(10) UNSIGNED NOT NULL,
  `IP` varchar(45) NOT NULL DEFAULT '',
  `expiration` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `body` varchar(255) NOT NULL DEFAULT '',
  `count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `type` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfstatus`
--

CREATE TABLE `dp_wfstatus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ctime` double(17,6) UNSIGNED NOT NULL,
  `level` tinyint(3) UNSIGNED NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `dp_wfstatus`
--

INSERT INTO `dp_wfstatus` (`id`, `ctime`, `level`, `type`, `msg`) VALUES
(1, 1534354485.476997, 10, 'info', 'SUM_PREP:Preparing a new scan.'),
(2, 1534354485.806919, 1, 'info', 'Initiating quick scan'),
(3, 1534354486.004289, 10, 'info', 'SUM_START:Scanning for old themes, plugins and core files'),
(4, 1534354486.148750, 10, 'info', 'SUM_ENDOK:Scanning for old themes, plugins and core files'),
(5, 1534354486.686766, 1, 'info', '-------------------'),
(6, 1534354486.811813, 2, 'info', 'Wordfence used 0 B of memory for scan. Server peak memory usage was: 12 MB'),
(7, 1534354486.905879, 1, 'info', 'Quick Scan Complete. Scanned in 1 second.'),
(8, 1534354486.993534, 10, 'info', 'SUM_FINAL:Scan complete. Congratulations, no new problems found.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_wfvulnscanners`
--

CREATE TABLE `dp_wfvulnscanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) UNSIGNED NOT NULL,
  `hits` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_api_keys`
--

CREATE TABLE `dp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_attribute_taxonomies`
--

CREATE TABLE `dp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_downloadable_product_permissions`
--

CREATE TABLE `dp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_log`
--

CREATE TABLE `dp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_order_itemmeta`
--

CREATE TABLE `dp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_order_items`
--

CREATE TABLE `dp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_payment_tokenmeta`
--

CREATE TABLE `dp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_payment_tokens`
--

CREATE TABLE `dp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_sessions`
--

CREATE TABLE `dp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_woocommerce_sessions`
--

INSERT INTO `dp_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(15, '4d0e3ff1c3b80bb3d96607ddd2475782', 'a:8:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:410:\"a:1:{s:32:\"e2c420d928d4bf8ce0ff2ec19b371514\";a:11:{s:3:\"key\";s:32:\"e2c420d928d4bf8ce0ff2ec19b371514\";s:10:\"product_id\";i:71;s:12:\"variation_id\";i:0;s:9:\"variation\";a:0:{}s:8:\"quantity\";i:1;s:9:\"data_hash\";s:32:\"b5c1d5ca8bae6d4896cf1807cdf763f0\";s:13:\"line_tax_data\";a:2:{s:8:\"subtotal\";a:0:{}s:5:\"total\";a:0:{}}s:13:\"line_subtotal\";d:10;s:17:\"line_subtotal_tax\";i:0;s:10:\"line_total\";d:10;s:8:\"line_tax\";i:0;}}\";s:8:\"customer\";s:744:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2018-08-18T18:15:30+00:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"CL\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"CL\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:30:\"mariana.j.ambrosetti@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";s:10:\"wc_notices\";N;}', 1535580382);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_shipping_zones`
--

CREATE TABLE `dp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_shipping_zone_locations`
--

CREATE TABLE `dp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_shipping_zone_methods`
--

CREATE TABLE `dp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_tax_rates`
--

CREATE TABLE `dp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_woocommerce_tax_rate_locations`
--

CREATE TABLE `dp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_yoast_seo_links`
--

CREATE TABLE `dp_yoast_seo_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `target_post_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_yoast_seo_links`
--

INSERT INTO `dp_yoast_seo_links` (`id`, `url`, `post_id`, `target_post_id`, `type`) VALUES
(20, 'http://localhost:8888/wp-content/uploads/2018/08/galeria3.jpg', 1, 0, 'internal'),
(21, 'http://localhost:8888/wp-content/uploads/2018/08/galeria1.jpg', 1, 0, 'internal'),
(22, 'http://localhost:8888/wp-content/uploads/2018/08/galeria2.jpg', 1, 0, 'internal'),
(28, 'http://186.64.118.50/~feg7mariana/contacto/', 24, 28, 'internal'),
(31, 'http://186.64.118.50/~feg7mariana/contacto', 18, 0, 'external');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dp_yoast_seo_meta`
--

CREATE TABLE `dp_yoast_seo_meta` (
  `object_id` bigint(20) UNSIGNED NOT NULL,
  `internal_link_count` int(10) UNSIGNED DEFAULT NULL,
  `incoming_link_count` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Volcado de datos para la tabla `dp_yoast_seo_meta`
--

INSERT INTO `dp_yoast_seo_meta` (`object_id`, `internal_link_count`, `incoming_link_count`) VALUES
(1, 3, 0),
(3, 0, 0),
(4, 0, 0),
(5, 0, 0),
(6, 0, 0),
(7, 0, 0),
(8, 0, 0),
(13, 0, 0),
(16, 0, 0),
(18, 0, 0),
(20, 0, 0),
(22, 0, 0),
(24, 1, 0),
(26, 0, 0),
(28, 0, 1),
(30, 0, 0),
(33, 0, 0),
(36, 0, 0),
(37, 0, 0),
(38, 0, 0),
(41, 0, 0),
(42, 0, 0),
(46, 0, 0),
(66, 0, 0),
(70, 0, 0),
(71, 0, 0),
(76, 0, 0),
(118, 0, 0),
(141, 0, 0),
(158, 0, 0),
(160, 0, 0),
(162, 0, 0),
(247, 0, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `dp_commentmeta`
--
ALTER TABLE `dp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `dp_comments`
--
ALTER TABLE `dp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indices de la tabla `dp_duplicator_packages`
--
ALTER TABLE `dp_duplicator_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indices de la tabla `dp_ewwwio_images`
--
ALTER TABLE `dp_ewwwio_images`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `path_image_size` (`path`(191),`image_size`),
  ADD KEY `attachment_info` (`gallery`(3),`attachment_id`);

--
-- Indices de la tabla `dp_links`
--
ALTER TABLE `dp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indices de la tabla `dp_options`
--
ALTER TABLE `dp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indices de la tabla `dp_postmeta`
--
ALTER TABLE `dp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `dp_posts`
--
ALTER TABLE `dp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indices de la tabla `dp_termmeta`
--
ALTER TABLE `dp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `dp_terms`
--
ALTER TABLE `dp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indices de la tabla `dp_term_relationships`
--
ALTER TABLE `dp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indices de la tabla `dp_term_taxonomy`
--
ALTER TABLE `dp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indices de la tabla `dp_usermeta`
--
ALTER TABLE `dp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indices de la tabla `dp_users`
--
ALTER TABLE `dp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indices de la tabla `dp_wc_download_log`
--
ALTER TABLE `dp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indices de la tabla `dp_wc_webhooks`
--
ALTER TABLE `dp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `dp_wfbadleechers`
--
ALTER TABLE `dp_wfbadleechers`
  ADD PRIMARY KEY (`eMin`,`IP`);

--
-- Indices de la tabla `dp_wfblockedcommentlog`
--
ALTER TABLE `dp_wfblockedcommentlog`
  ADD PRIMARY KEY (`IP`,`unixday`,`blockType`);

--
-- Indices de la tabla `dp_wfblockediplog`
--
ALTER TABLE `dp_wfblockediplog`
  ADD PRIMARY KEY (`IP`,`unixday`,`blockType`);

--
-- Indices de la tabla `dp_wfblocks7`
--
ALTER TABLE `dp_wfblocks7`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type`),
  ADD KEY `IP` (`IP`),
  ADD KEY `expiration` (`expiration`);

--
-- Indices de la tabla `dp_wfconfig`
--
ALTER TABLE `dp_wfconfig`
  ADD PRIMARY KEY (`name`);

--
-- Indices de la tabla `dp_wfcrawlers`
--
ALTER TABLE `dp_wfcrawlers`
  ADD PRIMARY KEY (`IP`,`patternSig`);

--
-- Indices de la tabla `dp_wffilechanges`
--
ALTER TABLE `dp_wffilechanges`
  ADD PRIMARY KEY (`filenameHash`);

--
-- Indices de la tabla `dp_wffilemods`
--
ALTER TABLE `dp_wffilemods`
  ADD PRIMARY KEY (`filenameMD5`);

--
-- Indices de la tabla `dp_wfhits`
--
ALTER TABLE `dp_wfhits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `k1` (`ctime`),
  ADD KEY `k2` (`IP`,`ctime`),
  ADD KEY `attackLogTime` (`attackLogTime`);

--
-- Indices de la tabla `dp_wfhoover`
--
ALTER TABLE `dp_wfhoover`
  ADD PRIMARY KEY (`id`),
  ADD KEY `k2` (`hostKey`);

--
-- Indices de la tabla `dp_wfissues`
--
ALTER TABLE `dp_wfissues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lastUpdated` (`lastUpdated`),
  ADD KEY `status` (`status`),
  ADD KEY `ignoreP` (`ignoreP`),
  ADD KEY `ignoreC` (`ignoreC`);

--
-- Indices de la tabla `dp_wfknownfilelist`
--
ALTER TABLE `dp_wfknownfilelist`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `dp_wfleechers`
--
ALTER TABLE `dp_wfleechers`
  ADD PRIMARY KEY (`eMin`,`IP`);

--
-- Indices de la tabla `dp_wflivetraffichuman`
--
ALTER TABLE `dp_wflivetraffichuman`
  ADD PRIMARY KEY (`IP`,`identifier`),
  ADD KEY `expiration` (`expiration`);

--
-- Indices de la tabla `dp_wflocs`
--
ALTER TABLE `dp_wflocs`
  ADD PRIMARY KEY (`IP`);

--
-- Indices de la tabla `dp_wflogins`
--
ALTER TABLE `dp_wflogins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `k1` (`IP`,`fail`),
  ADD KEY `hitID` (`hitID`);

--
-- Indices de la tabla `dp_wfnotifications`
--
ALTER TABLE `dp_wfnotifications`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `dp_wfpendingissues`
--
ALTER TABLE `dp_wfpendingissues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lastUpdated` (`lastUpdated`),
  ADD KEY `status` (`status`),
  ADD KEY `ignoreP` (`ignoreP`),
  ADD KEY `ignoreC` (`ignoreC`);

--
-- Indices de la tabla `dp_wfreversecache`
--
ALTER TABLE `dp_wfreversecache`
  ADD PRIMARY KEY (`IP`);

--
-- Indices de la tabla `dp_wfscanners`
--
ALTER TABLE `dp_wfscanners`
  ADD PRIMARY KEY (`eMin`,`IP`);

--
-- Indices de la tabla `dp_wfsnipcache`
--
ALTER TABLE `dp_wfsnipcache`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expiration` (`expiration`),
  ADD KEY `IP` (`IP`),
  ADD KEY `type` (`type`);

--
-- Indices de la tabla `dp_wfstatus`
--
ALTER TABLE `dp_wfstatus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `k1` (`ctime`),
  ADD KEY `k2` (`type`);

--
-- Indices de la tabla `dp_wfvulnscanners`
--
ALTER TABLE `dp_wfvulnscanners`
  ADD PRIMARY KEY (`IP`);

--
-- Indices de la tabla `dp_woocommerce_api_keys`
--
ALTER TABLE `dp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indices de la tabla `dp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `dp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indices de la tabla `dp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `dp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indices de la tabla `dp_woocommerce_log`
--
ALTER TABLE `dp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indices de la tabla `dp_woocommerce_order_itemmeta`
--
ALTER TABLE `dp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indices de la tabla `dp_woocommerce_order_items`
--
ALTER TABLE `dp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indices de la tabla `dp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `dp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indices de la tabla `dp_woocommerce_payment_tokens`
--
ALTER TABLE `dp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `dp_woocommerce_sessions`
--
ALTER TABLE `dp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_key`),
  ADD UNIQUE KEY `session_id` (`session_id`);

--
-- Indices de la tabla `dp_woocommerce_shipping_zones`
--
ALTER TABLE `dp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indices de la tabla `dp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `dp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indices de la tabla `dp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `dp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indices de la tabla `dp_woocommerce_tax_rates`
--
ALTER TABLE `dp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indices de la tabla `dp_woocommerce_tax_rate_locations`
--
ALTER TABLE `dp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indices de la tabla `dp_yoast_seo_links`
--
ALTER TABLE `dp_yoast_seo_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `link_direction` (`post_id`,`type`);

--
-- Indices de la tabla `dp_yoast_seo_meta`
--
ALTER TABLE `dp_yoast_seo_meta`
  ADD UNIQUE KEY `object_id` (`object_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `dp_commentmeta`
--
ALTER TABLE `dp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_comments`
--
ALTER TABLE `dp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `dp_duplicator_packages`
--
ALTER TABLE `dp_duplicator_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_ewwwio_images`
--
ALTER TABLE `dp_ewwwio_images`
  MODIFY `id` int(14) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=331;
--
-- AUTO_INCREMENT de la tabla `dp_links`
--
ALTER TABLE `dp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_options`
--
ALTER TABLE `dp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2132;
--
-- AUTO_INCREMENT de la tabla `dp_postmeta`
--
ALTER TABLE `dp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=689;
--
-- AUTO_INCREMENT de la tabla `dp_posts`
--
ALTER TABLE `dp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;
--
-- AUTO_INCREMENT de la tabla `dp_termmeta`
--
ALTER TABLE `dp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT de la tabla `dp_terms`
--
ALTER TABLE `dp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de la tabla `dp_term_taxonomy`
--
ALTER TABLE `dp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de la tabla `dp_usermeta`
--
ALTER TABLE `dp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT de la tabla `dp_users`
--
ALTER TABLE `dp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `dp_wc_download_log`
--
ALTER TABLE `dp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wc_webhooks`
--
ALTER TABLE `dp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfblocks7`
--
ALTER TABLE `dp_wfblocks7`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfhits`
--
ALTER TABLE `dp_wfhits`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfhoover`
--
ALTER TABLE `dp_wfhoover`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfissues`
--
ALTER TABLE `dp_wfissues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfknownfilelist`
--
ALTER TABLE `dp_wfknownfilelist`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wflogins`
--
ALTER TABLE `dp_wflogins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfpendingissues`
--
ALTER TABLE `dp_wfpendingissues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfsnipcache`
--
ALTER TABLE `dp_wfsnipcache`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_wfstatus`
--
ALTER TABLE `dp_wfstatus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_api_keys`
--
ALTER TABLE `dp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `dp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `dp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_log`
--
ALTER TABLE `dp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_order_itemmeta`
--
ALTER TABLE `dp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_order_items`
--
ALTER TABLE `dp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `dp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_payment_tokens`
--
ALTER TABLE `dp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_sessions`
--
ALTER TABLE `dp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_shipping_zones`
--
ALTER TABLE `dp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `dp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `dp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_tax_rates`
--
ALTER TABLE `dp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_woocommerce_tax_rate_locations`
--
ALTER TABLE `dp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `dp_yoast_seo_links`
--
ALTER TABLE `dp_yoast_seo_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
